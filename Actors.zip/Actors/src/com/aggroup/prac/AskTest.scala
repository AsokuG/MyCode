package com.aggroup.prac

import scala.concurrent.Future

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props
import akka.pattern.ask
import scala.concurrent.duration._
import akka.util.Timeout
import scala.util.Success
import scala.util.Failure
import scala.concurrent.Await

class MyActor extends Actor {
// implicit val ec= context.dispatcher
  override def receive: Receive = {
    case num: Int =>
      val result = process(num);
       sender ! result
       
     
    case _ =>
  }
  
  def process(num: Int): Int= {
  num*5
  }
}

object AskTest extends App {
implicit val timeout =  Timeout(1 seconds)
 val actorSystem = ActorSystem("ActorSystem")
 implicit val ec= actorSystem.dispatcher
 val myActor = actorSystem.actorOf(Props[MyActor], name="myActor")
  val res1 = myActor ? 8
  val res2 = myActor ? 6
  
  res1 onComplete { 
  case Success(res) => println(res)
  case Failure(fail) => println("Failed1")
    }
res2 onComplete { 
  case Success(res) => println(res)
  case Failure(fail) => println("Failed2")
    }
 
println("Hello")  
}