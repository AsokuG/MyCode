package com.aggroup.prac

import akka.actor.Actor
import scala.concurrent.Future
import akka.actor.ActorSystem
import akka.actor.Props
import scala.concurrent.ExecutionContext
import com.typesafe.config.ConfigFactory

class BlockingFutureActor extends Actor {
implicit val ec =  context.dispatcher
 override def receive:Receive = {
   case num: Int =>
    // println(s"Calling blocking Future: ${num}")
      Future {
        Thread.sleep(5000) //block for 5 seconds
        println(s"${Thread.currentThread().getName} Blocking future finished ${num}")
      }
 } 
}

class SeparateDispatcherFutureActor extends Actor {
  implicit val executionContext: ExecutionContext = context.system.dispatchers.lookup("my-blocking-dispatcher")

  def receive = {
    case i: Int ⇒
     // println(s"Calling blocking Future: ${i}")
      Future {
        Thread.sleep(5000) //block for 5 seconds
        println(s" ${Thread.currentThread().getName} Blocking future in separate finished ${i}")
        
      }
  }
}

class PrintActor extends Actor {
  def receive = {
    case i: Int ⇒
      println(s"PrintActor: ${i}")
  }
}

object BlockingApp extends App {
  val config  = ConfigFactory.parseString("""
      //#my-blocking-dispatcher-config
      my-blocking-dispatcher {
        type = Dispatcher
        executor = "thread-pool-executor"
        thread-pool-executor {
          fixed-pool-size = 16
        }
        throughput = 1
      }
      //#my-blocking-dispatcher-config
    """)
 val actorSystem = ActorSystem("ActorSystem", config)
 val blockingActor = actorSystem.actorOf(Props[BlockingFutureActor], name = "blockingActor")
 val separateDispatcherFutureActor = actorSystem.actorOf(Props[SeparateDispatcherFutureActor], name = "separateDispatcherFutureActor")
 val printActor = actorSystem.actorOf(Props[PrintActor], name = "printActor")
 1 to 100 foreach{
   i => blockingActor ! i; printActor ! i; separateDispatcherFutureActor ! i
 }
}