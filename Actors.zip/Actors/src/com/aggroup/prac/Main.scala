package com.aggroup.prac

import akka.actor.Actor
import akka.actor.ActorRef
import akka.actor.Props
import akka.actor.ActorSystem
import java.io.StringWriter
import java.io.PrintWriter

class MessageReceiver extends Actor {
  override def receive: Receive = {
    case msg: String => println(s"${Thread.currentThread()} |[${self.path}]| EchoActor : received message = $msg")
  }
}

class MessageSender(messageReceiver: ActorRef) extends Actor {
  override def preStart(): Unit = {
    val messages = List("Hello, Ashok", "Hello, Universe", "Hello, Galaxy")
    for (msg <- messages) {
      println(s"${Thread.currentThread()} |[${self.path}]| sending message $msg to $messageReceiver")
      messageReceiver ! msg
    }
  }

  override def receive = Actor.emptyBehavior
}

object MessageSender {
  def props(messageReceiver: ActorRef) = Props(new MessageSender(messageReceiver))
}

object Main {
  def main(args: Array[String]): Unit = {
    val system = ActorSystem("ActorSystem")
    try {
      val receiver = system.actorOf(Props[MessageReceiver], "receiver")
      system.actorOf(MessageSender.props(receiver))
    } catch {
      case t: Throwable => {
        val sw = new StringWriter
        t.printStackTrace(new PrintWriter(sw))
        println(t.getMessage)
        println(sw)
      }
    } finally {
      system.terminate()
    }
  }
}