package com.aggroup.prac

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.concurrent.Await
import scala.concurrent.duration.Duration

object Prog {
  def debug(msg: String): Unit = {
    val thread = Thread.currentThread().getName
    println(s" [$thread] processed message is $msg")
  }
  def taskA(): Future[Unit] = Future{
    debug("starting taskA")
    Thread.sleep(1000)
    debug("ending taskA")
  }
  def taskB(): Future[Unit] = Future{
    debug("starting taskB")
    Thread.sleep(2000)
    debug("ending taskB")
  }
   def main(args: Array[String]): Unit = {
    debug("Starting Main")
   val fa = taskA()
   val fb = taskB()
    debug("Finished Main")
     Await.result(fa zip fb, Duration.Inf)
  }
}