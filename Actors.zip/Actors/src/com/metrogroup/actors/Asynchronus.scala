package com.metrogroup.actors

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.Failure
import scala.util.Success

object Asynchronus extends App {
  
/*val f =  Future(11 + 22).mapTo[Int]

f onComplete { 
  case Success(result) => println("result is:" + result)
  case Failure(fail) => fail.printStackTrace()
}
 println("before future") */
  
  
 val f1 = Future{
   Thread.sleep(100)
  throw new IllegalArgumentException
  }
 
 val f2 = Future{
   Thread.sleep(200)
   33
 }
val result = for{
   x <- f1.recoverWith{ case e: Exception  => Future(10)}
   y <- f2
 } yield{ x+y}
 
result.onComplete{
  case Success(result) => println(result)
  case Failure(fail) => fail.printStackTrace()
}
 Thread.sleep(1000)
}