package com.metrogroup.actors

import akka.actor.ActorSystem
import akka.actor.Actor
import akka.routing.BalancingPool
import akka.actor.Props
import akka.routing.Broadcast
import akka.actor.PoisonPill

class BalancingPoolActor extends Actor {
  override def receive: Receive = {
    case num: Int => println(s"received message is $num and ${self.path.name}")
    case _ => //
  }
  
  override def postStop(): Unit = {
    println("all rotuees are killed by after successfully processed")
  }
}

object BalancingPoolTest extends App {
 val actorSystem = ActorSystem("ActorSystem")
//val balancingRouter = actorSystem.actorOf(Props[BalancingPoolActor].withRouter(BalancingPool(5)), "myBalancingRouter")
 val balancingRouter = actorSystem.actorOf(BalancingPool(5).props(Props[BalancingPoolActor]))
 
 1 to 10 foreach {
   i => balancingRouter ! i
 }
  balancingRouter ! Broadcast(PoisonPill)
}