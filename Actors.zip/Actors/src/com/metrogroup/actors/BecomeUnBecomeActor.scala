package com.metrogroup.actors

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props

/*changing the state of anctor
 * dynamically by using become*/
class BecomeUnBecomeActor extends Actor {
 override def receive: Receive = {
   case true => context.become(isStateTrue)
   case false => context.become(isStateFalse)
   case _  => println("we're unable to process the your request.")
 }
 
 def isStateTrue: Receive = {
   case msg: String => println(s"$msg")
   case false => context.become(isStateFalse)
 }
 def isStateFalse: Receive = {
   case msg: Int => println(s"$msg")
   case true => context.become(isStateTrue)
 }
  
}

object BecomeUnBecomeApp extends App {
  val actorSystem = ActorSystem("ashok")
 val becomeUnBecomeActor =  actorSystem.actorOf(Props[BecomeUnBecomeActor], name="becomeUnBecomeActor")
 becomeUnBecomeActor ! false
 becomeUnBecomeActor ! ""
 becomeUnBecomeActor ! 19
 becomeUnBecomeActor ! true
 becomeUnBecomeActor ! false
 
 becomeUnBecomeActor ! 56
}