package com.metrogroup.actors

import akka.actor.ActorSystem
import akka.actor.Actor
import akka.actor.Props
import akka.routing.BroadcastPool
import akka.routing.Broadcast
import akka.actor.PoisonPill

class BroadcastPoolActor extends Actor {
  var count = 0
  override def receive : Receive = {
    case num: Int => println(s"received message is $num")
    case _ =>//
  }
}

object BroadcastPoolTest extends App {
 val actorSystem = ActorSystem("actorSystem") 
 val broadcastPoolRouter = actorSystem.actorOf(BroadcastPool(5).props (Props[BroadcastPoolActor]))
 1 to 10 foreach {
   i => broadcastPoolRouter !  i
 }
 broadcastPoolRouter ! Broadcast(PoisonPill)
}