package com.metrogroup.actors

import scala.concurrent.duration.DurationInt

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props
import akka.pattern.{CircuitBreaker, ask}
import akka.util.Timeout

case class FetchRecord(recordID: Int)
case class Person(name: String, age: Int)


object DB {
val data =  Map(1 -> Person("John", 21), 
                2 -> Person("Peter", 30), 
                3 -> Person("James", 40),
                4 -> Person("Alice", 25), 
                5 -> Person("Henry", 26), 
                6 -> Person("Jackson", 48))
}

class DBActor extends Actor {
  override def receive: Receive = {
    case FetchRecord(recordID) => {
      if(recordID >=3 && recordID <=5) Thread.sleep(100)
      else sender ! DB.data.getOrElse(recordID, Person("", 0))
    }
  }
}

object CircuitBreakerApp extends App {
  
 val actorSystem = ActorSystem("ActorSystem")
 implicit val ec = actorSystem.dispatcher
 implicit val timeout = Timeout(10 seconds)
 
  val breaker =  CircuitBreaker(actorSystem.scheduler, maxFailures= 3, callTimeout = 1 seconds,  resetTimeout = 1 seconds).
            onOpen(println("===========State is open=============")).
            onClose(println("==========State is closed============")
              )
 
 val dbActor = actorSystem.actorOf(Props[DBActor], "dbActor")
 
  (1 to 10).map(recordId => {
            Thread.sleep(3000)
            val askFuture = breaker.withCircuitBreaker(dbActor ?  FetchRecord(recordId))
            askFuture.map(record => s"Record is: $record and RecordID  $recordId").recover({
              case fail => "Failed with: " + fail.toString
            }).foreach(x => println(x))
          })
  
}