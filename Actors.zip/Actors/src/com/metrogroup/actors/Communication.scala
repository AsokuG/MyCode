package com.metrogroup.actors

import akka.actor.Actor
import scala.util.Random._ 
import akka.actor.ActorSystem
import akka.actor.Props


class Communication {
  
}

class RandomNumberGeneratorActor  extends Actor{
  import Messages._
  override def receive: Receive = {
    case GiveMeRandomNumber => println("received a message from generated random number")
    val randomNum = nextInt
    sender ! Done(randomNum)
    
  }
}

class QueryActor extends Actor {
  import Messages._
  override def receive: Receive = {
    case Start(actorRef) => println(s"send me the next random number") 
                            actorRef ! GiveMeRandomNumber 
    case Done(randomNum: Int) => println(s"generated random number is ${randomNum}")
    
  }
}

object Communication extends App{
    import Messages._
  val actorSystem = ActorSystem("ashok")
  val queryActor = actorSystem.actorOf(Props[QueryActor], name="queryActor")
  val randomNumberActor = actorSystem.actorOf(Props[RandomNumberGeneratorActor], name="randomNumberActor")
  queryActor ! Start(randomNumberActor)
  
}