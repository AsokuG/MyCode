package com.metrogroup.actors

import scala.concurrent.Await
import scala.concurrent.duration._

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props
import akka.util.Timeout
import akka.pattern.ask 

class ComputationActor extends Actor {
  
  override def receive:Receive = {
    case (a: Int, b: Int) => sender ! (a+b)
  }
  
}

object FutureWithScala extends App {
  implicit val timeout = Timeout(10 seconds) 
  val actorSystem = ActorSystem("Hello-Akka") 
  val computationActor =  actorSystem.actorOf(Props[ComputationActor])          
  val future = (computationActor ? (2,3) ).mapTo[Int]          
  val sum = Await.result(future, 10 seconds)           
  println(s"Future Result $sum") 
}