package com.metrogroup.actors

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props
import akka.actor.Terminated

case object Service
case object Kill

class ServiceActor extends Actor {
  override def receive: Receive = {
    case Service => println("I'm providing a special service")
  }
}

class DeathWatchActor extends Actor {
  val serviceActor = context.actorOf(Props[ServiceActor], name = "serviceActor")
  context.watch(serviceActor)
  // context.unwatch(serviceActor)
  override def receive: Receive = {
    case Service                    => serviceActor ! Service
    case Kill                       => context.stop(serviceActor)
    case Terminated(`serviceActor`) => println("The service actor  has terminated and no longer available")
  }

}

object DeathWatchActorApp extends App {
  val system = ActorSystem("DeathWatchActor")
  val deathWatchActor = system.actorOf(Props[DeathWatchActor], name = "deathWatchActor")
  deathWatchActor ! Service
    Thread.sleep(1000) 
   deathWatchActor ! Kill 
   deathWatchActor ! Service 
}