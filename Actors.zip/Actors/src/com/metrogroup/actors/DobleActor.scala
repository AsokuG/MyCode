package com.metrogroup.actors

import akka.actor.Actor
import akka.actor.ActorRef
import akka.actor.Props
import akka.actor.ActorSystem

case class DoubleValues(x: Int)
case object CreateChid
case object Sends
case class Responses(x: Int)

class DobleActor extends Actor {
  def receive = {
    case DoubleValues(number) =>
      println(s"${self.path.name} Got the number $number")
      sender ! Responses(number * 2)
  }

}

class ParentDobleActor extends Actor {
  val random = new scala.util.Random
  var childs =
    scala.collection.mutable.ListBuffer[ActorRef]()
  def receive = {
    case CreateChid =>
      childs ++= List(context.actorOf(Props[DobleActor]))
    case Sends =>
      println(s"Sending messages to child")
      childs.zipWithIndex map {
        case (child, value) =>
          child ! DoubleValues(random.nextInt(10))
      }
    case Responses(x) => println(s"Parent: Response from child ${sender.path.name} is $x")
  }
}

object SendMessagesToChild extends App {
  val actorSystem = ActorSystem("Hello-Akka")
  val parent =  actorSystem.actorOf(Props[ParentDobleActor], "parent")
  parent ! CreateChid
  parent ! CreateChid
  parent ! CreateChid
  parent ! Sends
} 

