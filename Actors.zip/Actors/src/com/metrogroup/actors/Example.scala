package com.metrogroup.actors

import java.util.concurrent.TimeUnit

import akka.actor.ActorSystem
import akka.actor.Props
import akka.routing.RoundRobinPool

object Example extends App {
  
 val actorSystem = ActorSystem("RoundRobinRouterExample")
 val echoActor = actorSystem.actorOf(Props[MsgEchoActor], "EchoActor")
 val roundRobinRouter = actorSystem.actorOf(Props[MsgEchoActor].withRouter(RoundRobinPool(5)), name = "myRoundRobinRouterActor")
  println("starting time is:"+ System.nanoTime()) 
   
 1 to 10 foreach {
      i =>
        roundRobinRouter ! i
        if (i == 5) {
          TimeUnit.MILLISECONDS.sleep(100)
          System.out.println("\n")
           
        }
    }
actorSystem.awaitTermination()
println("ending time is:"+ System.nanoTime())
}