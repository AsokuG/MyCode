package com.metrogroup.actors

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.util.Timeout
import scala.concurrent.Await
import akka.actor.Props
import scala.concurrent.duration._ 
import akka.pattern.ask 

class FibonacciActor extends Actor{
  
  override def receive: Receive = {
      case num: Int => {
      val fiboNumber = fibo(num)
      /*send the Fibonacci result back to the sender
       * know who has sent them the message
       * we always have the sender present in the context of the receive block. */
      sender ! fiboNumber
    }
      
    def fibo(n: Int): Int = n match {
      case 0 | 1 => n
      case _ => fibo(n-1) + fibo(n-2) // 0 1 1 2 3 5 8 13 21 34
    }
    
  }
}

object FibonacciActorApp extends App{
implicit val timeout =  Timeout(10 seconds)
val actorSystem = ActorSystem("ashok")
val fibanocciActor = actorSystem.actorOf(Props[FibonacciActor], name="fibanocciActor")
//send a message to an actor by ask(?) result as future 
val future = (fibanocciActor ? 10).mapTo[Int]
val fut = (fibanocciActor ? 4).mapTo[Int]

val fibanocciNumber = Await.result(future, 10 seconds)
val res = Await.result(fut, 10 seconds)
println(fibanocciNumber)
println(res)
}