package com.metrogroup.actors

import scala.concurrent.Await
import scala.concurrent.Future
import scala.concurrent.duration._
import akka.util.Timeout
import scala.concurrent.ExecutionContext.Implicits.global
import scala.util.Failure
import scala.util.Success
import scala.concurrent._

object Future2 extends App {
// implicit val baseTime = System.currentTimeMillis()
 
 def sum(a: Int, b: Int) = Future {
   a+b
 }
 
 // 2 - create a Future
val f = Future {
 // println("Future start")
//Thread.sleep(500)
1 + 1
}

val f2 = Future{
  34
}

for{
  x <- f
  y <- f2
}yield {println(x+y);x+y}

println("****************** " +f2.map(ele=> ele))


val promise = Promise[Int]()
val future = promise.future

future.onComplete{
  case Success(x) => println(x)
  case Failure(ex) => println(ex)
}

val producer = new Thread(() => {
  println("Producer")
  promise.success(42)
   Thread.sleep(500)
  // promise.success(56)
})

producer.start()

// 3 - this is blocking (blocking is bad)
/*val result = Await.result(f, 1 second)
println(result)*/
//println("Start")
 sum(1, 2).onComplete{
   case Success(x) => println(x)
   case Failure(ex) =>
 }
Thread.sleep(1000)





def something()={
    println("calling something....")
    1
  }

def callByValue(x: Int) = {
    println("x1 value is: " + x)
    println("x2 value is: " + x)
  }


def callByName(x: => Int)={
  println("x1 value is: " + x)
  println("x2 value is: " + x)
}

callByValue(something)
callByName(something)
}