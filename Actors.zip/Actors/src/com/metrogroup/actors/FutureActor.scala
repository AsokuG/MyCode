package com.metrogroup.actors

import akka.actor.Actor
import scala.concurrent.duration._ 
import scala.concurrent.{Await, Future} 
import akka.actor.ActorSystem
import akka.actor.Props

class FutureActor extends Actor {
 import context.dispatcher 
  override def receive: Receive = {
    case (a: Int, b: Int) => val f = Future(a+b)
   println( (Await.result(f, 10 seconds)))
   println(Await.ready(f, 10 seconds))
  }
  
}

object FutureInsideActor extends App {
 implicit val system = ActorSystem("Hello-Actor")
 val futureActor = system.actorOf(Props[FutureActor])
 futureActor ! 10//(10, 20)
// futureActor ! 10
}