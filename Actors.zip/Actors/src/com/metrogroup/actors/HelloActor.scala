package com.metrogroup.actors

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props

class HelloActor extends Actor {
  self ! "hello Ashok"
  val system = context.system
  println(system.name)
  println(self.path)

 override def receive = {
    
    case msg: String => println(s"Hi, ${msg}")
    case _ => println("unable to process this message")
  }
    
}

object Main extends App {
 val system = ActorSystem("HelloSystem")
 val helloActor = system.actorOf(Props[HelloActor], name = "HelloActor")
/* helloActor ! "hello"
 helloActor ! "something"
 helloActor ! 1
println("path: "+helloActor.path)*/
 system.actorSelection("/user/HelloActor") ! "from actorSelection"
 
 val defaultDispatcherConfig = system.settings.config.getConfig("akka.actor.default-dispatcher")
println(s"akka.actor.default-dispatcher = $defaultDispatcherConfig")


}