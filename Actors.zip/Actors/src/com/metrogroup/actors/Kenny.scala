package com.metrogroup.actors

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props

class Kenny extends Actor {
  println("entered into krnny constructor")
  override def preStart() {println("kenny: preStart")}
  override def postStop() {println("kenny: postStop")}
  override def preRestart(reason: Throwable, message: Option[Any]) {
    println("kenny: preRestart")
    println(s" MESSAGE: ${message.getOrElse("")}")
    println(s" REASON: ${reason.getMessage}")
    super.preRestart(reason, message)
  }
  override def postRestart(reason: Throwable) {
    println("kenny: postRestart")
    println(s" REASON: ${reason.getMessage}")
    super.postRestart(reason)
  }

  def receive(): Receive = {
    case ForceRestart => throw new Exception("Boom!")
    case _            => println("Kenny received a message")
  }

}

case object ForceRestart


object LifeCycleDemo extends App{
 val system = ActorSystem("LifecycleSystem")
 val kenny = system.actorOf(Props[Kenny], "kenny")
 println("Kenny sent a message")
 kenny ! "hello"
 Thread.sleep(1000)
 
 println("make kenny restart")
 kenny ! ForceRestart
 Thread.sleep(1000)
 
println("stopping kenny")
system.stop(kenny)
println("shutting down system")
system.shutdown
}