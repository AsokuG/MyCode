package com.metrogroup.actors

import akka.actor.Actor
import akka.actor.ActorLogging
import akka.actor.ActorSystem
import akka.actor.Props

class LoggingActor extends Actor with ActorLogging {
 override def receive: Receive = {
   case (a: Int, b: Int) => log.info(s"sum of $a and $b is ${a + b}")
   case msg => log.warning(s"i don't know what are you talking about : $msg")
 } 
}

object Logging extends App{
 val actorSystem = ActorSystem("ActorSystem")
 val logActor = actorSystem.actorOf(Props[LoggingActor], "LoggingActor")
 logActor ! (10, 20) 
 logActor ! "Hello"
 actorSystem.terminate()
}