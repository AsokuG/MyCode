package com.metrogroup.actors

import akka.actor.Actor
import akka.actor.ActorLogging

class MsgEchoActor extends Actor with ActorLogging {
  
  override def receive: Receive = {
    case message =>
             Thread.sleep(10)
             log.info("Received Message {} in Actor {}", message, self.path.name) 
  }
  
}