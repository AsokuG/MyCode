package com.metrogroup.actors

import akka.actor.Actor

class MyActor extends Actor {
  
  /*val log = Logging

  override def preStart() {
     log.debug("Starting")
  }
  
  override def preRestart(reason: Throwable, message: Option[Any]) {
 log.error(reason, "Restarting due to [{}] when processing [{}]",
      reason.getMessage, message.getOrElse(""))
  }*/
  
  override def receive: Receive = {
    case "test" => //log.info("Received test")
    case x => // log.warning("Received unknown message: {}", x)
  }
  
}