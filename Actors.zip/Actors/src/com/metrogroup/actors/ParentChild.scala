package com.metrogroup.actors

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props

case object CreateChild
case class Greet(msg: String)

class ParentChild {
  
}

class Child extends Actor {
  override def receive: Receive = {
    case Greet(msg: String) => println(s"My parent actor ${self.path.parent} greeted me${self.path} ${msg}")
  }
}

class Parent extends Actor {
  override def receive: Receive = {
    case CreateChild => 
     val childActor = context.actorOf(Props[Child], name="childActor")
     println("Hello")
     childActor ! Greet("Hello, My child")
  }
}

object ParentChild extends App {
  val actorSystem = ActorSystem("ashok")
  val parentActor = actorSystem.actorOf(Props[Parent], name="parentActor")
  parentActor ! CreateChild
}