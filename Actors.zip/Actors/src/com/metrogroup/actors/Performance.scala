package com.metrogroup.actors

import akka.actor.ActorSystem
import akka.actor.Props
import akka.routing.RoundRobinPool

object Performance extends App {
  
 val actorSystem = ActorSystem("mainsystem")
 val processActor = actorSystem.actorOf(Props[Processing], "ProcessActor")
 val roundRobinRouter = actorSystem.actorOf(Props[Processing].withRouter(RoundRobinPool(5)), name = "myRoundRobinRouterActor")
 println("starting time is:"+ System.currentTimeMillis())
 1 to 100 foreach{
   i => processActor ! i
 }
 println("ending time is:"+ System.currentTimeMillis()) 
}