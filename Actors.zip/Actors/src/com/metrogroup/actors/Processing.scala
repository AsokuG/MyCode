package com.metrogroup.actors

import akka.actor.Actor

class Processing extends Actor {
    
  override def receive: Receive = {
    case num: Int => println(s"processing num is ${num}")
    case _ => //
  }
  
}