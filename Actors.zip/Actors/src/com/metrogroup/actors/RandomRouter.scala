package com.metrogroup.actors

import akka.actor.ActorSystem
import akka.actor.Props
import akka.routing.RandomPool

object RandomRouter extends App {
 val actorSystem = ActorSystem("RandomRouterExample")
// val randomRouter = actorSystem.actorOf(Props[MsgEchoActor].withRouter(RandomPool(5)), name = "myRandomRouterActor")
 val randomRouter = actorSystem.actorOf(RandomPool(5).props(Props[MsgEchoActor]))
  1 to 10 foreach {
      i => randomRouter ! i
} 
 actorSystem.awaitTermination()
}