package com.metrogroup.actors

import akka.actor.Actor
import akka.routing.DefaultResizer
import akka.actor.ActorSystem
import akka.actor.Props
import akka.routing.RoundRobinPool
import akka.actor.PoisonPill
import akka.routing.Broadcast

 case object Load 
class ResizablePoolActor extends Actor {
  override def receive: Receive = {
    case Load     => println("Handing loads of requests")
    case num: Int => println(s"$num ${self.path.name}")
  }

  override def postStop(): Unit = {
    println("all routees are killed by user")
  }
}

object ResizablePoolTest extends App{
  val system = ActorSystem("Hello-Akka")
  /*val resizer = DefaultResizer(lowerBound = 2,  upperBound = 8)
  val router = system.actorOf(RoundRobinPool(5,  Some(resizer)).props(Props[ResizablePoolActor]))*/

  val resizer = DefaultResizer(lowerBound = 1, upperBound = 4)
  val router3 = system.actorOf(Props[ResizablePoolActor].withRouter(RoundRobinPool(5, resizer = Some(resizer))))

  1 to 1000 foreach {
    i => router3 ! i
  }
  router3 ! Broadcast(PoisonPill)
}