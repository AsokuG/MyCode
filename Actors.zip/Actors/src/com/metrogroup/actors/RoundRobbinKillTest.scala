package com.metrogroup.actors

import scala.concurrent.duration._

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.PoisonPill
import akka.actor.Props
import akka.routing.Broadcast
import akka.routing.RoundRobinPool
import akka.util.Timeout
import akka.pattern.ask
import scala.util.{Success, Failure}
import akka.routing.Router
import akka.routing.RoundRobinRoutingLogic

class TestActor extends Actor {

  override def receive: Receive = {
    case i: Int => {println(s"processed number: ${i} ${context.self.path}")
  sender ! "Success"   
    }
    case _ =>
  }
override def postStop()  = {
  println("All routees are killed by user")
}
}

object RoundRobbinKillTest  extends App {
  implicit val timeout = Timeout(1 seconds)
  val system = ActorSystem("MainSystem")
  implicit val ec = system.dispatcher
  var count = 0
  val roundRobinRouter = system.actorOf(RoundRobinPool(5).props(Props[TestActor]))
 // val router = Router(RoundRobinRoutingLogic)
  for (i <- 1 to 100) {
    val res = (roundRobinRouter ? i).mapTo[String]
    res onComplete {
      case Success(x) =>
        count = count + 1; println("done: " + x + count)
      case Failure(f) => println("An error has occurred: " + f.getMessage)
    }
  }
  roundRobinRouter ! Broadcast(PoisonPill)

}