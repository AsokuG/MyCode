package com.metrogroup.actors

import akka.actor.ActorSystem
import akka.actor.Props
import akka.routing.ScatterGatherFirstCompletedPool
import scala.concurrent.duration._
import akka.util.Timeout
import scala.concurrent.Await
import akka.pattern.ask

object ScatterGatherFirstCompletedRouter extends App {
 val actorSystem =  ActorSystem("SGFCRouterExample")
 val scatterGatherFirstCompletedRouter = actorSystem.actorOf(Props[RandomTimeActor].withRouter(
ScatterGatherFirstCompletedPool(nrOfInstances = 5, within = 5 seconds)), name = "mySGFCRouterActor")
//actorSystem.actorOf(ScatterGatherFirstCompletedPool(5, within = 5 seconds).props (Props[RandomTimeActor]))
implicit val timeout = Timeout(5 seconds)
    val futureResult = scatterGatherFirstCompletedRouter ? "message"
    val result = Await.result(futureResult, timeout.duration)
System.out.println(result)

  actorSystem.awaitTermination()
}