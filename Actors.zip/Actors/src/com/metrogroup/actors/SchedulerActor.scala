package com.metrogroup.actors

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props
import scala.concurrent.duration.Duration
import java.util.concurrent.TimeUnit


class Schedule extends Actor {
  override def receive: Receive = {
    case name: String => println(s"Received number is: $name")
  }
}

object SchedulerActor extends App {
  
 val actorSystem = ActorSystem("System")
 implicit val ec = actorSystem.dispatcher
val sched = actorSystem.actorOf(Props[Schedule], "Schedule")
 actorSystem.scheduler.schedule(Duration.create(100, TimeUnit.SECONDS), (Duration.create(100, TimeUnit.MILLISECONDS)), sched, "Hello")
  
}