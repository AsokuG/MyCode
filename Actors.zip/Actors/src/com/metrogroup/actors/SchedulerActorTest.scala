package com.metrogroup.actors

import akka.actor.ActorSystem
import akka.actor.Actor
import scala.concurrent.duration._
import akka.actor.Props

case object Tick

class RandomIntActor extends Actor{
 val random = scala.util.Random 
 override def receive: Receive = {
   case Tick => {
  val num1 =   random.nextInt(10)
  val num2 = random.nextInt(5)
  println(s"multiplication of two is ${num1 * num2}")
   }
 }
}

object SchedulerActorTest extends App {
 val actorSystem = ActorSystem("ActorSystem") 
 import actorSystem.dispatcher
 val randomActor = actorSystem.actorOf(Props[RandomIntActor])
// actorSystem.scheduler.scheduleOnce(10 seconds, randomActor, Tick)
val rec = actorSystem.scheduler.schedule(10 seconds, 5 seconds, randomActor, Tick)
}