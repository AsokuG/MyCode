package com.metrogroup.actors

import akka.actor.Actor
import akka.actor.ActorRef
import akka.actor.Props
import akka.actor.ActorSystem

case object Send
case object CreateChildObj
case class DoubleValue(x: Int)
case class Response(x: Int)
class SendMesagesToChilds {

}
class DoubleActor extends Actor {
  override def receive: Receive = {
    case DoubleValue(number) =>
      println(s"${self.path.name} got the number $number")
      sender ! Response(number * 2)
  }
}

class ParentActor extends Actor {
  val random = new scala.util.Random
  var childs = scala.collection.mutable.ListBuffer[ActorRef]()
  override def receive: Receive = {
    case CreateChildObj => childs ++= List(context.actorOf(Props[DoubleActor]))
    case Send =>
      println(s"Sending messages to child")
      childs.zipWithIndex map {
        case (child, value) => child ! DoubleValue(random.nextInt(10))
      }
    case Response(x) => println(s"parent response from child ${sender.path.name} is ${x}")
  }
}
object SendMesagesToChilds extends App {
  val actorSystem = ActorSystem("ashok")
  val parentActor = actorSystem.actorOf(Props[ParentActor], name = "parentactor")
  parentActor ! CreateChildObj
  parentActor ! CreateChildObj
  parentActor ! CreateChildObj
  parentActor ! Send
}