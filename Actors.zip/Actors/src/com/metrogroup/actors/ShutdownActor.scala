package com.metrogroup.actors

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props
import akka.actor.PoisonPill

case object Stop
/*They are two ways to stop an actor
 * Using PoisonPill
 * Using context.self(actorRef)
 * PoisonPill is the inbuilt message
 * it is processed only after
 * all the messages that were already queued in the mailbox*/
class ShutdownActor extends Actor {

  override def receive: Receive = {
    case msg: String => println(s"$msg")
    case Stop        => context.stop(self)
  }

}

object ShutdownActorApp extends App {
  val actorSystem = ActorSystem("ashok")
  val shutdownActor1 = actorSystem.actorOf(Props[ShutdownActor], name = "shutdownActor1")

  shutdownActor1 ! "hello1"
  shutdownActor1 ! Kill
  shutdownActor1 ! PoisonPill
  shutdownActor1 ! "Are you there?"
/*  val shutdownActor2 = actorSystem.actorOf( Props[ShutdownActor], "shutdownActor2")
  shutdownActor2 ! "hello2"
  shutdownActor2 ! Stop
  shutdownActor2 ! "Are you there?"
  val shutdownActor3 = actorSystem.actorOf(Props[ShutdownActor], "shutdownActor3")
  shutdownActor3 ! "hello3"
  shutdownActor3 ! PoisonPill
  shutdownActor3 ! "Are you there?"*/
}