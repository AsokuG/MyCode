package com.metrogroup.actors

import akka.actor.ActorSystem
import akka.actor.Props
import akka.routing.SmallestMailboxPool
import akka.routing.Broadcast
import akka.actor.PoisonPill

object SmallestMailboxRouter extends App {
  val actorSystem =  ActorSystem("SmallestMailBoxRouterExample")
  val smallestMailBoxRouter = actorSystem.actorOf(Props[MsgEchoActor].withRouter(SmallestMailboxPool(5)), name = "mySmallestMailBoxRouterActor")
  actorSystem.actorOf(SmallestMailboxPool(5).props  (Props[MsgEchoActor])) 
  1 to 10 foreach {
      i => smallestMailBoxRouter ! i
}
  smallestMailBoxRouter ! Broadcast(PoisonPill)
}