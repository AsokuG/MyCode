package com.metrogroup.actors

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.routing.RandomPool
import akka.actor.Props
import akka.routing.Broadcast
import akka.actor.PoisonPill

case object Handle

class SpeciallyHandled extends Actor{
  override def receive: Receive = {
    case Handle => println(s"${self.path.name} say hello")
  }
  override def postStop(): Unit = {
    println("All routees are killed by manally....")
  }
}

object SpeciallyHandledTest extends App{
 val actorSystem = ActorSystem("ActorSystem")
 val roter = actorSystem.actorOf(RandomPool(5).props (Props[SpeciallyHandled]))
 ////roter ! Broadcast(Handle)
 //roter ! Broadcast(PoisonPill)
 roter ! Handle
  
}