package com.metrogroup.actors

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props

/*here we defining the state 
 * behaviour of an actor not created yet*/
class SummingActor extends Actor {
  // state inside the actor
  var sum = 0
  
  // behaviour which is applied to state
  /*it receives message 
   * pick a underlying java thread from threadpool
   * The actors never block your current thread of execution
   * Actors are  asynchronous by nature*/
override def  receive: Receive = {
    // receive integer message
    case x: Int => sum +=x; println(s"after applying behaviour on state is ${sum}")
    // receive any other message except integer
    case _ => println("I don't know what you are talking")
  }
}


object BehaviourAndState extends App {
/*here ActorSystem is created 
  * it's a heavy weight container home for all actors
  *  Akka is a message driven framework*/
 val actorSystem = ActorSystem("ashok")
 println(s"ActorSystem name ${actorSystem}")
 //here summing actor is created & message is passed
 val summingActor = actorSystem.actorOf(Props[SummingActor], name="summingActor")
 println(summingActor)
 println(s"User created Actor name is ${summingActor}")
 // sending message to an actor is the first step
/* while(true){
   Thread.sleep(300)
   summingActor ! 1
 }*/
 // tell(!) tell-and-forget pattern 
  summingActor ! 1
}