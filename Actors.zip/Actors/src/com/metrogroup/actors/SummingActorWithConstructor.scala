package com.metrogroup.actors

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props

class SummingActorWithConstructor(initialValue: Int) extends Actor {
  var sum: Int = 0
  
  override def receive: Receive = {
    case x: Int => sum = sum+initialValue+x; println(s"after applying behaviour is ${sum}")
    case _ => println("I don't know what your talking")
  }
  
}

object BeahaviourAndSummingWithCon extends App {
  val actorSystem = ActorSystem("ashok")
  val summingWithActor = actorSystem.actorOf(Props(classOf[SummingActorWithConstructor], 10), name="summingWithActor")
  summingWithActor ! 19
}