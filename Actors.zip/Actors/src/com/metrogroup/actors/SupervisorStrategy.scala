package com.metrogroup.actors

import scala.concurrent.duration._

import akka.actor.Actor
import akka.actor.OneForOneStrategy
import akka.actor.SupervisorStrategy.Escalate
import akka.actor.SupervisorStrategy.Restart
import akka.actor.SupervisorStrategy.Resume
import akka.actor.Props
import akka.actor.ActorSystem
import akka.actor.AllForOneStrategy

class Printer extends Actor {
  var y: Int=0
  override def preRestart(reason: Throwable, message: Option[Any]): Unit = {
    println("I'm restarting due to Arthmetic Exception")
  }

  override def receive: Receive = {
    case msg: String => y+=1;println(s"Received message is $msg "+ y)
    case msg: Int    => 1 / 0
  }
}

class IntAdder extends Actor {
  var x: Int = 0
   override def preRestart(reason: Throwable, message: Option[Any]): Unit = {
    println("I'm Intadder restarting due to Arthmetic Exception")
  }
  override def receive: Receive = {
    case msg: Int =>
      x = x + msg; println(s"Received message is $x")
    case msg: String => throw new IllegalArgumentException
  }

  override def postStop = {
    println("IntAdder: I'm getting  stop because i got the string message")
  }
}

class SupervisorStrategy extends Actor {
  import akka.actor.SupervisorStrategy.Stop
  override val supervisorStrategy = AllForOneStrategy(
    maxNrOfRetries = 10,
    withinTimeRange = 1 minute) {
    case _: ArithmeticException      => Restart
    case _: NullPointerException     => Resume
    case _: IllegalArgumentException => Stop
    case _: Exception                => Escalate
  }

  val printer = context.actorOf(Props[Printer], name = "printer")
  val intAdder = context.actorOf(Props[IntAdder], name = "intadder")

  override def receive: Receive = {
    case "start" =>
      printer ! "Hello Printer"
      printer ! 10
      printer ! "Restarted Successfully"
      printer ! 10
     /* intAdder ! 10
      intAdder ! "Hello int adder"*/
  }
}

object SupervisorStrategyApp extends App {
  val system = ActorSystem("SupervisorStrategy")
  val supervisorStrategy = system.actorOf(Props[SupervisorStrategy], name = "supervisorStrategy")
  supervisorStrategy ! "start"
}
