package com.metrogroup.actors



import akka.actor.Actor
import akka.actor.ActorSystem
import akka.util.Timeout
import akka.routing.TailChoppingPool  
import akka.actor.Props
import scala.concurrent.Await
import akka.pattern.ask
import scala.concurrent.duration 
    
/*class TailChoppingPoolAActor extends Actor{
  override def receive = {
    case msg: String => sender ! "I say hello back to you"
    case _ => println(s" I don't understand the message")
  }
}

object TailChoppingPool extends App {
    implicit val timeout = Timeout(10 seconds)  
  val actorSystem = ActorSystem("system")
  val router = actorSystem.actorOf(TailChoppingPool(5, 
           within = 10.seconds,interval = 20.millis).props(Props[TailChoppingPoolAActor]))
  println(Await.result((router ? "hello").mapTo[String], 10 seconds))

}*/