package com.metrogroup.actors

 import akka.actor.{Actor, ActorSystem, Props}  
 import akka.pattern.ask  
 import akka.routing.TailChoppingPool  
 import akka.util.Timeout 
 import scala.concurrent.Await 
 import scala.concurrent.duration._


class TailChoppingPoolActor extends Actor {
  override def receive: Receive = {
    case message: String => println("delay....."); sender! "hello i'm returning"
  }
}

object TailChoppingPoolTest extends App {
 implicit val timeout = Timeout(10 seconds)
 val actorSystem = ActorSystem("ActorSystem")
 val router = actorSystem.actorOf(TailChoppingPool(5, within = 10 seconds, interval = 10 millis).props (Props[TailChoppingPoolActor]))
 
//val res = router ? "Hi"

//res.mapTo[String]
 
/* 1 to 10 foreach {
 i => val res = Await.result((router ? "Hi").mapTo[String], 10 seconds)
  println(res)
  
 }*/ 
 
  val res = Await.result((router ? "Hi").mapTo[String], 10 seconds)
  println(res)
}