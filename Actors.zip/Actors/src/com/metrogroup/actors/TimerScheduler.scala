package com.metrogroup.actors

import akka.actor.ActorLogging
import akka.actor.Actor

object TimerScheduler extends App{
  
 /*  class TimerBasedHeartbeatActor extends Actor with ActorLogging {
     
   }*/
  
}