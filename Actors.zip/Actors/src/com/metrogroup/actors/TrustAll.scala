package com.metrogroup.actors

import javax.net.ssl.X509TrustManager
import java.security.cert.X509Certificate
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.SSLSession
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import scala.io.Source

object TrustAll extends X509TrustManager {

  val getAcceptedIssuers = null

  def checkClientTrusted(x509Certificates: Array[X509Certificate], s: String) = {}

  def checkServerTrusted(x509Certificates: Array[X509Certificate], s: String) = {}
  
}

// Verifies all host names by simply returning true.
object VerifiesAllHostNames extends HostnameVerifier {
  def verify(s: String, sslSession: SSLSession) = true
}

object TestCertificate extends App {
  
   // SSL Context initialization and configuration
  val sslContext = SSLContext.getInstance("SSL")
  sslContext.init(null, Array(TrustAll), new java.security.SecureRandom())
  HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory)
  HttpsURLConnection.setDefaultHostnameVerifier(VerifiesAllHostNames)
 
    println("*****************************")
    val html = Source.fromURL("https://movie.stockservice.metrosystems.net/cache?country=DE&salesLine=MCC&locationId=48&articleNo=592133&variant=1&bundleNo=1")
    println(html.mkString)
    
  
}