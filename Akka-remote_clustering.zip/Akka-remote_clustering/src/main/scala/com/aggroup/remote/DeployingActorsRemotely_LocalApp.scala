package com.aggroup.remote

import akka.actor.{ActorSystem, AddressFromURIString, Deploy, Props}
import akka.remote.RemoteScope
import com.typesafe.config.ConfigFactory

object DeployingActorsRemotely_LocalApp extends App {
  val system =  ActorSystem("LocalActorSystem", ConfigFactory.load("part2_remoting/deployingActorsRemotely.conf").getConfig("localApp"))
val simpleActor = system.actorOf(Props[SimpleActor], "remoteActor")
  simpleActor ! "hello, remote actor!"
  println(simpleActor)

 val remoteSystemAddress = AddressFromURIString("akka://RemoteActorSystem@localhost:2552")
 val remoteDeployActor = system.actorOf(Props[SimpleActor].withDeploy(
    Deploy(scope = RemoteScope(remoteSystemAddress))
  ))

  remoteDeployActor ! "hi, remotely deployed actor!"

}

object DeployingActorsRemotely_RemoteApp extends App {

  val system =  ActorSystem("RemoteActorSystem", ConfigFactory.load("part2_remoting/deployingActorsRemotely.conf").getConfig("remoteApp"))
}
