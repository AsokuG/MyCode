package com.aggroup.remote

import akka.actor.{Actor, ActorLogging}

class SimpleActor extends Actor with ActorLogging {

  def receive: Receive = {
    case msg => log.info(s"Receive $msg from ${sender()}")
  }

}
