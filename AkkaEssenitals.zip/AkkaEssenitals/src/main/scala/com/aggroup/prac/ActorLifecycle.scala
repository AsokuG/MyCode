package com.aggroup.prac

import akka.actor.{Actor, ActorLogging, ActorSystem, Props}
import com.aggroup.prac.StartingStopingActor.Parent.StartChild

object ActorLifecycle extends App {

  case object StartChild

  class LifecycleActor extends Actor with ActorLogging {
    override def preStart(): Unit = log.info("I am starting")

    override def postStop(): Unit = log.info("I have stopped")

    override def receive: Receive = {
      case StartChild => context.actorOf(Props[LifecycleActor], "child")
    }
  }

  val system = ActorSystem("LifecycleActorDemo")

  // val parent = system.actorOf(Props[LifecycleActor], "parent")

  // parent ! StartChild

  case object Failed

  case object FailedChild

  case object Check

  case object CheckChild

  class Parent extends Actor {

    val child = context.actorOf(Props[Child], "supervisorChild")


    override def receive: Receive = {
      case Failed => child ! FailedChild
      case Check => child ! CheckChild
    }

  }

  class Child extends Actor with ActorLogging {
    override def preStart(): Unit = log.info("supervised child started")

    override def postStop(): Unit = log.info("supervised child stopped")

    override def preRestart(reason: Throwable, message: Option[Any]): Unit = {
      super.preRestart(reason,message)
      log.info(s"supervised actor restarting because of ${reason.getMessage}")
    }

    override def postRestart(reason: Throwable): Unit =
      log.info("supervised actor restarted")

    override def receive: Receive = {
      case FailedChild =>
        log.warning("child will fail now")
        throw new RuntimeException("I failed")
      case CheckChild => log.info("alive and kicking")
    }
  }

 val parent = system.actorOf(Props[Parent], "Parent")
  parent ! Failed
  parent ! Check

}
