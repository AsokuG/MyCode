package com.aggroup.prac

import akka.actor.{Actor, ActorLogging, ActorSystem, Props}
import akka.event.Logging

object ActorLoggingDemo extends App {

  class SimpleActorWithExplicitLogger extends Actor {
   val logger = Logging(context.system, this)

    override def receive: Receive = {
      case message => logger.info(message.toString)
    }
  }

 val actorSystem = ActorSystem("actorSystem")

 val simpleActorWithExplicitLogger = actorSystem.actorOf(Props[SimpleActorWithExplicitLogger], "simpleactor")

  simpleActorWithExplicitLogger ! "Logging a simple message"

  class ActorWithLogging extends Actor with ActorLogging {

    override def receive: Receive = {
      case (a, b) => log.info("two received numbers is {}, {}", a, b)
      case message => log.info(message.toString)
        log.debug(message.toString)
        log.error(message.toString)
        log.warning(message.toString)
    }
  }

val actorWithLogging =  actorSystem.actorOf(Props[ActorWithLogging], "actorlogging")

  actorWithLogging ! "Logging a simple message with ActorLogging trait"

  actorWithLogging ! (6, 9)

}
