package com.aggroup.prac

import akka.actor.{Actor, ActorLogging, ActorSystem, Props}
import akka.testkit.{ImplicitSender, TestKit}
import org.scalatest.{BeforeAndAfterAll, WordSpecLike}
import akka.pattern.ask
import akka.util.Timeout
import akka.pattern.pipe
import com.aggroup.prac.AskSpec.AuthManager.{AUTH_FAILURE_NOT_FOUND, AUTH_FAILURE_PASSWORD_INCORRECT}

import scala.concurrent.ExecutionContext
import scala.concurrent.duration._
import scala.util.{Failure, Success}

class AskSpec extends TestKit(ActorSystem("AskSpec"))
  with ImplicitSender
  with WordSpecLike
  with BeforeAndAfterAll {
  override def afterAll(): Unit = {
    TestKit.shutdownActorSystem(system)
  }

  import AskSpec._

  "An Authenticator" should {
    authenticatedTestSuite(Props[AuthManager])

  }

  "An piped Authenticator" should {
    authenticatedTestSuite(Props[PipedAuthManager])

  }

  def authenticatedTestSuite(props: Props) = {
    import AuthManager._
    "fail to authenticate a non-registered user" in {
      val authManager = system.actorOf(props)
      authManager ! Authenticate("Ashok", "rtjvm")
      expectMsg(AuthFailure(AUTH_FAILURE_NOT_FOUND))
    }

    "failed to authenticate if invalid password" in {
      val authManager = system.actorOf(props)
      authManager ! RegisterUser("Ashok", "rtjvm")
      authManager ! Authenticate("Ashok", "rttjvm")
      expectMsg(AuthFailure(AUTH_FAILURE_PASSWORD_INCORRECT))
    }

  "Successful authentication" in {
    val authManager = system.actorOf(props)
    authManager ! RegisterUser("Ashok", "rtjvm")
    authManager ! Authenticate("Ashok", "rtjvm")
    expectMsg(AuthSuccess)
  }

  }
}

object AskSpec {

  case class Read(key: String)

  case class Write(key: String, value: String)

  class KVActor extends Actor with ActorLogging {
    override def receive: Receive = online(Map())

    def online(kv: Map[String, String]): Receive = {
      case Read(key) => log.info(s"try to read the content $key")
        sender() ! kv.get(key)
      case Write(key, value) => log.info(s"writing value $value for the key $key")
        context.become(online(kv + (key -> value)))
    }
  }

  case class RegisterUser(username: String, password: String)

  case class Authenticate(username: String, password: String)

  case class AuthFailure(message: String)

  case object AuthSuccess

  object AuthManager {
    val AUTH_FAILURE_NOT_FOUND = "user name not found"
    val AUTH_FAILURE_PASSWORD_INCORRECT = "password incorrect"
    val AUTH_FAILURE_SYSTEM = "system error"
  }

  class AuthManager extends Actor with ActorLogging {

    import AuthManager._

    protected val authDB = context.actorOf(Props[KVActor])
    implicit val timeout: Timeout = Timeout(1 second)
    implicit val executionContext: ExecutionContext = context.dispatcher

    override def receive: Receive = {
      case RegisterUser(username, password) => authDB ! Write(username, password)
      case Authenticate(username, password) => handleAuthentication(username, password)
    }

    def handleAuthentication(username: String, password: String) = {
      val originalSender = sender()
      val future = authDB ? Read(username)
      future.onComplete {
        case Success(None) => originalSender ! AuthFailure(AUTH_FAILURE_NOT_FOUND)
        case Success(Some(dbPassword)) =>
          if (dbPassword == password) originalSender ! AuthSuccess
          else originalSender ! AuthFailure(AUTH_FAILURE_PASSWORD_INCORRECT)
        case Failure(_) => originalSender ! AuthFailure(AUTH_FAILURE_SYSTEM)
      }

    }
  }

  class PipedAuthManager extends AuthManager {
    import AuthManager._
    override def handleAuthentication(username: String, password: String) = {
    val future = authDB ? Read(username)
     val futurePassword = future.mapTo[Option[String]]
     val responseFuture = futurePassword.map{
        case None => AuthFailure(AUTH_FAILURE_NOT_FOUND)
        case Some(dbPassword) => if(dbPassword ==  password) AuthSuccess
        else AuthFailure(AUTH_FAILURE_PASSWORD_INCORRECT)
      }

      responseFuture.pipeTo(sender())
    }
  }

}
