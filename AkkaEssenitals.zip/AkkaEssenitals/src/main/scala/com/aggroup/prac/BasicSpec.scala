package com.aggroup.prac

import akka.actor.{Actor, ActorSystem, Props}
import akka.testkit.TestActors.BlackholeActor
import akka.testkit.{ImplicitSender, TestKit}
import com.aggroup.prac.BasicSpec.SimpleActor
import org.scalatest.{BeforeAndAfterAll, WordSpecLike}

import scala.concurrent.duration._
import scala.util.Random


class BasicSpec extends TestKit(ActorSystem("BasicSpec"))
  with ImplicitSender
  with WordSpecLike
  with BeforeAndAfterAll {

  override def afterAll(): Unit = {

    TestKit.shutdownActorSystem(system)

  }

  import BasicSpec._

  "A simple actor" should {
    "send back the same message " in {
      val echoActor = system.actorOf(Props[SimpleActor])
      val message = "hello, test"
      echoActor ! message

      expectMsg(message)
    }

  }

  "A blackhole actor" should {
    "send back some message" in {
      val blackhole = system.actorOf(Props[Blackhole])
      val message = "hello, test"
      blackhole ! message

      expectNoMessage(1 second)
    }
  }

  "A labTest actor" should {
    val labTestActor = system.actorOf(Props[LabTestActor])
    "return a string in uppercase"in{
      labTestActor ! "I love akka"
      val reply = expectMsgType[String]
      assert(reply=="I LOVE AKKA")
    }

   "return a greeting message" in{
     labTestActor ! "greeting"
     expectMsgAnyOf("hi", "hello")
    }

    "return a tech message"in{
      labTestActor ! "favoriteTech"
      expectMsgAllOf("scala", "akka")
    }

    "reply with a cool tech message in a different way" in {
      labTestActor ! "favoriteTech"
      receiveN(2)
    }
   "reply with a cool tech message in a fancy way" in {
     labTestActor ! "favoriteTech"
     expectMsgPF() {
       case "Scala" => // only care that the PF is defined
       case "Akka" =>
     }
    }
  }


}

object BasicSpec {

  class SimpleActor extends Actor {
    override def receive: Receive = {
      case message => sender() ! message
    }
  }

  class Blackhole extends Actor {
    override def receive: Receive = Actor.emptyBehavior
  }

  class LabTestActor extends Actor {
   val random = new Random()
    override def receive: Receive = {
      case "greeting" => if(random.nextBoolean()) sender() ! "hi" else "hello"
      case "favoriteTech" =>
        sender() ! "Scala"
        sender() ! "Akka"
      case message: String => sender() ! message.toUpperCase()
    }
  }


}
