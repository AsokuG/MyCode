package com.aggroup.prac

import akka.actor.{Actor, ActorLogging, ActorSystem, Props}
import com.typesafe.config.ConfigFactory

object IntroAkkaConfig extends App {

  class SimpleLoggingActor extends Actor with ActorLogging {
    override def receive: Receive = {
      case message => log.info(message.toString)
    }
  }

  /**
    * 1 - inline configuration
    */
  val configString =
    """
      | akka {
      |   loglevel = "DEBUG"
      | }
    """.stripMargin

  val config = ConfigFactory.parseString(configString)
  val system = ActorSystem("ConfigurationDemo", ConfigFactory.load(config))

  val actor = system.actorOf(Props[SimpleLoggingActor])

  actor ! "A message to remember"

  /**
    * 2 - config file
    */


  val defaultConfigFileSystem = ActorSystem("DefaultConfigFileDemo")
  val simpleLoggingActor = defaultConfigFileSystem.actorOf(Props[SimpleLoggingActor])

  simpleLoggingActor ! "Hello"


  /**
    * 3 - separate config in the same file
    */

  val specialConfig = ConfigFactory.load().getConfig("mySpecialConfig")

  val actorSystem = ActorSystem("SpecialConfigFileDemo", specialConfig)

  val specialLoggingActor = actorSystem.actorOf(Props[SimpleLoggingActor])

  specialLoggingActor ! "Remember it's special configuration"

  /**
    * 4 - separate config in another file
    */

  val seperateConfig = ConfigFactory.load("secretFolder/secretConfiguration.conf")

  println(s"seperate config log level: ${seperateConfig.getString("akka.loglevel")}")

  /**
    * 5 - different file formats
    * JSON, Properties
    */


  val jsonConfig = ConfigFactory.load("json/jsonConfig.json")
  println(s"json config: ${jsonConfig.getString("aJsonProperty")}")
  println(s"json config: ${jsonConfig.getString("akka.loglevel")}")

  val actorJSONSystem = ActorSystem("JSONConfigDemo", jsonConfig)

  val simpleJSONLoggingActor = actorJSONSystem.actorOf(Props[SimpleLoggingActor])

  simpleJSONLoggingActor ! "Hello JSON"


  val propsConfig = ConfigFactory.load("props/propsConfiguration.properties")
  println(s"props config: ${propsConfig.getString("my.simpleProperty")}")
  println(s"props config: ${propsConfig.getString("akka.loglevel")}")

}
