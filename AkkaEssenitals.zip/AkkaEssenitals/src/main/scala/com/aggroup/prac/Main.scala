package com.aggroup.prac

import java.io.{PrintWriter, StringWriter}

import akka.actor.{Actor, ActorRef, ActorSystem, Props}

class MessageReciver extends Actor {
  def receive = {
    case s: String =>
      println(s"${Thread.currentThread()}|[${self.path}]|EchoActor: received message = $s")
  }

}

class MessageSender(messageReceiver: ActorRef) extends Actor {
  val messages = List("Hello Scala!", "Hello Akka!", "Hello Play")
  for (msg <- messages) {
    println(s"${Thread.currentThread()}|[${self.path}]|sending message $msg to $messageReceiver")
    messageReceiver ! msg
  }

  override def receive: Receive = Actor.emptyBehavior
}

object MessageSender {
  def props(messageReciver: ActorRef) = Props(new MessageSender(messageReciver))
}

object Main extends App {
  val system = ActorSystem("exampleSystem")
  try {
    val receiver = system.actorOf(Props[MessageReciver], "receiver")
    system.actorOf(MessageSender.props(receiver), "sender")
    Thread.sleep(3000)
  } catch {
    case t: Throwable => {
      val sw = new StringWriter()
      t.printStackTrace(new PrintWriter(sw))
      println(t.getMessage)
      println(sw)
    }
  }
  finally {
    system.terminate()
  }
}
