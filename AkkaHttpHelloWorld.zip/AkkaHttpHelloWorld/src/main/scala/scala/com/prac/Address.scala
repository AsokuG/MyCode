package scala.com.prac

import spray.json.RootJsonFormat
import spray.json.DefaultJsonProtocol._

case class Address(
                    pin:    Int,
                    street: String,
                    city:   String,
                    state:  String,
                  )

object Address {
  implicit val addressJsonFormat: RootJsonFormat[Address] = jsonFormat4(Address.apply)
}
