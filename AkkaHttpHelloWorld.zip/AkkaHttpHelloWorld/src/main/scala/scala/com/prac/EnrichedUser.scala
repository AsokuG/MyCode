package scala.com.prac

import spray.json.RootJsonFormat
import spray.json.DefaultJsonProtocol._

case class EnrichedUser(name: String,
                        age: Int,
                        address: Address)

object EnrichedUser {

  implicit val enrichedUserJsonFormat: RootJsonFormat[EnrichedUser] = jsonFormat3(EnrichedUser.apply)

}
