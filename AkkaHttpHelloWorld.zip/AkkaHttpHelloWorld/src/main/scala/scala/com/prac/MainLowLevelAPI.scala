package scala.com.prac


import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport._
import akka.http.scaladsl.marshalling.Marshal
import akka.http.scaladsl.model.HttpMethods.GET

import scala.concurrent.{ExecutionContext, Future}
// for HttpRequest, HttpResponse, Uri
import akka.http.scaladsl.model._
import akka.stream.{ActorMaterializer}

object MainLowLevelAPI {
def main(args: Array[String]): Unit = {
  implicit val system: ActorSystem = ActorSystem("MainLowLevelAPI")
  implicit val materializer: ActorMaterializer = ActorMaterializer()
  implicit val ec: ExecutionContext = system.dispatcher

  val requestHandler: HttpRequest => Future[HttpResponse] = {
    case HttpRequest(
    GET,
    Uri.Path("/"),
    _, // matches any headers
    _, // matches any HTTP entity (HTTP body)
    _  // matches any HTTP protocol
    ) => {
      val m = Marshal(User("Ashok Gangineni", 24))
      m.to[HttpResponse]
    }
  }

  Http().bindAndHandleAsync(requestHandler, "localhost", 8085)
  println(s"Server online at http://localhost:8085/")

    }
}
