package scala.com.prac

import spray.json.RootJsonFormat
import spray.json.DefaultJsonProtocol._

case class User(name: String, age: Int)

object User {
  // formats for unmarshalling and marshalling
  implicit val userJsonFormat: RootJsonFormat[User] = jsonFormat2(User.apply)
}
