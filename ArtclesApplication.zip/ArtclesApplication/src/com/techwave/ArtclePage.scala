package com.techwave

import org.apache.wicket.markup.html.WebPage
import org.apache.wicket.markup.html.form.TextField
import org.apache.wicket.model.Model
import org.apache.wicket.markup.html.form.TextArea
import org.apache.wicket.markup.html.form.Form
import org.apache.wicket.markup.html.panel.FeedbackPanel
import java.sql.DriverManager
import java.sql.Connection
import java.sql.PreparedStatement
import java.util.StringTokenizer
import java.sql.ResultSet
import java.sql.SQLException
import org.apache.wicket.markup.html.list.ListView
import org.apache.wicket.markup.html.list.ListItem
import org.apache.wicket.markup.html.basic.Label
import java.util.ArrayList
import org.apache.wicket.model.CompoundPropertyModel
import org.apache.wicket.markup.html.WebMarkupContainer
import org.apache.wicket.extensions.ajax.markup.html.modal.ModalWindow
import org.apache.wicket.ajax.markup.html.AjaxLink
import org.apache.wicket.ajax.AjaxRequestTarget
import com.techwave.DAO._
import org.apache.wicket.markup.repeater.data.DataView
import org.apache.wicket.markup.repeater.data.ListDataProvider
import org.apache.wicket.markup.repeater.Item
import org.apache.wicket.markup.html.navigation.paging.PagingNavigator
import org.apache.wicket.validation.validator.RangeValidator
import org.apache.wicket.validation.validator.MinimumValidator

class ArtclePage extends WebPage {

  val markupContainer = new WebMarkupContainer("markupContainer")

  markupContainer.setVisible(false)

  markupContainer.setOutputMarkupId(true)

  var query: String = "select *from zb_art_info where art_nr=?"

  query += " and end_dat>sysdate()"

  var list = new ArrayList[ArtclesInfo]()

  // add(new FeedbackPanel("feedback"))

  var artcleno = new TextField("Artclenumber", Model.of(""))
  
  var desc = new TextField("description", Model.of(""))

  artcleno.setRequired(true) //.add(new Validator())

  val form = new Form("useForm") {

    override def onSubmit() = {

      try {

        conn = new Connection_db().conect()

        var a = artcleno.getDefaultModelObjectAsString()

        var c = desc.getDefaultModelObjectAsString()

        list.clear()

        var st: StringTokenizer = new StringTokenizer(a, ",")

        while (st.hasMoreTokens()) {

          val b = st.nextToken().toInt

          if (c.length() != 0) {

            query = query + " and art_bez like '" + c + "'"

          } else {

            query
          }

          pst = conn.prepareStatement(query)

          pst.setInt(1, b)

          rs = pst.executeQuery()

          while (rs.next()) {

            markupContainer.setOutputMarkupId(true)

            markupContainer.setVisible(true)

            val artclesInfo = new ArtclesInfo(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getInt(5), rs.getDate(6), rs.getDate(7))

            list.add(artclesInfo)

          }

        }

      } catch {

        case e: SQLException => {

          println("SQLEXception " + e.printStackTrace())

        }

        case ex: ClassNotFoundException => {

          println("ClassNotFoundException")

        }

      } finally {

        if (conn != null) conn.close()

        if (pst != null) pst.close()

        if (rs != null) rs.close()
      }

    }
  }

  val listView = new DataView[ArtclesInfo]("listView", new ListDataProvider(list)) {

    def populateItem(item: Item[ArtclesInfo]) = {

      var artclesInfo = item.getModelObject().asInstanceOf[ArtclesInfo]

      item.setModel(new CompoundPropertyModel(artclesInfo))

      item.add(new Label("art_nr"))

      item.add(new Label("art_bez"))

      item.add(new Label("vari"))

      item.add(new Label("gebi_nr"))

      item.add(new Label("price"))

      item.add(new Label("start_date"))

      item.add(new Label("end_date"))

      item.add(new AjaxLink("link") {

        def onClick(target: AjaxRequestTarget) {

          setContent(target: AjaxRequestTarget, artclesInfo)

        }
      })
      
     

    }

  }

  listView.setItemsPerPage(30)
  //add(listView)
  val pagingNavigator = new PagingNavigator("pager", listView);

  //add(pagingNavigator)
  val modalWindow = new ModalWindow("modalWindow")

  def setContent(target: AjaxRequestTarget, artclesInfo: ArtclesInfo) = {

    val panel1 = new Panel1(modalWindow, artclesInfo, this)

    modalWindow.setInitialHeight(300)

    modalWindow.setInitialWidth(350)
    
    modalWindow.setResizable(false)
    
    modalWindow.setTitle("Artcle Information:")

    modalWindow.setContent(panel1)

    modalWindow.show(target)

  }

  add(modalWindow)

  def getString(): String = {

    "modalWindow"
  }
  markupContainer.add(listView)

  markupContainer.add(pagingNavigator)

  add(form)

  form.add(artcleno)

  form.add(desc)

  add(markupContainer)

}