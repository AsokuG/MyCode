package com.techwave

import org.apache.wicket.ajax.markup.html.AjaxLink
import org.apache.wicket.IClusterable


class ArtclesInfo(art_nr: Int, art_bez: String, vari: Int, gebi_nr: Int, var price: Int, start_date: java.util.Date, end_date: java.util.Date) extends IClusterable {

  def getArt_nr(): Int = {

    art_nr
  }

  def getArt_bez(): String = {

    art_bez
  }

  def getVari(): Int = {

    vari
  }

  def getGebi_nr(): Int = {

    gebi_nr
  }

  def getPrice(): Int = {

    price
  }

  def getStart_date(): java.util.Date = {

    start_date
  }

  def getEnd_date(): java.util.Date = {

    end_date
  }

  def setPrice(price: Int) = {

    this.price = price
  }
  
 

}