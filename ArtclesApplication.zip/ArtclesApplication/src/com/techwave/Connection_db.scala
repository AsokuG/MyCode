package com.techwave

import java.sql.Connection

import java.sql.DriverManager

import com.techwave.DAO._

class Connection_db {
  
  def conect(): Connection = {

    try {

      Class.forName("com.mysql.jdbc.Driver")

      conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/store", "root", "root")

      conn
      
    } 
    
    catch {

      case ex: ClassNotFoundException =>{

          ex.printStackTrace()

        }
      
        null
    }

  }
 
}