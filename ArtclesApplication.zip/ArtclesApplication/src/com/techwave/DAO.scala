package com.techwave

import java.sql.ResultSet
import java.sql.PreparedStatement
import java.sql.Connection

object DAO {
  
   var conn:Connection=null

  var pst: PreparedStatement = null

  var rs: ResultSet = null
}