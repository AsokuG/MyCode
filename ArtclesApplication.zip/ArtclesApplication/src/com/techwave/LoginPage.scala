package com.techwave

import java.sql.Connection
import java.sql.DriverManager
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.SQLException
import org.apache.wicket.markup.html.WebPage
import org.apache.wicket.markup.html.form.Form
import org.apache.wicket.markup.html.form.PasswordTextField
import org.apache.wicket.markup.html.form.TextField
import org.apache.wicket.markup.html.panel.FeedbackPanel
import org.apache.wicket.model.Model
import com.techwave.DAO._

class LoginPage extends WebPage {
  
  val user = new TextField("UserName", Model.of(""))

  val pword = new PasswordTextField("Password", Model.of(""))

  user.setRequired(true).add(new Validator())

  pword.setRequired(true).add(new Validator())
  
  add(new FeedbackPanel("feedback"))

  val form = new Form("loginForm") {

    override def onSubmit() = {

      val v1 = user.getDefaultModelObjectAsString()

      val v2 = pword.getDefaultModelObjectAsString()

      try {

        conn = new Connection_db().conect()

        pst = conn.prepareStatement("Select username,password from cus_tbl where username=? and password=?")

        pst.setString(1, v1)

        pst.setString(2, v2)

        rs = pst.executeQuery()

        if (rs.next())

          setResponsePage(classOf[ArtclePage])
          
      } catch {

        case ex: ClassNotFoundException => {

          ex.printStackTrace()

        }

        case e: SQLException => {

          e.printStackTrace()
        }

      } finally {
        
        if (conn != null) conn.close()

        if (pst != null) pst.close()

        if (rs != null) rs.close()

      }

    }
  }

  add(form)

  form.add(user)

  form.add(pword)
}