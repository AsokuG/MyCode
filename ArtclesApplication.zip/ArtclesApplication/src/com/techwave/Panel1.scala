package com.techwave

import org.apache.wicket.markup.html.panel.Panel
import java.util.ArrayList
import org.apache.wicket.markup.html.list.ListView
import org.apache.wicket.markup.html.list.ListItem
import org.apache.wicket.markup.html.basic.Label
import org.apache.wicket.model.CompoundPropertyModel
import org.apache.wicket.extensions.ajax.markup.html.modal.ModalWindow
import org.apache.wicket.ajax.markup.html.AjaxLink
import org.apache.wicket.ajax.AjaxRequestTarget
import org.apache.wicket.markup.html.form.TextField
import org.apache.wicket.model.PropertyModel
import org.apache.wicket.ajax.markup.html.form.AjaxButton
import org.apache.wicket.model.Model
import org.apache.wicket.markup.html.form.Form
import org.apache.wicket.ajax.form.OnChangeAjaxBehavior
import java.sql.SQLException
import java.sql.DriverManager
import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.ResultSet
import org.apache.wicket.markup.html.WebMarkupContainer
import com.techwave.DAO._
class Panel1(modalWindow: ModalWindow, artclesInfo: ArtclesInfo, parent: ArtclePage) extends Panel(modalWindow.getContentId()) {

  var query: String = "update zb_art_info set price= ? where art_nr=? and var=? and gebi_nr=?"

  val link = new AjaxLink("closeLink") {

    def onClick(target: AjaxRequestTarget) = {

      modalWindow.close(target)
    }

  }
  add(link)

  val link1 = new AjaxLink("Save") {

    def onClick(target: AjaxRequestTarget) = {

      val newPrice = oldPrice.getDefaultModelObject.toString()

      artclesInfo.price_=(newPrice.toInt)

      modalWindow.close(target)

      try {

        val conn = new Connection_db().conect()

        pst = conn.prepareStatement(query)

        pst.setInt(1, newPrice.toString.toInt)

        pst.setInt(2, artclesInfo.getArt_nr())

        pst.setInt(3, artclesInfo.getVari())

        pst.setInt(4, artclesInfo.getGebi_nr())

        val rs: Int = pst.executeUpdate()

        target.addComponent(parent.markupContainer)

      } catch {

        case e: SQLException => {

          println("SQLEXception " + e.printStackTrace())

        }

        case ex: ClassNotFoundException => {

          println("ClassNotFoundException")

        }

      } 
      finally {

         if (conn != null) conn.close()
         
         if (pst != null) pst.close()
      }

    }

  }

  add(link1)

  add(new Label("art_nr", artclesInfo.getArt_nr().toString()))

  add(new Label("art_bez", artclesInfo.getArt_bez().toString()))

  add(new Label("vari", artclesInfo.getVari().toString()))

  add(new Label("gebi_nr", artclesInfo.getGebi_nr().toString()))

  val oldPrice = new TextField("myTextField", new CompoundPropertyModel[Int](artclesInfo.getPrice()))

  add(oldPrice)

  oldPrice.add(new OnChangeAjaxBehavior() {

    def onUpdate(target: AjaxRequestTarget) = {

     
    }
  })

  add(new Label("start_date", artclesInfo.getStart_date().toString()))

  add(new Label("end_date", artclesInfo.getEnd_date().toString()))
}
