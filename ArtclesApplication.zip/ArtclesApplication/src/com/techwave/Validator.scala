package com.techwave

import org.apache.wicket.validation.CompoundValidator
import org.apache.wicket.validation.validator.StringValidator
import org.apache.wicket.validation.validator.PatternValidator

class Validator extends CompoundValidator[String] {

  add(StringValidator.lengthBetween(2, 13))

}