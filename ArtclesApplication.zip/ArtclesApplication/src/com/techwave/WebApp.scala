package com.techwave

import org.apache.wicket.protocol.http.WebApplication
import org.apache.wicket.Page

class WebApp extends WebApplication {

  override def getHomePage(): Class[_ <: Page] = {

    classOf[LoginPage]
  }

}