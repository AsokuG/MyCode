import java.util.Scanner;

public class BiValued {
	
public static void count(int a, int b) {
	
	int count = 0;
			
			for(int i=a; i <=b; i++) {
				toBinary(i);
			}
}
	
	public static void toBinary(int decimal){  
	     int binary[] = new int[40];  
	     int index = 0;  
	     while(decimal > 0){  
	       binary[index++] = decimal%2;  
	       decimal = decimal/2;  
	     }  
	     for(int i = index-1;i >= 0;i--){  
	       System.out.print(binary[i]);  
	     }  
	System.out.println();//new line
	} 
	
	 static boolean checkPerfectSquare(double x)  
	    { 

		// finding the square root of given number 
		double sq = Math.sqrt(x); 

		/* Math.floor() returns closest integer value, for
		 * example Math.floor of 984.1 is 984, so if the value
		 * of sq is non integer than the below expression would
		 * be non-zero.
		 */
		return ((sq - Math.floor(sq)) == 0); 
	    } 
	
	  public static void main(String[] args)  
	    { 
		System.out.print("Enter any number:");
		Scanner scanner = new Scanner(System.in);
		double num = scanner.nextDouble(); 
		scanner.close();
        count(1, 20);
		if (checkPerfectSquare(num)) 
			System.out.print(num+ " is a perfect square number"); 
		else
			System.out.print(num+ " is not a perfect square number"); 
	    } 
	
	/*
	
// case 1 A = [4,2,2,4,2] 5                   2 2 2 4 4
// [1,2,3,2] 3                                1 2 2 3
// [0,5,4,4,5,12] 4                           0 4 4 5 5 12
// [4,4] 2
 
 * [2, 1, 6, 6, 6, 8, 9, 1, 1]
 * 
 * 			
	
	public static void main(String[] args) {
		int value = 0;	
		int[] array= {0, 5, 4, 1, 4, 5, 12};
		  HashMap hm = new HashMap();
		    for (int i = 0; i < array.length; i++) {
		        Double key = new Double(array[i]);
		        if ( hm.containsKey(key) ) {
		            value = (int) hm.get(key);
		            hm.put(key, value + 1);
		        } else {
		            hm.put(key, 1);
		        }
		    }
		    
		    System.out.println(hm);
		    List list = new ArrayList(hm.values());
		   Collections.sort( list); 
		   System.out.println(list);
		   if(!list.isEmpty() && list.size()>1)
		   {
			   int v1=(int) list.get(list.size()-1);
			   int v2=(int) list.get(list.size()-2);
			   System.out.println(v1+v2);
			   
		   }
		   else {
			   if(!list.isEmpty()) {
				   int v1=(int) list.get(list.size()-1);
				   System.out.println(v1);
			   }else {int v1=0;
			   System.out.println(v1);}
		   }
	}

*/}
