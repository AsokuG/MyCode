

object CustomFold extends App {
  val list = List(1, 3, 5, 7, 9)

  val letters = List("A", "B", "C")

  val fls = letters.foldLeft("z")(_ + _)
  println(fls)
  val frs = letters.foldRight("z")(_ + _)
  println(frs)

  val rl = letters.reduceLeft(_ + _)
  println(rl)
  val rr = letters.reduceRight(_ + _)
  println(rr)

  val sl = letters.scanLeft("z")(_ + _)
  println(sl)
  val sr = letters.scanRight("z")(_ + _)
  println(sr)

  val fl = list.foldLeft(0)(_ + _)
  val fr = list.foldRight(0)(_ + _)

  println("foldLeft Sum: " + fl + "foldRight Sum:" + fr)
  
  
  val li = List(1, 2, 3, 4)
  println(li.reduceLeft(_-_))
  println(li.reduceRight(_-_))
  
  
  /**
   * def foldLeft[B](z: B)(op: (B, A) => B): B
   * Applies a binary operator to a start value and all elements of this sequence, going left to right.
   * list = List(1, 3, 5, 7, 9)
   *                                         0+1 = 1
   *                                               1+3 = 4
   *                                                     4+5 = 9
   *                                                           9+7 = 16
   *                                                                 16+9 = 25
   *
   *  def foldRight[B](z: B)(op: (A, B) => B): B = reverse.foldLeft(z)((right, left) => op(left, right))
   * Applies a binary operator to a start value and all elements of this sequence, going right to left
   *  list.reverse
   *  List(9, 7, 5, 3, 1)
   *                                                       (0, 9) => (9, 0)              9 = 9+0
   *                                               (9, 7) => (7, 9)               16 = 7+9
   *                                       (16, 5) => (5, 16)              21 = 5+16
   *                                (21, 3) => (3, 21)              24 = 3+21
   *                         (24, 1) => (1, 24)              25 = 1+24
   */

  val xs = List(2, 5, 7, 9, 3, 1, 4, 6)

  val ys = List(2.0, 5.0, 2.0)

  //length of the list
  println("length: "+xs.foldLeft(0)((acc, i) => acc + 1))

  //sum of the list
  println("sum: "+xs.foldLeft(0)((acc, i) => acc + i))
  
  println("Reverse: "+ xs.foldLeft(List[Int]())((acc, ele) => ele :: acc))

  //last element in list
  println(xs.foldLeft(0)((acc, i) => i))

  def average(list: List[Double]): Double = list match {
    case head :: tail =>
      tail.foldLeft((head, 1.0)) { (avg, cur) =>
      ((avg._1 * avg._2 + cur) / (avg._2 + 1.0), avg._2 + 1.0)
    }._1
    case Nil => 0.0
  }//((3.5, 2),2.0) ((3.0 , 3.0), 4.0)

  println("avg is: "+average(List(2.0, 5.0, 2.0, 4.0)))

  //List(2, 5, 7, 9, 3, 1, 4, 6)
  def get[A](list: List[A], idx: Int): A =
    list.tail.foldLeft((list.head, 0)) {
      (r, c) => if (r._2 == idx) r else (c, r._2 + 1)
    }._1 /* match {
    case (result, index) if (idx == index) => result
    case _ => throw new Exception("Bad index!")
  }*/

  println("get....."+get(xs, 2))
    
    def linearSearch[A](list: List[A], ele: A): Int = {
    list.tail.foldLeft((list.head, 0)) {
      (r, c) => if (r._1 == ele) r else (c, r._2 + 1)
    }._2
  }
    
    println(""+linearSearch(List(2, 8, 4, 9, 3), 9))

  def reverse[A](list: List[A]): List[A] = {
    list.foldLeft((List[A]()))((r, c) => c :: r)
  }

  println(reverse(xs))

  //if (r._2 < n) ( r._1 :+ c, r._2 + 1) else return r._1

  def take[A](list: List[A], n: Int): List[A] = {
    list.foldLeft((List[A](), 0)) {
      (r, c) => if (r._2 == n) r else (r._1 :+ c, r._2 + 1)
    }._1
  }

  println(take(List(2, 5, 7, 9, 3, 1, 4, 6), 2))

  val opt1: Option[Int] = Some(5)
  opt1.foldLeft(0)(_ + _)
  
  def findMin(list: List[Int]): Int = list.tail.foldLeft(list.head)((acc, ele) => if(acc < ele) acc else ele)
  def findMax(list: List[Int]): Int = list.tail.foldLeft(list.head)((acc, ele) => if(acc > ele) acc else ele)
  
  println("min element in the list is:" + findMin(List(2, 5, 7, 9, 3, 1, 4, 6)))
  println("max element in the list is:" + findMax(List(2, 5, 7, 9, 3, 1, 4, 6)))
}