

object CustomInterpolater extends App {

  case class Person(name: String, age: Int)

  def stringToPerson(line: String): Person = {
    // assume the strings are always "name,age"
    val tokens = line.split(",")
    Person(tokens(0), tokens(1).toInt)
  }

  val bob = stringToPerson("Bob,55")


  implicit class PersonInterpolator(sc: StringContext) {
    def person(args: Any*): Person = {
      // logic here
      val tokens = sc.s(args: _*).split(",")
      Person(tokens(0), tokens(1).toInt)
    }
  }

  val name = "Bob"
  val age = 23
  val bobInterpolator = person"$name,$age"
  println(bobInterpolator)
  
  
  trait Action {
  def act(x: Int): Int
}

val myAction: Action = (x: Int) => x + 1

println(myAction.act(7))

1 :: 2 :: 3 :: List()

1 :: (2 :: (3 ::List()))   ///          List(1,2,3)

List().::(3).::(2).::(1)

 

}