import scala.collection.mutable.ListBuffer
import scala.annotation.tailrec


object CustomMap extends App {
  /*1.
   * Custom map method implementation
   * using for yield comb*/
  def customMap[A, B](f: A => B, list: List[A]): List[B] = {
    for {
      ele <- list
    } yield f(ele)
  }

  val list = List(1, 2, 3, 4, 5)
  val list1 = List(List(1, 2), List(3, 4))  //List(1, 2, 3, 4)
  val multiply = (i: Int) => i * 2
  val square = (i: List[Int]) => i
  val g =(i: Int)=>List((i-1), i, (i+1))
  println(customMap(multiply, list))
  
  println(list.filter(_ %2 ==0))

  /*2.
   * custom map implementation
   * using tailRec*/
  def custMap[A, B](f: A => B, list: List[A]): List[B] = {
    val initialList = List.empty[B]
    @tailrec
    def customMapHelper(in: List[A], out: List[B]): List[B] = {
      in match {
        case Nil          => out.reverse
        case head :: Nil  => (f(head) :: out).reverse
        case head :: tail => customMapHelper(tail, (f(head) :: out))
      }
    }
    customMapHelper(list, initialList)
  }

  println(custMap(multiply, list))

  /*
   * customflatMap method implementation
   * using tailRec
   * */
  def custFlatMap[A, B](f: A => List[B], list: List[A]): List[B] = {
    val initialList = List.empty[B]
    @tailrec
    def customFlatMapHelper(in: List[A], out: List[B]): List[B] = {
      in match {
        case Nil          => out
        case head :: Nil  => out ::: f(head)
        case head :: tail => customFlatMapHelper(tail, out ::: f(head))
      }
    }
    customFlatMapHelper(list, initialList)
  }
  println(custFlatMap(square, list1))
  
  println(custFlatMap(g, list))
  val listDonuts: List[String] = List("Glazed Donut", "Strawberry Donut", "Vanilla Donut")

  /*
   * we are using star(*) symbol for representing the variable argument parameter
   * this function is allowed to call zero or more parameters
   * must be declare variable arguments parameter as last value in the parameter list
   * we can also pass list to this function use  special syntax called type ascription
   * The Var-Args Parameter does not accept “Default Parameter Values”. */
  def variArgs(names: String*) = {
    names.map(println(_))
  }
  variArgs("Ashok", "Gangineni")
  variArgs()
  variArgs(listDonuts: _*)
  
  def filter[A, B](f: A => Boolean, list: Seq[A]): Seq[A] = {
    var buffer = ListBuffer[A]()
    for {
      x <- list
    } yield if (f(x)) buffer += x
    buffer.toList
  }
  
  println(filter(((i: Int) => i%2==0), list))
  
  
  def factorial(n: Int, acc: Int): Int = {
    @tailrec
    def loop(n: Int, acc: Int): Int =
      if (n < 1) acc
      else loop(n - 1, acc * n)

    loop(n, 1)
  }
 println("Factorial: "+factorial(5, 1))
}