

object ListMapHigherOrder {

  def main(args: Array[String]) {
    /* val s = new Scanner(System.in)
     print("Enter any integer you want to check:")
     val n = s.nextInt();*/
    val intList = args.map(StringToInt(_)).toList.flatMap(ele => ele)
    def isPerfectNumber(n: Int): Boolean = {
      var sum = 0
      for (i <- 1 to n - 1) {
        n % i == 0 match {
          case true => sum += i
          case _    =>
        }
      }
      val result = (sum == n) match {
        case true  => true
        case false => false
      }
      result
    }
    def myHigherOrderFunction(f: Int => Boolean, listOfIntegers: List[Int]): List[Boolean] = {
      val result = listOfIntegers.map(f)
      result
    }
    print(myHigherOrderFunction(isPerfectNumber, intList ))
  }

  def StringToInt(value: String): Option[Int] = {
    try {
      Some(value.trim().toInt)
    } catch {
      case ex: Exception => None
    }

  }
}