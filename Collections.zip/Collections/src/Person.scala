
class Person private (name: String) 

object Person {
 val p = new Person("")
 def getInstance = p
}