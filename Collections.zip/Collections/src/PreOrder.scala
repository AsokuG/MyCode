import scala.collection.mutable.ListBuffer
import java.util.Date


object PreOrder extends App {
  
  case class PreOrderStoreArticleEntity(artId: Long,
                                        artNr: Int,
                                        varNr: Int,
                                        gebiNr: Int)

  case class PreOrderStoreFlatEntity(
    salesPeriodId: Long,
    artId:         Long,
    delDay:        Long,
    storeId:       Long,
    dcNr:          Int,
    hier_lfd:      Int,
    projectId:     Long,
    artNr:         Int,
    varNr:         Int,
    gebiNr:        Int,
    storeQty:      Float,
    specialPr:     Float,
    buyingPr:      Float,
    comment:       String)

 val flatList = ListBuffer(
    PreOrderStoreFlatEntity(54, 115, 173, 0, 0, 0, 1000000020, 51613, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 115, 172, 0, 0, 0, 1000000020, 51613, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 117, 183, 0, 0, 0, 1000000020, 103011, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 118, 189, 0, 0, 0, 1000000020, 36398, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 117, 180, 0, 0, 0, 1000000020, 103011, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 116, 179, 0, 0, 0, 1000000020, 87315, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 117, 184, 0, 0, 0, 1000000020, 103011, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 118, 185, 0, 0, 0, 1000000020, 36398, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 119, 190, 0, 0, 0, 1000000020, 74265, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 118, 188, 0, 0, 0, 1000000020, 36398, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 119, 194, 0, 0, 0, 1000000020, 74265, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 115, 174, 0, 0, 0, 1000000020, 51613, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 116, 177, 0, 0, 0, 1000000020, 87315, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 118, 187, 0, 0, 0, 1000000020, 36398, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 119, 191, 0, 0, 0, 1000000020, 74265, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 118, 186, 0, 0, 0, 1000000020, 36398, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 116, 178, 0, 0, 0, 1000000020, 87315, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 115, 170, 0, 0, 0, 1000000020, 51613, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 115, 171, 0, 0, 0, 1000000020, 51613, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 119, 193, 0, 0, 0, 1000000020, 74265, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 117, 181, 0, 0, 0, 1000000020, 103011, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 116, 176, 0, 0, 0, 1000000020, 87315, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 119, 192, 0, 0, 0, 1000000020, 74265, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 116, 175, 0, 0, 0, 1000000020, 87315, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"),
    PreOrderStoreFlatEntity(54, 117, 182, 0, 0, 0, 1000000020, 103011, 1, 1, 0f, 0f, 0f, "Pre Order Test articles"))
    
   val artFun = (flatEnty: PreOrderStoreFlatEntity) => {
     PreOrderStoreArticleEntity(flatEnty.artId, flatEnty.artNr, flatEnty.varNr, flatEnty.gebiNr)
   } 
    
    
 val res =  flatList.groupBy(artFun) 
 
 println(res)
 
 
val buffer = ListBuffer(PreOrderStoreFlatEntity(54,118,189,0,0,0,1000000020,36398,1,1,0f, 0f, 0f, "Pre Order Test articles"),
 PreOrderStoreFlatEntity(54,118,185,0,0,0,1000000020,36398,1,1,0f, 0f, 0f, "Pre Order Test articles"),
 PreOrderStoreFlatEntity(54,118,188,0,0,0,1000000020,36398,1,1,0f, 0f, 0f, "Pre Order Test articles"),
 PreOrderStoreFlatEntity(54,118,187,0,0,0,1000000020,36398,1,1,0f, 0f, 0f, "Pre Order Test articles"),
 PreOrderStoreFlatEntity(54,118,186,0,0,0,1000000020,36398,1,1,0f, 0f, 0f, "Pre Order Test articles"))
 
val r = buffer.groupBy(e => (e.delDay, e.specialPr, e.buyingPr))    

println(r)

}