import scala.annotation.tailrec
import scala.collection.mutable.ListBuffer


object Solution extends App {
  def solution1(a: Array[Int]): Int = {
    val minVal = a.min
    val maxVal = a.max
    val b = (minVal to maxVal).toArray
   // println(b.toList)
    val c = b.diff(a)
    println(c.toList)
    if (c.size > 0) c.max
    else maxVal + 1

  }

  println(solution1(Array(-3, 0, 2, 2, 4))) // -3, -2, -1, 0, 1, 2, 3, 4 ------ -2, -1, 1, 3

/*******************************************************************/

  def solution(n: Int): Array[Int] = {
    val arr = new Array[Int](n)
    var i = n - 1
    var j = n - 2
   // def isEven = (x: Int) => x % 2 == 0
   // isEven(n) match {
    //  case true => {
        var result = n / 2
        while (result > 0) {
          arr(i) = result
          arr(j) = result.unary_-
          result -= 1; i -= 2; j -= 2
        }
     // }
    /*  case false => {
        var result = n / 2
       // println(result)
        // arr(result + 1) = 0
        while (result > 0) {
          arr(i) = result
          arr(j) = result.unary_-
          result -= 1; i -= 2; j -= 2
        }
      }*/
   // }
    arr
  }

  println(solution(5).toList)
  println(solution(6).toList)
 /* println(solution(57).toList)
  println(solution(57).toList.sum)

  println(solution(3).toList)
  println(solution(3).toList.sum)

  println(solution(48).toList)
  println(solution(48).toList.sum)*/

  val lenghth = (input: String) => input.length
  def findLength(f: (String) => Int, input: String): Int = {
    f(input)
  }

 // println(findLength(lenghth, "Äshok"))

/***************************************** Prime Number ***************************************************/

  import util.control.Breaks._

  def isPrime(n: Int): Boolean = {
    var flag: Boolean = n match {
      case n if (n > 1) => true
      case _            => false
    }
    var i = 2
    breakable {
      while (i <= n / 2) {
        if (n % i == 0) {
          flag = false
          break
        }
        i += 1
      }
    }
    flag

  }

 // println(isPrime(21))

  val a = (1 to 100 toList) filter (isPrime)

  println(a)

  //println(a.size)

/*****************************************************Another way of Prime**********************************************************/
  def checkPrime(n: Int): Boolean = {
    var flag: Boolean = n match {
      case n if (n > 1) => true
      case _            => false
    }
    for (i <- 2 to n / 2) {
      if (n % i == 0) flag = false
    }
    flag
  }

  println("&&&" + checkPrime(21))

  val b = (1 to 100 toList) filter (isPrime)

 // println(b)

  //println(b.size)

/************************************************* Eliminating duplicates by using Tail Recursion *********************************************************/
  def removeDuplicates[A](input: List[A]): List[A] = {
    @tailrec
    def eliminateDuplicates[A](result: List[A], input: List[A]): List[A] = input match {
      case Nil          => result.reverse
      case head :: tail => eliminateDuplicates(head :: result, tail.filterNot(_ == head))
    }
    eliminateDuplicates(Nil, input)
  }
 // println(removeDuplicates(List('a', 'b', 'a', 'c', 'a', 'c')))

/**********************************************************Different Operations On LIst**************************************************************************/
  val xs = List(1, 2, 3, 4)
  val ys = List(6, 7, 8, 9)

  0 :: xs

  val x = List(1)
  val y = scala.collection.mutable.LinkedList(2)

/******************************************************Custom take method***********************************************/

  def customTake[A](n: Int, list: List[A]): List[A] = {
    var i = 0
    var buffer = ListBuffer[A]()
    list match {
      case Nil => List()
      case head :: tail => {
        for {
          x <- list
        } yield (i < n) match {
          case true =>
            buffer += x; i += 1
          case false =>
        }
      }
    }

    buffer.toList
  }
 // println(customTake(3, List()))

  def custTake[A](n: Int, list: List[A]): List[A] = {
    var these = list
    var count = n
    var buffer = ListBuffer[A]()
    while (!these.isEmpty && count > 0) {
      buffer += these.head
      these = these.tail
      count -= 1
    }
    buffer.toList
  }
 // println("@@@@@@@@@@@@@@@@@@@@@@@"+custTake(3, xs))
/********************************************************Custom drop method ***************************************************/

  def customDrop[A](n: Int, list: List[A]): List[A] = {
    var these = list
    var count = n
    while (!these.isEmpty && count > 0) {
      these = these.tail
      count -= 1
    }
    these
  }

  //println(customDrop(3, List()))

/*************************************************************Custom splitAt method**********************************************/

  def splitAt[A](n: Int, list: List[A]): (List[A], List[A]) = {
    var count = n
    var b = ListBuffer[A]()
    var these = list
    while (!these.isEmpty && count > 0) {
      b += these.head
      these = these.tail
      count -= 1
    }
    (b.toList, these.toList)
  }

 // println(splitAt(2, xs))

/************************************************************Custom takeRight method******************************/

  def customTakeRight[A](n: Int, list: List[A]): List[A] = {
    var these = list.reverse
    var count = n
    var buffer = ListBuffer[A]()
    while (!these.isEmpty && count > 0) {
      buffer += these.head
      these = these.tail
      count -= 1
    }
    buffer.toList.reverse
  }

 // println(customTakeRight(3, xs))

/*********************************************************************************************/

  //Array(2, 3, 2, 3, 3, 4, 0, 0)
  //Array(2, 4, 0, 0, 5, 7, 2, 3)

  def soliderSolution(arr: Array[Int]): Int = {
    var i = 0
    var count = 0
    while (!arr.isEmpty && i < arr.length) {
      val ele = arr(i)
      arr.contains(ele + 1) match {
        case true  => count += 1
        case false => count
      }
      i += 1
    }
    count
  }

  println("Solider "+soliderSolution(Array(2, 3, 2, 3, 3, 4, 0, 0)))

/*************************************************************************************************/
  
  //Map("capu" -> List(Coffee("capu", Charge(20), Coffee("capu", Charge(10)))), )
  case class Charge(price: Int)
  case class Coffee(name: String, Charge: Charge)

  val coffeeMenu = ListBuffer(Coffee("capu", Charge(20)), Coffee("espr", Charge(50)), Coffee("lettu", Charge(20)), Coffee("capu", Charge(10)), Coffee("lettu", Charge(20)))

  println(coffeeMenu.groupBy(_.name).mapValues { b => b.foldLeft(Charge(0))((c, d) => c.copy(c.price + d.Charge.price)) })
  
  println(coffeeMenu.groupBy(_.name).mapValues(_.foldLeft(Charge(0))((c, d) => c.copy(c.price + d.Charge.price))))

/******************************************************************partition****************************************/
  def partition[A](f: A => Boolean, list: List[A]): (List[A], List[A]) = {
    val l, r = ListBuffer[A]()
    for (x <- list) (if (f(x)) l else r) += x
    (l.toList, r.toList)
  }

  //println(partition((x: Int) => x > 3, xs))

/*************************************************************************************************/

  val testList = List("2 orange", "3 banana", "5 apple", "10 orange", "4 banana")

  val op = testList.map(ele => {
    val r = ele.split(" ")
    (r(0), r(1))
  }).groupBy(_._2).mapValues(ele => ele.map(_._1))

  println(op)

  val storeList = List("1 - Metro Banjaras", "2 - Makro Bnjaras", "3 - Metro Fresh", "4- Metro Bakery")

  val sidList = storeList.map(ele => {
    val r = ele.split("-")
    (r(0), r(1))
  }).groupBy(_._1)
  println(sidList)

/**********************************************************************forall**************************/
  def forall[A](p: A => Boolean, list: List[A]): Boolean = {
    var these = list
    while (!these.isEmpty) {
      if (!p(these.head)) return false
      these = these.tail
    }
    true
  }
  println(forall((x: Int) => x > 3, xs))

/*****************************************************************************foldLeft***********************************/

  def foldLeft[A, B](z: B)(op: (B, A) => B, list: List[A]): B = {
    var acc = z
    var these = list
    while (!these.isEmpty) {
      acc = op(acc, these.head)
      these = these.tail
    }
    acc
  }
  val add = (x: Int, y: Int) => x + y
  //sprintln(foldLeft(0)(add, xs))

/***********************************************************************fold************************************************/
  
  def distinct[A](in: List[A]): List[A] = {
    var buffer = ListBuffer[A]()
    var these = in
    var seen = scala.collection.mutable.HashSet[A]()
    for (x <- these) {
      if (!seen(x)) {
        buffer += x
        seen += x
      }
    }
    buffer.toList
  }
  
  println("Remove duplicates"+ distinct(List(7,7, 9,5, 3, 4,4 )))

}