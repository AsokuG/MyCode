

object Solution1 {
  def main(args: Array[String]): Unit = {
    //println(io.Source.stdin.getLines().take(2).map(_.toInt).sum)
    def f(n: Int) = {
      //1.
      println("Hello World \n" * n)
      //2.
      List.fill(n)("Hello World") foreach (println(_))
      //3.
      var i = n
      while (i > 0) {
        println("Hello World")
        i -= 1
      }
    }
    f(4)
    
    def f1(n: Int, arr: List[Int]): List[Int] = {
      val fil = arr.filter(_ < n)
      println(fil)
      val res = arr.flatMap(ele => List.fill(n)(ele))
      res
    }
    println(f1(4, List(1, 2, 3, 4)))
    
    def sum(x: Int, y: Int) = x + y
def multiply(x: Int, y: Int) = x * y
 

    def execTwoFunctions(
      f1: (Int, Int) => Int,
      f2: (Int, Int) => Int,
      a:  Int,
      b:  Int): Tuple2[Int, Int] = {
      val result1 = f1(a, b)
      val result2 = f2(a, b)
      (result1, result2)
    }
    
   println( execTwoFunctions(sum, multiply, 4, 8))
   
   def whilst(testCondition: => Boolean)(codeBlock: => Unit): Unit = ???
    
  }
}