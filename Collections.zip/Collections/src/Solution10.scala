import jdk.nashorn.internal.ir.BreakableStatement
import scala.util.control.Breaks._
import scala.collection.mutable.ArrayBuffer

/*****************************Optum**************************************/

object Solution10 extends App {
  def solution(a: Array[Int]): Int = {
    var count = 1
    val length = a.size
    breakable {
      while (length > 0) {
        a.contains(count) match {
          case true  => count += 1
          case false => break
        }
      }
    }
    count
  }
 // println(solution(Array(1, 3, 6, 4, 1, 2)))
  
  def solutionWithFoldLeft(a: Array[Int]): Int = {
    a.foldLeft(1)((acc, i) => a.contains(acc) match {
      case true => acc+1
      case false => acc
    })
  }
  // println(solutionWithFoldLeft(Array(1, 3, 6, 4, 1, 2)))
  
  def solutionWithBiValued(a: Array[Int]): Int = {
    var i = 0
    val arr = new ArrayBuffer[Int]()
    while (a.length > 0) {
      a.contains(a(i)) match {
        case true  => arr += a(i)
        case false => arr.isEmpty match {
          case true => 
          case false => arr +=arr(i)
        }
      }
    }
    arr.size
  }
  println(solutionWithBiValued(Array(1,2,3,2)))
  println("dfbgdh")
}

// case 1 A = [4,2,2,4,2] 5                   2 2 2 4 4
// [1,2,3,2] 3                                1 2 2 3
// [0,5,4,4,5,12] 4                           0 4 4 5 5 12
// [4,4] 2
 