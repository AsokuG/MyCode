import scala.collection.mutable.ArrayBuffer


object Solution2 extends App {

  def solution(a: Array[Int]): Int = {
    var i = a.length
    var b = a.sorted
    var repeat = 0
    // var count = 0
    var arr = new ArrayBuffer[Int]()
    while (i > 0) {
      b.contains(a(i - 1)) match {
        case true => if (repeat <= 2) {
          arr.contains(b(i - 1)) match {
            case true  => arr += b(i - 1)
            case false => repeat += 1; arr += b(i - 1)
          }
        }
        case false =>
      }
      i -= 1
    }
    arr.size
  }
  println(solution(Array(1, 2, 3, 2)))
}

// case 1 A = [4,2,2,4,2] 5                   2 2 2 4 4
// [1,2,3,2] 3                                1 2 2 3
// [0,5,4,4,5,12] 4                           0 4 4 5 5 12
// [4,4] 2
 