
/*
 * We have three different formats of cricket players runs
 * in three different Maps
 * find the all formats of runs of each and every player
 * */
object Solution3 extends App {

  val t20Cricket = Map("Virat Kohli" -> 2441, "Suresh Raina" -> 1605, "Sachin Tendulakar" -> 10, "Rohit Sharma" -> 2434)
  val odiCricket = Map("Sachin Tendulakar" -> 18426, "Virender Sehwag" -> 8273, "Sourav Ganguly" -> 11363, "Rahul Dravid" -> 10889, "Rohit Sharma" -> 8686)
  val testCricket = Map("Rahul Dravid" -> 13288, "Virender Sehwag" -> 8586, "Sachin Tendulakar" -> 15921, "Sourav Ganguly" -> 7212, "VVS Laxman" -> 8781)
  


  val allFormatRuns = List(t20Cricket, odiCricket, testCricket)
  
 val result = allFormatRuns.reduceLeft((f, s) => s.foldLeft(f){
    (dist, ele) => dist + (ele._1 -> (ele._2 + dist.getOrElse(ele._1, 0))) 
  })
  
  println("All players runs in all formats:" + result)

  def mergingMaps(maps: Seq[Map[String, Int]]): Map[String, Int] = { 
    maps.reduceLeft((r, m) => m.foldLeft(r) {
     // case (dist, (k, v)) => dist + (k -> (v + dist.getOrElse(k, 0)))
      
     (dist, ele) => dist + (ele._1 -> (ele._2 + dist.getOrElse(ele._1, 0))) 
    })

  }
    
  //(t20Cricket, odiCricket) =>
  println("All players runs in all formats:" + mergingMaps(allFormatRuns))
  

  println(mergingMaps(allFormatRuns).getOrElse("Sachin Tendulakar", "Not Found"))
  
  allFormatRuns.reduceLeft((f, s) => s.foldLeft(f){
    (dist, ele) => dist + (ele._1 -> (ele._2 + dist.getOrElse(ele._1, 0)))
  })

}