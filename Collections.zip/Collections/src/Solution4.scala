

object Solution4 extends App {
  var max = 0
  var secondMax = 0
  var length = 0
  var min = 0
  val list = List(14, 46, 47, 86, 92, 52, 7, 48, 36, 66, 85)
//1 2 3
  for (li <- list) {
    if (length == 0) min = li
    if (li > max) {
      secondMax = max
      max = li
    } else if (li > secondMax) {
      secondMax = li
    }
    length += 1
    /*
     * */
    if (li < min) {
      min = li
    }
  }

  list.foreach(ele => print(ele + " "))
  println("Max num:" + max + " " + "Second max:" + secondMax + " " + "Min num:" + min)

}