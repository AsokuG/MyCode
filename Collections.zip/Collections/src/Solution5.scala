
/*
 * separate Integers, Strings & Mixed
 * from the List of combined data
 *   */
object Solution5 extends App {

  val liveData = List("54664732", "hhgjkfdjkbg", "97263836", "hdfsh47485", "256364748", "dhbfjdshjkfhfhh", "567hdhj67", "6437838")

  def toInt(input: String): Option[Int] = {
    try {
      Some(Integer.parseInt(input.trim()))
    } catch {
      case ex: Exception => None
    }
  }

  val numbers = liveData.flatMap(toInt).map(_.toString())

  val mixed = (liveData diff numbers).filter(eleStr => eleStr.filter(ele => Character.isDigit(ele)).size > 0)

  val pureStrings = (liveData diff numbers diff mixed).toList

  println("Combined Data: " + liveData)

  println("Integers :" + numbers)

  println("Both String & Integer: " + mixed)

  println("Strings: " + (liveData diff numbers diff mixed))
  
  /*implicit val x: Boolean =true
  implicit val y: Boolean = false
  
  def printIfTrue(a: Int)(implicit b: Boolean) = if(b) println(a) 

  printIfTrue(5)*/
}