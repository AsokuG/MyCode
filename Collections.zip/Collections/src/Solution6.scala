import scala.util.Random

object Solution6 extends App {

  /*apply method defined inside a object*/
  object Great {
    def apply(name: String): String = {
      "Hello %s".format(name)
    }
  }

  println(Great("Ashok"))

  /*apply method defined inside a class*/
  class Amazing {
    def apply(x: String) = "Amazing %s!".format(x)
  }

  val a = new Amazing()
  a("")

  /*using class in pattern matching*/
  class User(val id: Int, val name: String)

  object User {
    def apply(id: Int, name: String): User = new User(id, name)

    def unapply(user: User): Option[(Int, String)] =
      Some(user.id, user.name)
  }

  val user = User(3, "Ashok")
  def getId(user: User): Int = user match {
    case User(id, name) => id
  }
  println(getId(user))

  /*using case class in pattern matching*/
  object CustomerID {

    def apply(name: String) = s"$name--${Random.nextLong}"

    def unapply(customerID: String): Option[String] = {
      val stringArray: Array[String] = customerID.split("--")
      if (stringArray.tail.nonEmpty) Some(stringArray.head) else None
    }
  }

  val customer1ID = CustomerID("Sukyoung") // Sukyoung--23098234908
  val name = CustomerID.unapply(customer1ID).get
  println(name)// prints Sukyoung
  customer1ID match {
    case CustomerID(name) => println(name) // prints Sukyoung
    case _                => println("Could not extract a CustomerID")
  }
}