import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent._
import scala.util.Random
import scala.concurrent.duration._
import java.util.concurrent.TimeoutException
import java.util.Calendar
import java.text.SimpleDateFormat
import java.util.Date
import scala.collection.mutable.ListBuffer
import java.time.LocalDate
import java.util.ArrayList
import scala.collection.mutable.ArrayBuffer
import scala.collection.mutable.HashMap


object Solution7 extends App {/*

  implicit val baseTime = System.currentTimeMillis

var totalA = 0
  //var totala = 0

  val text = Future {
    "na" * 16 + "BATMAN!!!" //nanananananananananananananananaBATMAN!!!
  }
  println("Hello Await!!!")
  val res1 = Await.result(text, 1 second)
  totalA += res1.count(_ == 'A')
  println(totalA)
  val res2 = Await.result(text, 1 second)
  totalA += res2.count(_ == 'a')
  println(totalA)
  println("Hello Ashok!!!")
  
  
  text foreach { txt =>
    totalA += txt.count(_ == 'A') //2
  }

  text foreach { txt =>
    totalA += txt.count(_ == 'a') //16, 18
  }

  Thread.sleep(5000)
  println(totalA)
  // println(totala)

  println("starting futures")
  val result1 = Cloud.runAlgorithm(10)
  val result2 = Cloud.runAlgorithm(20)
  val result3 = Cloud.runAlgorithm(30)

  println("before for-comprehension")
  val result = for {
    r1 <- result1
    r2 <- result2
    r3 <- result3
  } yield (r1 + r2 + r3)

  println("before onSuccess")
  result onSuccess {
    case result => println(s"total = $result")
  }

  println("before sleep at the end")
  Thread.sleep(2000) // important: keep the jvm alive

  object Cloud {
    def runAlgorithm(i: Int): Future[Int] = future {
      Thread.sleep(Random.nextInt(500))
      val result = i + 10
      println(s"returning result from cloud: $result")
      result
    }
  }
  
  
  
   val cal  = Calendar.getInstance();
   cal.add(Calendar.DATE, 9);
   //val s = new SimpleDateFormat("yyyy-MM-dd");
   println( new Date(cal.getTimeInMillis()))
   
  // println(new Date().before(new Date(cal.getTimeInMillis())))

  // println("before sleep at the end")
  // Thread.sleep(2000)  // important: keep the jvm alive
   
   
   val li = new ListBuffer[Int]()
   
   li.update(1, 34)
   
   //Tue Nov 12 00:00:00 IST 2019,  Tue Nov 19 00:00:00 IST 2019
   
  println( getDatesBetweenDates(new Date(), new Date(cal.getTimeInMillis())).size)
  
  getDatesBetweenDates(new Date(), new Date(cal.getTimeInMillis())).foreach(ele => println(ele))
   
   def getDatesBetweenDates(startDate: Date, endDate: Date): List[Date] = {
    val multi = new ListBuffer[Date]()
    cal.setTime(startDate)
    while (cal.getTime().before(endDate)) {
      val result = cal.getTime()
      multi.append(result)
      cal.add(Calendar.DATE, 1)
    }
    multi.toList
  }
   
   
   val a = Map(
    1 -> "one",
    2 -> "two",
    3 -> "three"
)

println(a.get(4).isEmpty)

println(String.format("%1$te.%1$tm.%1$tY %1$TH:%1$TM:%1$TS", new Date()))
println(new java.math.BigDecimal(2))

val strtDate = "2019-11-12";
val endDate = "2019-11-18";
var start = LocalDate.parse(strtDate)
val end = LocalDate.parse(endDate)
val totalDates = new ListBuffer[LocalDate]();
while (!start.isAfter(end)) {
    totalDates.append(start);
    start = start.plusDays(1);
}

totalDates.foreach(ele => println(ele))
println(totalDates.size)

val df = new SimpleDateFormat("dd.MM.yyyy")

def getDate(dtStr: String): java.util.Date = {
    //    var dtResult = new Date()
    //    try {
    if (dtStr == null || dtStr.trim().equals("")) {
      new Date()
    } else {
      df.parse(dtStr)
    }
    //    } catch {
    //      case e: Exception => e.printStackTrace()
    //    }
    //    dtResult
  } //end of getDate

val stDate = "12.11.2019"

println(getDate(stDate))
//println(new java.util.Date(new java.sql.Date(10).getTime))
*/
  
    def solution(a: Array[Int]): Int = {
    var i = a.length
    var b = a.sorted
    var repeat = 0
    // var count = 0
    var arr = new ArrayBuffer[Int]()
    while (i > 0) {
      b.contains(a(i - 1)) match {
        case true => if (repeat <= 2) {
          arr.contains(b(i - 1)) match {
            case true  => arr += b(i - 1)
            case false => repeat += 1; arr += b(i - 1)
          }
        }
        case false =>
      }
      i -= 1
    }
    arr.size
  }
    
    def  solution1(a: Array[Int]): Int = {
    val hm = new HashMap[Int, Int]();
    var count = 0
    for (i <- a) {
      // val  key = new Double(a[i]);
      if (hm.contains(i)) {
        count = hm.get(i).get;
        hm.put(i, count + 1);
      } else {
        hm.put(i, 1);
      }
    }
   val res = (hm.values.size > 1) match {
     case true =>  hm.values.toList.sorted.last + hm.values.toList.sorted.init.last
     case false => 
    }
    hm.values.toList.sorted.last + hm.values.toList.sorted.init.last
  }
    
     println(solution1(Array(4,4)))  // 2 2 2 4 4  1 1 1 2 2 2 3 3 4 4
  
println("Ashok")
}