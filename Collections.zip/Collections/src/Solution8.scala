

object Solution8 extends App {

  case class BillingInfo(
    creditCards: Seq[CreditCard])

  case class Person(
    firstName: String,
    lastName:  String,
    age:       Int)

  case class User(
    id:          Int,
    name:        Person,
    billingInfo: BillingInfo,
    phone:       String,
    email:       String)

  case class CreditCard(
    name:   Person,
    number: String,
    month:  Int,
    year:   Int,
    cvv:    String)

  val ashok = Person("Ashok", "Gangineni", 25)

  val hdfc = CreditCard(ashok, "1234-5678-9876-5432", 10, 21, "720")

  val billingInfo = BillingInfo(Seq(hdfc))

  val user = User(1, ashok, billingInfo, "9160662386", "gangineniashok19@gmail.com")

 //1. update the phone number
 val user1 = user.copy(phone = "7995100761")
 
 val newName = user1.name.copy(age=24)
 
 val oldCreditInfo = user1.billingInfo.creditCards(0)
 
 val newCreditInfo = oldCreditInfo.copy(newName)
 
 val newBillingInfo = user1.billingInfo.copy(Seq(newCreditInfo))
 
 val user2 = user1.copy(billingInfo = newBillingInfo)
 
 val user3 = user2.copy(name = newName)
 
 println(user3.toString)

}