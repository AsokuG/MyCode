

object Solution9 extends App {
 //1. Implicit parameters
  implicit val a = 10
 // implicit val b = 20
  
  def multiply(x: Int)(implicit y: Int) = x * y
  
 // def add(implicit a: Int, b: Int)= a+b
  
 // println(add())
  
  println(multiply(5))
  
  //2. Implicit conversions
  def something(s: String): Unit = println(s)
  
  implicit def intToString(i: Int): String = i.toString()
  
  something(7)
  
  //3. 
  
  class LoquaciousInt(x: Int){
    def chat: Unit = for(i <-1 to x){println("Hi")}
  }
  
  implicit def intToLoquaciousInt(x: Int) = new LoquaciousInt(x)
  
  3.chat
}