package com.prac.basic

object  PrintPlanted  {
   def main(args: Array[String]): Unit = {
     for(fruit <- planted){
       println(fruit)
     }
   }
   
   
  def myFunc(input:Either[Int, String]): Either[Int, String] = {
    if (true)
      Left(42) // return an Int
    else
      Right("Hello, world") // return a String
  }
  
  println(myFunc(Left(42)))
}