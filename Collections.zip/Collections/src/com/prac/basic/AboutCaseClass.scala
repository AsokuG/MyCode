package com.prac.basic

/*
 * Case class is similar to a class but it provides a lot of boilerplate code for developers to use. 
 * By default, they are immutable i.e. once declared cannot be changed.
 * If we compile the case class using scalac command and decompile it using javap command
 * Case classes automatically generate the following:
 * Getter methods for the constructor arguments.
 * Hashcode and equals.
 * Copy method.
 * Companion object with apply/unapply.
 * toString.
 * Case classes use an algorithm called murmur hash and regular classes use the default hash
 * */

object AboutCaseClass extends App {

  case class Book(id: Int, title: String, isbn: Long)

  /*
   * If a case class is a data holder, then a corresponding companion object is a service for that case class.
   *  Singleton object serves the purpose of both a factory and an extractor.
   * As a factory, it provides apply method which allows us to create an object without new keyword. */

  val book = Book(1, "Programming In Scala", 9788370017361L)

  //As an extractor, it provides unapply method which is used for pattern matching.
  book match { case Book(1, "Programming In Scala", 9788370017361L) => println("Extractor") case _ => print("Failed!") }

  /*
   * case class constructor parameters by default all are val for val only getters are provided
   * We change case class constructor parameters to vars for vars both gettersa and setters provided.
   * Case classes without parameters are meaningless and deprecated. In that situation, case objects are used.
   * */

  Book // It references the companion object Book
  /*
  * toString method in case classes does not give the hexadecimal representation of the hashcode
  * rather it gives a meaningful representation of the class.*/
  val fullCopiedObject = book.copy()
  println(fullCopiedObject.toString)
  val partialCopiedObject = book.copy(title = "Scala for Impatient")
  println(partialCopiedObject.toString)

  /*
  * equals method that does the comparison on basis of values.
  * '==' this method also internally calls equals method only
  * */

  println(book.equals(fullCopiedObject))
  println(book == fullCopiedObject)

  /*
  * The eq method compares the memory address of the objects.
  *  The ne method is the exact opposite of eq.
  *  */
  println(book.eq(fullCopiedObject))
  println(book.ne(fullCopiedObject))

  /*
   * the case to case inheritance is prohibited due to the equals and hashcode method case classes generate
   * Case Class can extend another Class, trait or Abstract Class.
   *  */
  // case class Card(id: Int)

  //case class DebitCard(id:Int,name:String,cvv:Int) extends Card(id)

  //case class extends abstract class
  abstract class Card(id: Int) {
    def printCardDetails: Unit
  }

  case class DebitCard(id: Int, name: String, cvv: Int) extends Card(id) {
    override def printCardDetails: Unit = {
      print(id + " " + name + " " + cvv)
    }
  }

  val debitCardObject: Card = DebitCard(1, "Aman", 312)
  println(debitCardObject)
//case class extends trait
  trait Message {
    def id: String
    def content: String
  }

  case class DefaultMessage(id: String, content: String) extends Message

  val defaultMessage: Message = DefaultMessage("A121", "Hello everyone..!!")
  println(defaultMessage)

  case class FailureBook(id: Int)(title: String)
  println(FailureBook(7)("GlocalLeader") == FailureBook(7)("Programming in scala"))
}