package com.prac.basic

case class Employee(id: Int, name: String, salary: Double)