package com.prac.basic

import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration._
import scala.concurrent.Await

object Future1 extends App {

  val f = Future {
    Thread.sleep(500)
    1 + 1
  }
  
 val result = Await.result(f, 2.seconds)
 println(result)
 
 val result1 = Await.ready(f, 2.seconds)
 println(result1)
 
 Thread.sleep(1000)
  

}