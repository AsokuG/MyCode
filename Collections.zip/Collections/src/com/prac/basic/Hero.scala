package com.prac.basic

object Hero extends App {

  val in = Console.readLine("Type Either a string or an Int: ")
  val result: Either[String, Int] = try {
    Right(in.toInt)
  } catch {
    case e: Exception =>
      Left(in)
  }

  println(result match {
    case Right(x) => "You passed me the Int: " + x + ", which I will increment. " + x + " + 1 = " + (x + 1)
    case Left(x)  => "You passed me the String: " + x
  })
  /*def main(args: Array[String]){

    val n = io.StdIn.readLine().toInt
 // println(s"n value is $n")
    for (_ <- 1 to n) {
      val map = scala.collection.mutable.Map.empty[Int, Int]
      val k = io.StdIn.readLine().toInt
      println("k value" + k)
      var isFunction = true
      (1 to k).foreach(i => {
        val args = io.StdIn.readLine().split(" ").map(_.toInt)
        if (map.contains(args(0)) && map(args(0)) != args(1)) {
          isFunction = false
        } else {
          map(args(0)) = args(1)
        }
      })
      println(if (isFunction) "YES" else "NO")
    }
  }*/
}