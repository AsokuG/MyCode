package com.prac.basic

import scala.util.Try
import scala.util.Success
import scala.util.Failure

object OptionTry extends App {

  
  //Option -> Some, None
  def toInt(s: String): Option[Int] = {
    try {
      Some(Integer.parseInt(s))     
    } catch {
      case e: Exception => None
    }
  }

  //Try -> Success, Failure
  def stringToInt(s: String): Try[Int] = Try(s.trim.toInt)

  stringToInt("foo") match {
    case Success(x) => println(x)
    case Failure(e) => println(e.getMessage)
  }

  //scalatic Or -> Good, Bad
  /*def makeInt(s: String): Int Or ErrorMessage ={
    try {
      Good(s.trim.toInt)
    } catch {
      case e: Exception => Bad(e.toString)
    }
  }*/
  
  def fib(n: Int): Int = {
  @annotation.tailrec
  def loop(n: Int, prev: Int, cur: Int): Int =
    if (n <= 1 ) prev
    else loop(n - 1, cur, prev + cur)  //  4, 1, 0+1  3, 1, 1+1  2, 1, 2+1  1, 1, 3   0 1 1 2 3 5   5, 0, 1    4, 1, 0+1    3, 1, 1+1   2, 2, 2
  loop(n, 0, 1)
}

println("Fibo of 5 is: " + fib(5))
  
  //Either -> Right, Left
  def strToInt(s: String): Either[String, Int] = {
    try {
      Right(s.trim.toInt)
    } catch {
      case e: Exception => Left(e.getMessage)
    }
  }
println("Either.......: " + strToInt("foo"))
}