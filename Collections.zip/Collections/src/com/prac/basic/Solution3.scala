

package com.prac.basic

object Solution3 extends App {
  
  case class Employee(id: Int, name: String, salary: Double) /*extends Ordered[Employee]*/
  
  val firstEmp = Employee(1,"james",12000.00)
  
  val secondEmp = Employee(2,"shaun",12000.00)
  
  val thirdEmp = Employee(3,"michael",12000.00)
  
  val forthEmp = Employee(4,"michael",11000.00)
  
  val fifthEmp = Employee(5,"michael",15000.00)
  
  val empList = List(firstEmp,secondEmp,thirdEmp,forthEmp,fifthEmp)
  
  println(empList.sortBy(_.name))
  
  println(empList.sortBy(_.salary))
  
  /*
   * sort is based on multiple attributes, 
   * it will sort based on the first attribute 
   * if more than one value in the first attribute is same then 
   * it will sort on the basis of the second attribute and so on.
   * */
  
  println(empList.sortBy(empList =>(empList.name,empList.salary)))
 
  
  // def sortWith(lt: (A, A) => Boolean): Repr 
  
  println(empList.sortWith(_.salary > _.salary))
  
  def sortBySalary(emp1: Employee, emp2: Employee): Boolean = {
    emp1.salary < emp2.salary
  }
  
  
   println(empList.sortWith((emp1, emp2) => sortBySalary(emp1, emp2)))
   
  // println(empList.sorted)
}