package com.prac.basic

import scala.collection.mutable.LinkedList
import java.util.regex.Pattern.End

object Solution4 extends App {
 sealed trait Sum[A, B] 
 final case class Left[A, B](value: A) extends Sum[A, B]
 final case class Right[A, B](value: B) extends Sum[A, B]
 
 println(Left[Int, String](1).value)
 
 sealed trait CustomMethods[A] {
    def map[B](f: A => B): CustomMethods[B] = {
      this match {
        case Full(v) => Full(f(v))
        case Empty() => Empty[B]()
      }
    }

    def flatMap[B](f: A => CustomMethods[B]): CustomMethods[B] = {
      this match {
        case Full(v) => f(v)
        case Empty() => Empty[B]()
      }
    }
  }
 
final case class Full[A](value: A) extends CustomMethods[A]  
final case class Empty[A]() extends CustomMethods[A]

val list: List[CustomMethods[Int]] = List(Full(3), Full(2), Full(1))

println(list.map(maybe => maybe.flatMap[Int] { x => if (x % 2 == 0) Full(x) else Empty() }))

println(list.map(custom => custom.map[Int](x => x)))

}