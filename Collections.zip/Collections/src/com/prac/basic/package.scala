package com.prac

package object basic {
  
   val planted = List("Apple")
 
  
}