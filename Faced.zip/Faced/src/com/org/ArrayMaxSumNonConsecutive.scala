package com.org

object ArrayMaxSumNonConsecutive extends App {

  def maxSum(list: Seq[Int]): Int = {
    def inner(list: Seq[Int], inclusive: Int, exclusive: Int): Int = list match {
      case Nil          => math.max(inclusive, exclusive)
      case head :: tail => inner(list.tail, list.head + exclusive, inclusive)  //(1, 2, 3, 4, 5) 1 0 => (2, 3, 4, 5) 1+0 1 => (3, 4, 5) 2+1 1 => (4, 5) 3+1 3 => 5 4+3  4 => Nil 5+4 
    }
    inner(list.tail, list.head, 0)
  }

  println("max sum: " + maxSum(List(1, 2, 3, 4, 5)))

}