package com.org

import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Promise
import scala.util.Failure
import scala.util.Success
import scala.concurrent.Await
import scala.concurrent.duration.Duration
import scala.concurrent.ExecutionContext

/*
 * futures are defined as a type of read-only placeholder object 
 * promise can be thought of as a writable, single-assignment container
 * - callbacks
 * - combinators
 * - recovery
 * 
 *  */

object AsynchronusAPI extends App {

  val f1 = Future(2)
  val f2 = Future {
   5
  }
  println(f1.value)
  println(f1)
  println(f2)
  
 val result = Future.foldLeft(List(f1, f2))(0)(_+_)
 
 
 var count =0
(1 to 100).foreach(ele => Future {
  count +=1
})
println("count:  "+count)
 
//println(result)
 result.onComplete{
    case Success(x) =>  println("result"+x)
    case Failure(ex) => println(""+ ex)
  }
  
  
  val g = Future {
  4 / 2
}
for (exc <- g.failed) println("*************" + exc)

  val promise = Promise[String]()
  val future = promise.future
  

  promise.success("Hyderabad")
 future.map { value => println(value) }
 // println(future.value)
  
  

  val arthemeticFuture = Future {
    100 / 0
  } recover {
    case t: Throwable => Future(0)
  }
  arthemeticFuture onComplete {
    case Success(_)     => println("Future completed successfully.")
    case Failure(error) => println(s"Future completed with error: ${error}.")
  }
  
 val b = arthemeticFuture.transform{
  case Success(x) => Success("OK")
  case Failure(_) => Success("KO")
  }
  
 b.onComplete{
   case Success(x)     => println("Future tansform completed successfully."+ x)
    case Failure(error) => println(s"Future completed with error: ${error}.")
 }
 
 
  val c = arthemeticFuture.map{
  case Success(x) => Success("OK")
 // case Failure(_) => Success("KO")
  }
  arthemeticFuture.map(ele => Success("OK"))
  println("C value is: "+c.value)
  arthemeticFuture.map(ele => Success("OK")).onComplete{
     case Success(_)     => println("Future map completed successfully.")
    case Failure(error) => println(s"Future map completed with error: ${error}.")
  }
  
  /*
   * List[Future[T]] ============>   Future[List[T]]*/
  
  val pricesList:List[Future[Int]] = List(Future(1001),Future(999),Future(-2000),Future(1000)) 
  Future.sequence(pricesList).map(_.max) onComplete { 
     case Success(x) => println(x)
      case Failure(error) => println(s"Future completed with error: ${error}.")
   }
  
  
  def listOfFuture = List(1, 2, 3).map(Future(_))
  
  def futureOfList = Future.sequence(listOfFuture)
  
  println(listOfFuture)
  futureOfList.onComplete {
    case Success(x)     => println("nfnndknkn: "+x)
    case Failure(error) => println(s"Future completed with error: ${error}.")
  }
  
 def futOfList = Future.traverse(listOfFuture)(x => x) 
 def futuOfList = Future.traverse(List(1, 2, 3))(Future(_))
 futOfList.onComplete {
    case Success(x)     => println(x)
    case Failure(error) => println(s"Future completed with error: ${error}.")
  }
  Thread.sleep(1000)
  
/*@volatile var totalA = 0

val text = Future {
  "na" * 16 + "BATMAN!!!"
}

text foreach { txt =>
  totalA += txt.count(_ == 'a')
}

text foreach { txt =>
  totalA += txt.count(_ == 'A')
}

println(totalA)
  */
  
  
  def f[A](x: Option[Future[A]]): Future[Option[A]] = 
  x match {
     case Some(f) => f.map(Some(_))
     case None    => Future.successful(None)
  }
  
  f(Some(Future.successful(42)))
  
  def processAndReturnFuture(x:String):Future[String] = Future(x)
def processAgainAndReturnOption(x:String):Option[String] = Some(x)
  
  val futOpt:Future[Option[String]] = Future(Some("x"))
  
 val a = futOpt.flatMap {
    case None => Future.successful(None)
    case Some(x) =>
      processAndReturnFuture(x).map {
        processedX => processAgainAndReturnOption(processedX)
      }
  }
  
  val studentIds = Future{
    List("s1", "s2", "s3")
  }
  
  val res = studentIds zip(Future(List("Ashok", "Scott"))).map(x => x.tail)
  
res.onComplete{
    case Success(x) => println(x)
    case Failure(ex) =>
  }
  
   val str = "hcl technolgies"
 
 println(str.zipWithIndex.groupBy(_._1).mapValues(_.map(_._2).size))
  
val list1: Future[List[Int]] =  Future{List(1, 2, 3, 4)}
val list2: Future[List[Int]] = Future{List(5, 6, 7, 8)}

var respt: Future[List[(Int, Int)]] = Future{List()}

val resp = for{
  l1 <- list1
  l2 <- list2
} yield{l1 zip l2}

val res1 = list1.transform(x => x)
 list1.onComplete{
    case Success(x) => list2.onComplete {
      case Success(y)  =>  respt = Future(x zip y)
      case Failure(ex) => 
    }
    case Failure(ex) => List()
  }
 
 Thread.sleep(1000)
 
 println(res)
  

}