package com.org

import scala.collection.mutable.Stack
import scala.util.control.Breaks._

object BalancingBrackets extends App {
 val stack = Stack[Char]()
  def validate(str: String): Boolean =
    validateCharSeq(str.toList, stack)
  def validateCharSeq(charSeq: Seq[Char], stack: Stack[Char]): Boolean =
    charSeq match {
      case Nil => stack.isEmpty
      case head :: tail if (head == '(' || head == '{' || head == '[') => stack.push(head); validateCharSeq(tail, stack)
      case head :: tail if (head == ')') => if(stack.top == '(') {stack.pop; validateCharSeq(tail, stack)} else validateCharSeq(Nil, stack)
      case head :: tail if (head == '}') => if(stack.top == '{') {stack.pop; validateCharSeq(tail, stack)} else validateCharSeq(Nil, stack)
      case head :: tail if (head == ']') => if(stack.top == '[') {stack.pop; validateCharSeq(tail, stack)} else validateCharSeq(Nil, stack)
      case _ :: tail => validateCharSeq(tail, stack)
    }

  println("Balancing the parenthesis: " + validate("{}["))   //A({[]}) {}  [(])    [()]   [(a)]a  {] {}[
  
  /*
  val stack = Stack[Char]()
  def isBalancedBrackets(str: String): Boolean = {
    for (i <- 0 until str.length()) { 
      val char = str(i)
      breakable {
        if (char == '(' || char == '{' || char == '[') {
          stack.push(char)
        }else break
      }
      if (stack.isEmpty) false
      char match {
        case ')' => breakable {
          val ele = stack.pop
          if (ele == '{' || ele == '[')
            return false;
          break
        }
        case '}' => breakable {
          val ele = stack.pop
          if (ele == '(' || ele == '[')
            return false;
          break
        }
        case ']' => breakable {
          val ele = stack.pop
          if (ele == '{' || ele == '(')
            return false;
          break
        }
        
      }
    }
     stack.isEmpty
  }
  
  println(isBalancedBrackets("([{}])"))
  
  
    def validate(str: String): Boolean =
    validateCharSeq(str.toList, 0)
  def validateCharSeq(charSeq: Seq[Char], count: Int): Boolean =
    if (count < 0) false
    else charSeq match {
      case Nil => count == 0
      case head :: tail if (head == '(' || head == '{' || head == '[') => validateCharSeq(tail, count + 1)
      case head :: tail if (head == ')' || head == '}' || head == ']') => validateCharSeq(tail, count - 1)
      case _ :: tail => validateCharSeq(tail, count)
    }

  println("Balancing the parenthesis: " + validate("A({[}])"))

*/}