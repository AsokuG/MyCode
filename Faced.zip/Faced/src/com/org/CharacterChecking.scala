package com.org

object CharacterChecking extends App {
  def test(x: String): Boolean = {
    val indexOfB = x.indexOf('b')
    val indexOfA = x.zipWithIndex.filter(_._1 == 'a').map(_._2)
    indexOfA.forall(_ < indexOfB)
  }

  println(test("aaabbaabb"))
  
  def test1(x: String): String = {
    x.zipWithIndex.groupBy(_._1).foldLeft("")((c, r) => c+r._1+r._2.length)
  }
  
  println(test1("aaaaabbbbbcccc"))   // Map(a -> List((a, 0), (a, 1)))
}