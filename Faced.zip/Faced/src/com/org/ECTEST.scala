package com.org

import scala.concurrent.Future
import scala.concurrent.Await
import scala.concurrent.duration.Duration
import scala.concurrent.ExecutionContext.Implicits.global

object ECTEST {

  def main(args: Array[String]): Unit = {
    val tasks: Future[Seq[Unit]] = Future.traverse(1 to 30)(runTask)
    Await.result(tasks, Duration.Inf)
  }

  def runTask(i: Int): Future[Unit] = {
    Future {
      println(s"[${Thread.currentThread().getName}]-Task#$i")
      Thread.sleep(1000)
    }
  }

  /* def runTask(i: Int): Future[Unit] = {
    Future {
      println(s"Task#$i")
      Thread.sleep(1000)
    }
  }

  def main(args: Array[String]): Unit = {
  val tasks: Future[Seq[Unit]] = Future.traverse(1 to 30)(runTask)
  Await.result(tasks, Duration.Inf)
}*/

}