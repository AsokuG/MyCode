package com.org

import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global
import scala.util.Random
import scala.util.Failure
import scala.util.Success

object FutureAndPromise extends App {

  case class Profile(id: String, name: String) {
    def poke(anotherProfile: Profile) = println(s"${this.name} poking ${anotherProfile.name}")
  }

  object SocialNetwork {
    val names = Map(
      "7995100761" -> "Ashok",
      "9989476700" -> "Ram",
      "1111000022" -> "dummy")

    val friends = Map("7995100761" -> "9989476700")

    val random = new Random()

    def fetchProfile(id: String): Future[Profile] = Future {
      Thread.sleep(random.nextInt(300))
      Profile(id, names(id))
    }

    def fetchBestFriend(profile: Profile): Future[Profile] = Future {
      val bestFriend = friends(profile.id)
      Thread.sleep(random.nextInt(400))
      Profile(bestFriend, names(bestFriend))
    }
  }
  
  
  val f1 = Future{
    Thread.sleep(100)
    124
  }
  
  val f2 = Future{
    Thread.sleep(100)
    150
  }
  


  val ashok = SocialNetwork.fetchProfile("7995100761")

  ashok.onComplete {
    case Success(ashokProfile) =>
      val ram = SocialNetwork.fetchBestFriend(ashokProfile)
      ram.onComplete {
        case Success(ramProfile) => ashokProfile.poke(ramProfile)
        case Failure(e)          => e.printStackTrace()
      }
    case Failure(x) => x.printStackTrace()
  }

  val name = ashok.map(profile => profile.name)
 
  
  

  val bestFriend = ashok.map(profile => SocialNetwork.fetchBestFriend(profile))

  for {
    ashok <- SocialNetwork.fetchProfile("fb.id.1-zuck")
    bill <- SocialNetwork.fetchBestFriend(ashok)
  } ashok.poke(bill)

  Thread.sleep(5000)

  println("Name :" + name + "Best Friend:" + bestFriend)

  SocialNetwork.fetchProfile("7995100761").recover {
    case e: Exception => Profile("9988776655", "Harry")
  }

  val aFetchedProfileNoMatterWhat = SocialNetwork.fetchProfile("unknown id").recoverWith {
    case e: Throwable => SocialNetwork.fetchProfile("fb.id.0-dummy")
  }

  val fallbackResult = SocialNetwork.fetchProfile("unknown id").fallbackTo(SocialNetwork.fetchProfile("fb.id.0-dummy"))
  Thread.sleep(1000)
  println(f1.flatMap(ele => f2.map(ele2 => ele+ele2)))
}