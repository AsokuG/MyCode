package com.org

object HPE extends App {

  case class Employee(name: String, age: Int, address: String)

  val dataObject = List(
    Employee("Äshok", 27, "Prakasam"),
    Employee("Uday", 27, "Nalgonda"),
    Employee("Manoj", 32, "Nellore"),
    Employee("Prem", 37, "Warngal"),
    Employee("ÄshokReddy", 27, "Guntur"),
    Employee("Poorna", 37, "Kadapa"),
    Employee("Ravi", 32, "Ananthapur"),
    Employee("Kalyan", 32, "Khamam"))
    
    def employeeMap(list: List[Employee]): Map[Int, List[Employee]] = list.groupBy(_.age)
    
    println(employeeMap(dataObject))
    
    val map1 = Map(1 -> List("One"), 2 -> List("Two"))
    val map2 = Map(1 -> List("Uno"), 2 -> List("Duo"))
 
    
    val list = List(map1, map2)
    
   val res = list.reduceLeft((r, c) => r.foldLeft(c){
      (dist, ele) => dist + (ele._1 -> (ele._2 ++ dist.getOrElse(ele._1, List())))
    })
    
    println(res)
    
  // val mergeLists = (l1: List[String], l2: List[String]) => l1 ++ l2
   
   map1.toSeq ++ map2.toSeq
   
   import scala.collection.immutable.IntMap
 val c = IntMap(map1.toSeq:_*)
 val d = IntMap(map2.toSeq:_*)
   
   val a = IntMap(1 -> "one", 2 -> "two", 3 -> "three", 4 -> "four")
val b = IntMap(1 -> "un", 2 -> "deux", 3 -> "trois")

val merged = c.intersectionWith(d, (_, av: List[String], bv: List[String]) => av ++ bv)

val resp = a.intersectionWith(b, (_, av: String, bv: String) => List(av, bv))
println(resp)
println(merged)
   
  // def mergeMaps[U, V](map1: Map[U, V], map2: Map[U, V], (v1: List[V], v2: List[V]) => List[v]): Map[U, V] = ???
  
}