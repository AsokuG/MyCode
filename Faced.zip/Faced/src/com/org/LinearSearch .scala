package com.org

import scala.annotation.tailrec

object LinearSearch extends App  {

  def linearSearch(arr: Vector[Int], ele: Int): Int = {
    @tailrec
    def iter(index: Int): Int = {
      if (index == arr.length) -1
      else if (arr(index) == ele) index
      else iter(index + 1)
    }
    iter(0)
  }
  
  println("Linear Search :"+ linearSearch(Vector(2, 8, 4, 9, 3), 9))

}