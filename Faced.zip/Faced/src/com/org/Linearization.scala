package com.org

object Linearization extends App {

  trait BaseStep {
    def name: String = "BaseStep"
  }

  trait Step1 extends BaseStep {
    override def name = "Step1 >>" + super.name
  }

  trait Step2 extends BaseStep {
    override def name = "Step2 >>" + super.name
  }

  trait Step3 extends BaseStep {
    override def name = "Step3 >>" + super.name
  }
  /*
     * Step1 >> BaseStep >> ScalaObject >> AnyRef >> Any
     Step2 >> BaseStep >> ScalaObject >> AnyRef >> Any
    FinalStep1

    from bottom to top and from left to right
    FinalStep1 >> Step2 >> Step1 >> BaseStep
     */
  class FinalStep1 extends Step1 with Step2 {
    override def name = "FinalStep1 >> " + super.name
  }

  class FinalStep2 extends Step2 with Step1 {
    override def name = "FinalStep2 >> " // + super.name
  }

  class FinalStep3 extends Step3 with Step2 with Step1 { override def name = "FinalStep3 >> " + super.name }

  class FinalStep4 extends Step2 with Step3 with Step1 { override def name = "FinalStep4 >> " + super.name }

  println(new FinalStep1().name)
  println(new FinalStep2().name)
  println(new FinalStep3().name)
  println(new FinalStep4().name)
  
  
  trait T1 {
    def test = println("T1")
  }
  
  trait T2 {
    def test = println("T2")
  }
  
  trait T3 {
    def test = println("T3")
  }
  
  
  class Something extends T1 with T2 with T3 {
    
    override def test = super[T3].test
  }
  
  new Something().test
}