package com.org

import java.util.ArrayList

object NArrayTree extends App {

  case class Node(key: Int) {
    val child = new ArrayList[Node]()
  }

  def nodesGreaterThanX(root: Node): Int = {
    var count = 0
    if (root == null) return 0
    else {
      if (root.child.size > 1)
        count += 1
      root.child.forEach { child =>
        count += nodesGreaterThanX(child);
      }
    }
    count
  }
  
  /*
   *                                    5
   *                                    |*/
                                       
  val root = Node(5);
  root.child.add(Node(1))
  root.child.add(Node(2))
  root.child.add(Node(3))

  root.child.get(0).child.add(Node(15))
  root.child.get(1).child.add(Node(4))
  root.child.get(1).child.add(Node(5))
  root.child.get(2).child.add(Node(6))
  
  root.child.get(2).child.add(Node(9))

  val x = 5;

  println("Number of nodes have more than one child: ");
  println(nodesGreaterThanX(root));

}