package com.org

import scala.annotation.tailrec

object Servion extends App {

  val list1 = List(1, 3, 6, 8, 4)
  val list2 = List(6, 9, 2, 7, 5)
  
  val list3 = List(5, 6)

  println(list1 zip (list2))

  def customZip[A, B](l1: List[A], l2: List[B]): List[(A, B)] = {
    val accList = List[(A, B)]()
    @tailrec
    def loop(in1: List[A], in2: List[B], out: List[(A, B)]): List[(A, B)] = {
      if (in1.isEmpty || in2.isEmpty) out
      else loop(in1.tail, in2.tail, (out :+ (in1.head, in2.head)))
    }
    loop(l1, l2, accList)
  }

  println("custom zip....:" + customZip(list1, list2))
  
  
  def customZipAll[A, B](l1: List[A], l2: List[B], firstElem: A, secondElem: B): List[(A, B)] = {
    val accList = List[(A, B)]()
    @tailrec
    def loop(in1: List[A], in2: List[B], out: List[(A, B)], fele: A, sele: B): List[(A, B)] = {
      if (in1.isEmpty && in2.isEmpty) out
      else if (!in1.isEmpty && in2.isEmpty) loop(in1.tail, in2, (out :+ (in1.head, sele)), fele, sele)
      else if (in1.isEmpty && !in2.isEmpty) loop(in1, in2.tail, (out :+ (fele, in2.head)), fele, sele)
      else loop(in1.tail, in2.tail, (out :+ (in1.head, in2.head)), fele, sele)
    }
    loop(l1, l2, accList, firstElem, secondElem)
  }

  println("customZipAll......:" + customZipAll(list1, list3, 8, 9))  //List((1, 5), (3, 6), (6, 9), (8, 9), (4, 9))
  
  println("defaultZipAll......:" +list1.zipAll(list3, 8, 9))
  
  def customZipWithIndex[A, B](in: List[A], indexList: List[B]): List[(A, B)] = {
    val accList = List[(A, B)]()
   // val indexList = List.range(0, in.length)
    def loop(in: List[A], indexList: List[B], accList: List[(A, B)]): List[(A, B)] =
      if (in.isEmpty) accList
      else loop(in.tail, indexList.tail, accList :+ (in.head, indexList.head))

    loop(in, indexList, accList)
  }
  println("customZipWithIndex: " + customZipWithIndex(list2, List.range(0, list2.length)))
  
  
  def mapReduce(f: Int => Int, operator: (Int, Int) => Int, base: Int)(a: Int, b: Int): Int = {
  @tailrec
  def loop(a: Int, acc: Int): Int = {
    if(a > b) acc
    else loop(a + 1, operator(f(a), acc))
  }
  loop(a, base)
}
  
  println(mapReduce(x=>x*x, (a,b)=>a*b, 1)(3,4))  // "racecar"  length=7 index=0 mid=3 
  
  
  def solution(s: String): Int = {
    val len = s.length()
    @tailrec
    def loop(index: Int, mid: Int): Int = {
      if (index >= mid) mid
      else {
        if (s(index) == s(len - index - 1))
          loop(index + 1, mid)
        else -1
      }
    }
    if (len == 0 || len % 2 == 0) -1
    else loop(0, len / 2)
  }
  
  println(solution("racecar"))
}