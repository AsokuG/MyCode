package com.org

import scala.io.StdIn

object Result {

    /*
     * Complete the 'fizzBuzz' function below.
     *
     * The function accepts INTEGER n as parameter.
     */

    def fizzBuzz(n: Int) {
    (1 to n).map(_ match {
      case i: Int if ((i % 3) == 0 && (i % 5) == 0) => "FizzBuzz"
      case i: Int if ((i % 3) == 0)                 => "Fizz"
      case i: Int if ((i % 5) == 0)                 => "Buzz"
      case i: Int                                   => i.toString
    }).foreach(println _)

      
     /* val list = 1 to n toList 
      val threeMultiples =  list.filter(_%3==0)         
      val fiveMultiples = list.filter(_%5==0)
      val threeAndFiveMultiples = threeMultiples.intersect(fiveMultiples)
      val threeMultiplesList = threeMultiples diff threeAndFiveMultiples
      val fiveMultiplesList = fiveMultiples diff threeAndFiveMultiples
      val resultList =list diff (threeMultiples ::: fiveMultiples).distinct
      list.foreach(ele => {
      if(threeMultiplesList.contains(ele)) println("Fizz")
      else if(fiveMultiplesList.contains(ele)) println("Buzz")
      else if(threeAndFiveMultiples.contains(ele)) println("FizzBuzz")
      else println(ele)
      })*/
    }

}

object Solution {
    def main(args: Array[String]) {
        val n = StdIn.readLine.trim.toInt

        Result.fizzBuzz(n)
    }
}