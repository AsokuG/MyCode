package com.org

import scala.annotation.tailrec

object SortingDemo {

  def sortList(list: List[Int]): List[Int] = {

    @tailrec
    def insertTailRec(num: Int, sortedList: List[Int], accumulator: List[Int]): List[Int] = {
      if (sortedList.isEmpty || num <= sortedList.head) accumulator.reverse ++ (num :: sortedList)
      else insertTailRec(num, sortedList.tail, sortedList.head :: accumulator)
    }
   // insertTailRec(3, list, Nil)
    
    @tailrec
    def sortTailRec(list: List[Int], accumulator: List[Int]): List[Int] = {
      if(list.isEmpty) accumulator
      else sortTailRec(list.tail, insertTailRec(list.head, accumulator, Nil))
    }
    
    sortTailRec(list, Nil)
  }
  
  

  def main(args: Array[String]): Unit = {
   // println(sortList(List(1, 2, 4)))
    println(sortList((1 to 10000).reverse.toList))
  }
}