package com.org

object StreamSieve extends App {

  private val allPrimes: Stream[Int] = 2 #:: Stream.from(3).filter { c =>           //2 3 4 
    val primesUptoSqrt = allPrimes.takeWhile(p => p <= math.sqrt(c))
    !primesUptoSqrt.exists(p => c % p == 0)
  }

  def getPrimeNumbers(n: Int): Seq[Int] = allPrimes.take(n).toList

  println("Prime Number:" + getPrimeNumbers(10))
}