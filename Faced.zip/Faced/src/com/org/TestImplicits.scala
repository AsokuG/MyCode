package com.org

object TestImplicits extends App {

  val num = 10

  val numInString = "20"

  implicit def str2Int(str: String) = str.toInt

  println(num * numInString)
  
  println("12" + "14")
  
  
  


}