package com.org


 trait T1 {
   this : C =>
     def display() = println("T1")
  }

  trait T2 {
    def display() =  println("T2")
  }

  trait T3 {
    def display() =  println("T3")
  }
  
  class C extends T1 with T2 with T3 {
    override def display() = println("hello")
    
   // display
  }

object Tts extends App {
 new C().display()

}