package com.org.prac

object Classes extends App  {

  class Brain private (isExist: Boolean) {
    override def toString = "This is the brain."
  }

  object Brain {
    val brain = new Brain(true)
    def getInstance = brain
  }
  
  def printAll(numbers: Int*) {
    numbers.foreach(println)
  }
  
  printAll()

}