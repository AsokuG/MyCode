package com.org.prac

object CustomPatternMatching extends App {

  /*
   * PM
   - constants
   - strings
   - singletons
   - case classes
   - tuples
   - collections
   */

  class Pet(var name: String, var age: Int)

  object Pet {
    def unapply(pet: Pet): Option[(String, Int)] = {
      if (pet.age < 1) None
      else Some((pet.name, pet.age))
    }

    def unapply(age: Int): Option[(String)] = {
      if (age < 1) Some("cub")
      else Some("adult Pet")
    }
  }


  val garfield = new Pet("Garfield", 102)

  val garfieldPM = garfield match {
    case Pet(n, a) => s"I'm $n, I'm $a yo"
  }

  val garfieldStatus = garfield.age match {
    case Pet(status) => s"Garfield is a $status"
  }
  
  
  println(garfieldPM)
  println(garfieldStatus)

}