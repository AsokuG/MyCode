package com.org.prac

import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global
import scala.util.Success
import scala.util.Failure

object Test extends App{
  
  case class Person(name: String, age: Int, address: String)

  val personList = List(
    Person("Ram", 30, "Hyderabad"),
    Person("Rajesh", 25, "Hyderabad"),
    Person("Ramesh", 28, "Hyderabad"),
    Person("Suresh", 22, "Hyderabad"),
    Person("Suraj", 38, "Hyderabad"))
    
    for{
     person <- personList
     if(person.age >=30)
    } yield println("name: "+person.name +" "+"age: "+person.age)
    
    personList.filter(_.age>=30).foreach(person => println(person.name))
    
    val list1 = List(1, 2, 3, 4, 5)
    val list2 = List(6, 7, 8)
    
    list1.zip(list2)
    
  //  println(list1.zipWithIndex)
    
    def customZip(list1: List[Int], list2: List[Int], fele: Int, sele: Int): List[(Int, Int)] ={
    val acc = List[(Int, Int)]()
    def loop(in1: List[Int], in2: List[Int], out: List[(Int, Int)], fele: Int, sele: Int): List[(Int, Int)] = (in1, in2) match {
      case (in1, in2) if (in1.isEmpty && in2.isEmpty)   => out
      case (in1, in2) if (!in1.isEmpty && in2.isEmpty)  => loop(in1.tail, in2, out :+ (in1.head, sele), fele, sele)
      case (in1, in2) if (in1.isEmpty && !in2.isEmpty)  => loop(in1.tail, in2, out :+ (fele, in2.head), fele, sele)
      case (in1, in2) if (!in1.isEmpty && !in2.isEmpty) => loop(in1.tail, in2.tail, out :+ (in1.head, in2.head), fele, sele)
    }
    loop(list1, list2, acc, fele, sele)
  }
  
 println(customZip(list1, list2, 0, 0)) // List((1, 6), (2, 7), (3, 8), (4, 2), (5, 2))
 def custom(list: List[Int]): Int = {
    var acc = 0
    def sum(list: List[Int], acc: Int): Int = list match {
      case Nil       => acc
      case h :: tail => sum(tail, h + acc) // h + sum(tail)
    }
    sum(list, acc)
  }
 
 println(list1.foldLeft(0)(_+_)) // 0
 
 println(custom(List(1, 2, 3, 4,5, 6, 7, 8, 9, 10)))
 
    val sumInFut: Future[Int] = Future{custom(List(1, 2, 3, 4,5, 6, 7, 8, 9, 10))}
    
    sumInFut.flatMap(f => Future(f*f)).onComplete {
      case Success(value) => println(value)
      case Failure(ex) => println("Exception: " + ex)
    }
    
    Thread.sleep(1000)
    
    
    class Outer {
      
      class Inner {
        var x= 10
      }
    }
    
    val outer = new Outer
    val inner =  new outer.Inner
    
    println(inner.x)
    
    inner.x=200
     println(inner.x)
    
}