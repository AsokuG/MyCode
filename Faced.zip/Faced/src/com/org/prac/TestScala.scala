package com.org.prac

import scala.annotation.tailrec

object TestScala extends App {
  
  val list1 = List(1, 2, 3, 4)
  val list2 = List(5, 6, 7, 8)
  
val result =  for{    
    l1 <- list1
    l2 <- list2
  } yield l1+l2
  
  println(result)
  
 val res = list1.flatMap{ x=> list2.map(_ +x)}
  
  println(res)
  
  val ls = List("a", "a", "a", "a", "b", "c", "c", "a", "a", "d", "e", "e", "e", "e","a")

println( ls.foldLeft(List[String]())((l,x)=> if(l.size==0 || l.last!=x)l++List(x) else l) )

def findDuplicate(ls:List[String])={
@tailrec
def find(l1:List[String],l2:List[String]):List[String]={
l1 match {
case h::t =>
if(l2.size==0 || l2.last!=h) find(t,l2++List(h) ) else find(t,l2)

case _=> l2
}
}
find(ls,List[String]())
}



println ( findDuplicate(ls) )

def removeDuplicates(list: List[Char]): List[Char] = {
    def go(list: List[Char], acc: List[Char]): List[Char] = list match {
      case Nil          => acc
      case head :: tail => go(tail.dropWhile(_ == head), acc :+ head)  //filterNot
    }
    go(list, Nil)
  }

println(removeDuplicates(List('a', 'a', 'a', 'a', 'b', 'c', 'c', 'a', 'a', 'd', 'e', 'e', 'e', 'e', 'a')))

println(removeDuplicates(List('a', 'b', 'a', 'c', 'b')))

println ( List(1,2,3,4,5) collect { case x if x%2==0 => x} )
  
}