package com.metrogroup

trait Animal {
  
}