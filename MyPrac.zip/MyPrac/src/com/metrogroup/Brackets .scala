package com.metrogroup

import scala.annotation.tailrec

object Brackets extends App  {

  def solution(str: String): Int = {


   @tailrec
    def go(i: Int, list: List[Char]): Int = {

      if (i >= str.length) {
        if (list.nonEmpty) 0 else 1
      } else {
        str(i) match {

          case '{' | '[' | '(' => go(i + 1, str(i) :: list)

          case '}' =>
            list match {
              case Nil                         => 0
              case head :: tail if head == '{' => go(i + 1, tail)
              case _                           => go(i + 1, list)
            }

          case ']' =>
            list match {
              case Nil                         => 0
              case head :: tail if head == '[' => go(i + 1, tail)
              case _                           => go(i + 1, list)
            }

          case ')' =>
            list match {
              case Nil                         => 0
              case head :: tail if head == '(' => go(i + 1, tail)
              case _                           => go(i + 1, list)
            }
        }
      }
      
    }
    go(0, List.empty)
  }
println(solution("{}"))  // List("{"),   List("[", "{"), List("(", "[", "{")  3   4 List("[", "{")  5 List("(", "[", "{")  6 List("[", "{")  7  List("{")
//println(solution("([)()]")) // List("[", "(")

def solution1(str: String): Boolean = {
    def loop(index: Int, numOpen: Int): Boolean = {
      if (index >= str.length()) numOpen == 0
      else {
        val ch = str.charAt(index)
        if (ch == '(') loop(index + 1, numOpen + 1)
        else if (ch == ')') loop(index + 1, numOpen - 1)
        else loop(index + 1, numOpen)
      }
    }
    loop(0, 0)
  }

println(solution1("(()(())())"))


def solution2(str: String): Int ={
    str.foldLeft(0)((index, ele) => {
      if (index < 0) index
      else {
        ele match {
          case '(' => index + 1
          case ')' => index - 1
          case _   => index
        }

      }
    })
  }

println(solution2("(()(())())"))

/* abstract class Fruit 
  class Apple extends Fruit
  class Orange extends Fruit
  
  val apples = new Apple :: Nil*/
}