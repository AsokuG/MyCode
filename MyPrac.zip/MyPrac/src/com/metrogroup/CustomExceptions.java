package com.metrogroup;

public class CustomExceptions extends Exception{
	  public CustomExceptions(String s) 
	    { 
	        // Call constructor of parent Exception 
	        super(s); 
			}

	}