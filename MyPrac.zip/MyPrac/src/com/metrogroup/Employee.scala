package com.metrogroup



object Employee extends App{
  case class Employee (id: Int,name: String,salary: Double) extends Ordered[Employee]() {
  def compare(that: Employee) = this.name compare that.name
  }
  val firstEmp = Employee(1, "michael", 12000.00)
  val secondEmp = Employee(2, "james", 12000.00)
  val thirdEmp = Employee(3, "shaun", 12000.00)
  val forthEmp = Employee(4,"michael",11000.00)
  val fifthEmp = Employee(5,"michael",15000.00)
  val empList = List(firstEmp,secondEmp,thirdEmp, forthEmp, fifthEmp)
   println(empList)
   println(empList.sorted)
 
 
  

}