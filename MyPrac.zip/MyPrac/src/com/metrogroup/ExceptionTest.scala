package com.metrogroup

object ExceptionTest extends App {
  

  

  def m1() = {
    try {
      println("Hellooooo")
      for (i <- 2 to 10 by 2) {
        try {

          foo(i, if (i == 4) 0 else 2)
          println("Hiiiiiiiiii")
        } catch {
          case e: Exception => println("only specific exceptions handled here" + " " + e.getMessage)
        }
      }
    } catch {
      case e: Exception => println("Main Method Handles All the Exception")
    }

  }

  def foo(a: Int, b: Int) {
    try {
      val c = a / b
    } catch {
      case e: Exception =>  throw new CustomExceptions("Hello")
    }
  }

  m1()

}