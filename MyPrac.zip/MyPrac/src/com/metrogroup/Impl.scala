package com.metrogroup

class Impl {
  
def findAnInt(implicit x : Int) = x

def speaker(name: String)(implicit language: String= "French") = {
 println(s"$name can speak $language")
 }

def speakerOne(){
 implicit val english = "English"
 speaker("John")
 }

def speakerTwo(){
 implicit val hindi = "Hindi"
 speaker("Henry")
 }

def speakerThree(){
 speaker("Shivangi")
 }
  
}

object Impl extends App {
  implicit val value = 5
  val imp = new Impl()
  println(imp.findAnInt(10))
  println(imp.speakerThree())
}