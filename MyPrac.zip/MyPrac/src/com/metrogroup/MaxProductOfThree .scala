package com.metrogroup

object MaxProductOfThree extends App  {

  def solution(arr: Array[Int]): Int = {
    val sortArr = arr.sorted
    val arrLength = arr.length
    val maxP = sortArr(arrLength - 1) * sortArr(arrLength - 2) * sortArr(arrLength - 3)
    val maxN = sortArr(0) * sortArr(1) * sortArr(arrLength - 1)
    Math.max(maxN, maxP)
  }

  println(solution(Array(-3, 1, 2, -2, 5, 6))) // -3, -2, 1, 2, 5, 6   6   2*5*6=60   -3*1*6=-18
  
  println(solution(Array(3, 5, 7, 9, 10, -12, -25))) // -25, -12, 3, 5, 7, 9, 10 7*9*10=630 -25*-12*10=3000
  
  println(solution(Array(-3, -20, -1, -6, -90, -12, -12))) // -90, -20, -12, -12, -6, -3, -1 -90*-20*-1=-1800  -6*-3*-1=-18

}