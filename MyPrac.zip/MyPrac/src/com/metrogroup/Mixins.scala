package com.metrogroup

trait Tail{
  def wagTail {
    println("Tail is wagging.")
  }
}
  
  abstract class Pet(name: String){
    def speak
    def ownerIsHome{println("excited")}
    def jumpForJoy{
      println("Jump For Joy.")
    }
  
  
  def stopTail{
    println("tail is stopping.")
  }
}

class Dog(name: String) extends Pet(name) with Tail {
  def speak { println("Bow Bow Bow........Bowwwwwww") }
  override def ownerIsHome {
    wagTail
    speak
  }

}

object Mixins extends App {
  val dog = new Dog("dog")
  dog.ownerIsHome
  dog.jumpForJoy
}