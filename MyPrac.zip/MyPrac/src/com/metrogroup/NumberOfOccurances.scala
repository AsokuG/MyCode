package com.metrogroup

import scala.collection.mutable.ListBuffer

object NumberOfOccurances extends App {
  val str = "aabbacaadd"
  //aa,bbac,aa,dd
  val sb = new StringBuffer(str)
  val list = List("aa", "a")
  var lb = ListBuffer[Int]()
  var (count, fromIndex) = (0, 0)
  list.foreach(ele => {
    fromIndex = 0
    while (fromIndex < str.length()) {
      if (str.indexOf(ele, fromIndex) == fromIndex) {
        if (!lb.contains(fromIndex)) {
         // println(fromIndex)
          val initial = lb.contains(0)
          val count = lb.filter(ele => ele < fromIndex && ele != 0).size
          val nrOfDelimiters = if (initial) count * 2 + 1 else count * 2
          if (fromIndex == 0 && ele.length() > 1) { sb.insert(fromIndex + ele.length(), ",") }
          else if (fromIndex == 0) { sb.insert(fromIndex + 1, ",") }
          else if (ele.length() > 1) { sb.insert(fromIndex + nrOfDelimiters, ","); sb.insert(fromIndex + nrOfDelimiters + ele.length() + 1, ",") }
          else { sb.insert(fromIndex + nrOfDelimiters, ","); sb.insert(fromIndex + nrOfDelimiters + ele.length() + 1, ",") }
          lb += fromIndex
        }
      }
      fromIndex += 1
    }
  })
  println(sb)
  println(sb.toString().split(",").filter(_ != "").map(ele => ele.trim.toString).toList)

}