package com.metrogroup

class PariFun {
  def isEven(x :Int) = x % 2 == 0
  def square(x: Int) = x * x
 val squareRoot: PartialFunction[Double, Double] = {
 case x if x > 0 => scala.math.sqrt(x)
 }  //Function can only be applied but it can not be queried.
  
  def callSquareRoot(x: Int) = {
 if(squareRoot.isDefinedAt(x)) squareRoot(x)
 }
  
  val divide: PartialFunction[(Double, Double), Double] = {
     case (dividend, divisor) if divisor != 0 => dividend / divisor
     }
  
 
}

object PariFun extends App {
  val pf = new PariFun()
  println(pf.isEven(6))
  println(pf.square(5))
 // println(pf.callSquareRoot(4))
 // println(pf.squareRoot(pf.divide(25, 5)))
  //pf.divide.andThen(pf.callSquareRoot)(50, 2)
  println(pf.divide.andThen(pf.squareRoot)(50, 2))
  println(pf.squareRoot.compose(pf.divide)(50,2))
  println(pf.squareRoot.applyOrElse(16.0, (x: Double) => 0.0))
}