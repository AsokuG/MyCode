package com.metrogroup

object PartialFunctions extends App {

  val doubleThePositiveNumber = new PartialFunction[Int, Int] {
    def apply(data: Int) = data * 2
    def isDefinedAt(data: Int) = data > 0
  }
  
  println(doubleThePositiveNumber(-1))
}