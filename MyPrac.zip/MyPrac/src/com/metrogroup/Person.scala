package com.metrogroup



class Person(val firstName: String, val lastName: String)

object Person{
  def apply(firstName: String, lastName: String) 
        = new Person(firstName, lastName)

    def unapply(p: Person): (String,String) 
        = (p.firstName, p.lastName)
}


