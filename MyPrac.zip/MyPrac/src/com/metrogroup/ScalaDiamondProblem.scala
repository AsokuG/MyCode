package com.metrogroup

trait A {
  def disp(){println("From A Display")}
}

trait B extends A{
 override def disp(){println("From B Display")}
 //super.disp()
}

trait C extends A {
 override def disp(){println("From C Display")}
  //super.disp()
}

class D extends B with C with A

//B >> A >> ScalaObj >> Anyref >> Any c >> A >> 
// D >> C >> B >> A

object ScalaDiamondProblem extends App {
 val d = new D
 
 d disp
}