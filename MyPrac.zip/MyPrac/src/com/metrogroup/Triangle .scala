package com.metrogroup

object Triangle extends App  {

  def solution(arr: Array[Int]): Int = {

    scala.util.Sorting.quickSort(arr)
    def loop(idx: Int): Int = {
      if (idx >= arr.length - 2) 0
      else if (arr(idx) <= 0) loop(idx + 1)
      else {
        val currentTrio = (arr(idx) + arr(idx + 1)) - arr(idx + 2)
        if (currentTrio > 0) 1
        else loop(idx + 1)
      }
      0
    }
    loop(0)
  }
  
   println(solution(Array(10, 2, 5, 1, 8, 20))) //  1, 2, 5, 8, 10, 20     1+2-5=-3
   println(solution(Array(10, 50, 5, 1))) // 1, 5, 10, 50
   println(solution(Array(1, 1, 1)))

}