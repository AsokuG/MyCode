

object Checking extends App {
  val name = "Ashok"
 val result = if(true) {(name=="Soku") match {
      case true  => "Yes, Ashok Gangineni here!"
      case false => "He is Not Ashok Gangineni"
    }
  } else "Hello! Ashok"
    
    println("performed result :" + result)
    
    case class ArtInfoEntity(art: Int, vari: Int, geb: Int, vkGebi: Int, Qty: Float) 
  val filtered =  List(ArtInfoEntity(12345, 1, 2, 2, 5f), ArtInfoEntity(12345, 1, 2, 1, 8f)).groupBy((ele => (ele.art, ele.vari, ele.geb)))
  println(filtered)
}