import java.util.Date
import java.util.Calendar
import java.text.SimpleDateFormat


object DateTimeTest extends App {

   val dateTimeFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss")
  
  def atEndOfDay(date: Date): Date = {
    val calendar = Calendar.getInstance();
    calendar.setTime(date);
    calendar.set(Calendar.HOUR_OF_DAY, 23);
    calendar.set(Calendar.MINUTE, 59);
    calendar.set(Calendar.SECOND, 59);
    calendar.set(Calendar.MILLISECOND, 999);
    return calendar.getTime();
  }
  
  println(atEndOfDay(new Date()))
  
  println( new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").getCalendar)
  
  println(dateTimeFormat.format(new Date()))

}