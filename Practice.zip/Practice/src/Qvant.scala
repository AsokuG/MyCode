import scala.util

object Qvant extends App{
  
 
  
 def sumZero(n: Int): Array[Int] = {
val a = (Array(n-1, (n-(n*3)), n+1))
a.map(ele => println(ele))
a
  }
 
 sumZero(5) 
 
 scala.util.Try{
   1.0/2.0
 }.toOption.map(ele => println(ele))
 
 
}