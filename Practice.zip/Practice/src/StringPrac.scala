import scala.annotation.tailrec


object StringPrac extends App {

  def reverse(s: String): String = {
    @tailrec
    def iter(s: String, acc: String): String = {
      if (s.isEmpty() || s == null) acc.toString()
      else iter(s.tail, s.head + acc)
    }
    iter(s, "")
  }

  println("Reverse a given string :" + reverse("Ashok"))

  def custReverse(s: String): String = {
    s.foldLeft("")((r, c) => c + r)
  }

  println("Reverse string :" + custReverse("gangineni"))

  //aaabaabcc

  def contains(s: String): Boolean = {
    val indexOfB = s.indexOf('b')
    val listOfIndexsOfA = s.zipWithIndex.filter(_._1 == 'a').map(_._2)
    listOfIndexsOfA.forall(_ < indexOfB)
  }

  println("check :" + contains("aaabbcc"))

  val reg = "[0-9]+".r
  val reg1 = "([0-9]+)([A-Za-z]+)".r
  val reg2 = "movies (\\d{5})".r
  val reg3 = "movies near ([a-z]+), ([a-z]{2})".r
  
  
  //find the index of a character in a string 
  
  "Äshok".zipWithIndex.filter(_._1=='o').headOption
  
  
 def findIndx(s: String, c: Char): Int = {
    @tailrec
    def iter(s: String, c: Char, index: Int): Int = {
      if(index==s.length()) -1
      else if(s(index)==c) index
      else iter(s, c, index+1)
    }
    iter(s, c, 0)
  }
  
  println("Index is: "+findIndx("Ashok", 'o'))
}