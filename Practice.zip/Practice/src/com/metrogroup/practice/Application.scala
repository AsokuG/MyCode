package com.metrogroup.practice

object Application extends App {

  val list = (1 to 5).toList
  val customMapsObject = CustomMap[Int, Int](list)
  val mapLambda = (x: Int) => x * 2
  val addSubUnity = (x: Int) => List(x - 1, x + 1) //another a lambda for flatMap method
  val mapResult = customMapsObject.customMap(mapLambda)
  val flatMapResult = customMapsObject.customFlatMap(addSubUnity)
  println("(===========> printing result of custom map ")
  println(mapResult) // 1, 2, 3, 4, 5
  println("(===========> printing result of custom flatMap ")
  println(flatMapResult)

}