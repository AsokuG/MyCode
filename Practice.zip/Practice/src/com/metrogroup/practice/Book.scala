package com.metrogroup.practice

abstract class Card(id: Int) {

 def printCardDetails: Unit

 }

 case class Book(id: Int, name: String, cvv: Int) extends Card(id) {

 override def printCardDetails: Unit = {
 print(id + " " + name + " " + cvv)
 }
 def main(args: Array[String]){
   
   val debitCardObject: Card = Book(1,"Aman",312)
  
  println(debitCardObject)
 }
  
 }

 
