package com.metrogroup.practice

object Currency extends Enumeration {
  
 //val ADD = Value("ADD")
 
 type Currency = Value
 
 val CNY, GBY, INR = Value
  
}

object Curr extends App {
 Currency.values.foreach(println) 
}