package com.metrogroup.practice

import scala.util.Random

object CustomerId extends App {

  def apply(name: String) = s"$name--${Random.nextLong}"

  def unapply(CustomerId: String): Option[String] = {
    val strArray: Array[String] = CustomerId.split("--")
    if (strArray.tail.nonEmpty) Some(strArray.head) else None

  }

  case class Message(sender: String, recipient: String, body: String)
  val message2 = Message("jorge@catalonia.es", "guillaume@quebec.ca", "Com va?")
  val message3 = Message("jorge@catalonia.es", "guillaume@quebec.ca", "Com va?")
  val messagesAreTheSame = message2 == message3
  println(messagesAreTheSame)

  val customerId = CustomerId("Ashok")
  val customer2ID = CustomerId("Nico")
  val CustomerId(name) = customer2ID
  println(name)

  customerId match {
    case CustomerId(name) => println(name)

    case _                => println("")
  }

}