package com.metrogroup.practice

import java.text.SimpleDateFormat
import java.util.Date

object Dt extends App {
    val df= new SimpleDateFormat("yyyy-mm-dd")
   
  def getDate(dtStr: String): java.util.Date  = {
     
      if (dtStr == null || dtStr.trim().equals("")) {
        new Date()
      }else
        df.parse(dtStr)
   
  }
   
  println(getDate("2018-09-19"))
  
}