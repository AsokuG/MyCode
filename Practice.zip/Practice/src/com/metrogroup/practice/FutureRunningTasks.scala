package com.metrogroup.practice

import scala.concurrent.Future


import scala.concurrent.ExecutionContext.Implicits.global

object FutureRunningTasks {
  val list = (1 to 20).toList
  def futureTask: Future[List[Int]] = Future {
    Thread.sleep(1234)
    list.map(_ * 2)
}
}