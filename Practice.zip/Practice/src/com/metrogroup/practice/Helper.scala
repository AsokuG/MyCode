package com.metrogroup.practice

trait Helper extends DelayedInit {

  val x: Int = 10
  val y: Int = 5

  def addition(x: Int, y: Int): Unit
  def subtraction(x: Int, y: Int): Unit
  def multiplication(x: Int, y: Int): Unit
  def division(x: Int, y: Int): Unit

  override def delayedInit(body: => Unit) = {
    addition(x, y)
    subtraction(x, y)
    multiplication(x, y)
    division(x, y)
   // body
  }
}