package com.metrogroup.practice

object Hero extends App  {
  override def main(args: Array[String]): Unit = {
    println("HI, Ashok")  
  }
 
 /* override def delayedInit(body: => Unit): Unit = {
   println("Hello, Ashok")
   body
  }*/
 println("Hello Scala")
 
  
}