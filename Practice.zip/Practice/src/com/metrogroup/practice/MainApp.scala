package com.metrogroup.practice

object MainApp extends App with Helper{
  
/**
* This is used to calculate sum of two number
*
* @param x
* @param y
*/
def addition(x: Int, y: Int): Unit = {
println(s"$x + $y = ${x + y}")
}

/**
* This is used to subtract second number from first number
*
* @param x
* @param y
*/
def subtraction(x: Int, y: Int): Unit = {
println(s"$x - $y = ${x - y}")
}

/**
* This is used to calculate multiplication of two number
*
* @param x
* @param y
*/
def multiplication(x: Int, y: Int): Unit = {
println(s"$x * $y = ${x * y}")
}

/**
* This is used to divide first number with second number
*
* @param x
* @param y
*/
def division(x: Int, y: Int): Unit = {
println(s"$x / $y = ${x / y}")
}

println("WOW: All methods have been executed successfully!")
  
}