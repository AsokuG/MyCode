package com.metrogroup.practice

case class EmailAccount(
    accountName: String,
    url: String,
    username: String,
    password: String,
    minutesBetweenChecks: Int,
    usersOfInterest: List[String]
)

object ParseJsonArray extends App  {
  
   val jsonString ="""
    {
      "accounts": [
    { "emailAccount": {
      "accountName": "YMail",
      "username": "USERNAME",
      "password": "PASSWORD",
      "url": "imap.yahoo.com",
      "minutesBetweenChecks": 1,
      "usersOfInterest": ["barney", "betty", "wilma"]
    }},
    { "emailAccount": {
      "accountName": "Gmail",
      "username": "USER",
      "password": "PASS",
      "url": "imap.gmail.com",
      "minutesBetweenChecks": 1,
      "usersOfInterest": ["pebbles", "bam-bam"]
    }}]}
    """
   
    val json = net.liftweb.json.parse(jsonString)
     val elements = (json \\ "emailAccount").children
    for (acct <- elements) {
       println(acct)
        //println(s"Account: ${m.url}, ${m.username}, ${m.password}")
        //println(" Users: " + m.usersOfInterest.mkString(","))
    }
  
}