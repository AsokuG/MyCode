package com.metrogroup.practice

import net.liftweb.json.DefaultFormats

object SarahEmailPluginConfigTest {
  
implicit val formats = DefaultFormats
case class Mailserver(url: String, username: String, password: String)
val json = net.liftweb.json.parse(
"""
{ 
  "url": "imap.yahoo.com",
  "username": "myusername",
  "password": "mypassword"
}
"""
)
  def main(args: Array[String]) {
 //  val parsedJson = net.liftweb.json.parse(json.mkString)
  
  val m = json.extract[Mailserver]
   println(m.url)
  }

}