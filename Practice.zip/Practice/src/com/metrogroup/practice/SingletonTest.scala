package com.metrogroup.practice

class Brain private(val name: String)

object Brain{
  val brain = new Brain("mybrain")
  def getInstance = brain
}

object SingletonTest extends App {
  
  println(Brain.getInstance.name)
  
}