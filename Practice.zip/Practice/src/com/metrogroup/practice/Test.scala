package com.metrogroup.practice

object Test extends App {

  abstract class Card(id: Int) {

    def printCardDetails: Unit

  }

  trait Message {
    def id: String
    def content: String
  }

  case class DebitCard(id: Int, name: String, cvv: Int) extends Card(id) {

    override def printCardDetails: Unit = {
      print(id + " " + name + " " + cvv)
    }
  }
  
  case class Book(id : Int)(title : String)
  
 println(Book(1)("Hello, Ashok") == Book(1)("HI, Ashok"))

  case class DefaultMessage(id: String, content: String) extends Message
  
  val defaultMessage: Message =    DefaultMessage("A121","Hello everyone..!!")
  
  println(defaultMessage)

  val debitCardObject: Card = DebitCard(1, "Aman", 312)

  println(debitCardObject)

}