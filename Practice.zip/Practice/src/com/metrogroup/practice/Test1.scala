package com.metrogroup.practice

case class UseId(id: Int)

case class Username(name: String)

case class TweetId(id: Int)

case class TweetContent(content: String)

case class User(id: UseId, name: Username)

case class Tweet(id: TweetId, content: TweetContent)

object Test1 extends App {
  
  val user = User(UseId(1), Username("kunal"))

  val tweet = Tweet(TweetId(11), TweetContent("ABC"))

  println("userID :-" + user.id)
println("tweetID:-" + tweet.content)
  
}