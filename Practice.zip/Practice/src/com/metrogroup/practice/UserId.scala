package com.metrogroup.practice

class UserId(val id: Int) extends AnyVal