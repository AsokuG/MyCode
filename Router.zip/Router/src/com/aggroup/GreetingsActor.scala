package com.aggroup

import akka.actor.Actor
import akka.actor.Props
import akka.routing.RoundRobinPool

object GreetingsActor {
  
  def props = Props(classOf[GreetingsActor])

  def propsWithDispatcherAndRoundRobinRouter(dispatcher: String, nrOfInstances: Int): Props = {
    props.withDispatcher(dispatcher).withRouter(RoundRobinPool(nrOfInstances = nrOfInstances))
}
  
}

class GreetingsActor extends Actor {
  
}