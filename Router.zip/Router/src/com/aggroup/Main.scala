package com.aggroup

import akka.actor.ActorSystem
import akka.actor.ActorRef

object Main extends App {
  
   val config = ConfigFactory.load()

  val _system: ActorSystem = ActorSystem.create("hello-system", config.getConfig("configuration"))
  val supervisor: ActorRef = _system.actorOf(SupervisorActor.props, name = "supervisor")

  supervisor ! Language("hindi")

  supervisor ! Hello(1)
  supervisor ! Hello(2)
  supervisor ! Hello(3)

supervisor ! Count()
  
}