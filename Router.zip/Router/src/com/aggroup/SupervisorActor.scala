package com.aggroup

import akka.actor.Actor
import akka.actor.Props
import akka.actor.ActorRef

case class Count()
case class CountResponse(count: Int)

class SupervisorActor extends Actor {
  
  val greeter: ActorRef = context.actorOf(
    GreetingsActor.propsWithDispatcherAndRandomPoolRouter("default-dispatcher",3),
    name = "greeter"
  )
  val rogue: ActorRef = context.actorOf(RogueActor.props.withDispatcher("rogue-dispatcher"), name = "rogue")

  override def receive: Receive = {
    case x: Hello => { greeter ! x }

    case response: HelloResponse =>  println( response.response )

    case c: Count => greeter ! c

    case c: CountResponse => println(s"Count Response: ${c}")

    case l: Language => greeter ! l

    case r: RogueRequest => rogue ! r

    case _ => unhandled()

}
  
}


object SupervisorActor {
  def props = Props(classOf[SupervisorActor])
}