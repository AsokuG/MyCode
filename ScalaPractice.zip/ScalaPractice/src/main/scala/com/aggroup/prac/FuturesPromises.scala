package com.aggroup.prac

import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global
import scala.util.{Failure, Success}

object FuturesPromises extends App {

  def calculateMeainingOfLife: Int = {
    Thread.sleep(2000)
    42
  }

  val aFuture = Future{
    calculateMeainingOfLife
  }

  println(aFuture.value)
  aFuture.onComplete{
    case Success(value) => println(s"meaing of the life is ${value}")
    case Failure(exception) => println(s"I have failed with ${exception}")
  }
  println(aFuture.value)


  Thread.sleep(3000)

  case class Profile(id: String, name: String)
  def poke(anotherProfile: Profile): Unit = {
    println(s"${anotherProfile.id} poking ${anotherProfile.name}")
  }

  object SocialNetwork{
    val names = Map("fb.id.1.zuck"->"Zuck",
    "fb.id.2.bill" -> "Bill")
  }
}
