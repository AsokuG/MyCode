package com.aggroup.prac

object Prac {

}
