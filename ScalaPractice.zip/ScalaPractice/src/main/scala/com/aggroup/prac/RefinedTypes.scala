package com.aggroup.prac

import eu.timepit.refined.numeric.Interval.OpenClosed
import eu.timepit.refined.string.{EndsWith, MatchesRegex, Regex}

object RefinedTypes {

  case class User(name: String, email: String)

  val ashok = User("Ashok", "soku.gangineni@yahoo.com")

  import eu.timepit.refined.api.Refined
  import eu.timepit.refined.auto._ // implicit conversions
  import eu.timepit.refined.numeric._ // predicate for numeric types

  val aPositiveInteger: Refined[Int, Positive] = 42

 // val aInvalidIntger: Refined[Int, Positive] = -42

  val onlyNegative: Refined[Int, Negative] = -100

  val anEvenNumber: Int Refined Even = 24

  import eu.timepit.refined.W //shapeless.Witness
  val smallEnough: Int Refined Less[W.`100`.T]=45
  val zeroToHundered: Int Refined OpenClosed[W.`0`.T, W.`100`.T] = 56
  val divisibleByFive: Int Refined Divisible[W.`5`.T] = 25

  val coomandPromot: String Refined EndsWith[W.`"$"`.T] = "Ashok$"

  val isRegex: String Refined Regex = "rege(x(es)?|xps?)"

  type Email = String Refined MatchesRegex[W.`"""[a-z0-9]+@[a-z0-9]+\\.[a-z0-9]{2,}"""`.T]
  type SimpleName = String Refined MatchesRegex[W.`"""[A-Z][a-z]+"""`.T]

  case class ProperUser(name: SimpleName, email: Email)
 val ashokName: SimpleName = "Ashok"
  val ashokEmails: Email = "gangineniashok19@gmail.com"

  val ashokUser = ProperUser(ashokName, ashokEmails)

  import eu.timepit.refined.api.RefType

  val poorEmail = "ashok"
  val refineCheck = RefType.applyRef[Email](poorEmail)

  def main(arges: Array[String]): Unit = {
 println(refineCheck)
  }

}
