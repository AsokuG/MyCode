package com.aggroup.prac

case class Student() {

}