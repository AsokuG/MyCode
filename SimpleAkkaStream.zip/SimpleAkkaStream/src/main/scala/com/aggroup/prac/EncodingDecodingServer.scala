package com.aggroup.prac

import akka.http.scaladsl.coding.{Gzip, NoCoding}
import akka.http.scaladsl.model.StatusCodes
import akka.http.scaladsl.server.HttpApp
import com.typesafe.config.ConfigFactory
import akka.http.scaladsl.settings.ServerSettings


object EncodingDecodingServer extends HttpApp {

  val routes =
    post {
      decodeRequestWith(Gzip, NoCoding){
        entity(as[String]){StringEntity =>
          encodeResponse {
            complete {
              println(s"Received $StringEntity")
              StatusCodes.OK -> s"Thank you for your encoded request [$StringEntity]."
            }
          }

        }
      }
    }

}

object EncodingDecodingServerApplication extends App {
  EncodingDecodingServer.startServer("0.0.0.0", 8088, ServerSettings(ConfigFactory.load))
}
