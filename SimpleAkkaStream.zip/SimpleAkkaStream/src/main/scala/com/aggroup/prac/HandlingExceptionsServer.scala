package com.aggroup.prac

import akka.actor.{ActorRef, ActorSystem, Props}
import akka.http.scaladsl.server.HttpApp
import akka.http.scaladsl.settings.ServerSettings
import akka.util.Timeout
import akka.pattern.ask
import com.typesafe.config.ConfigFactory

import scala.concurrent.duration._

class HandlingExceptionsServer(someRef: ActorRef) extends HttpApp with RouteExceptionHandler {

  implicit val timeout = Timeout(500 millis)

  val routes = handleExceptions(routeExceptionHandler) {
    path("divide") {
      parameters('a.as[Int], 'b.as[Int]) { (a, b) =>
        complete {
          val result = a / b
          s"Result is: $result"
        }

      }
    } ~
      path("futureTimingOut") {
        onSuccess(someRef ? "Something") {
          case _ => complete("Actor finished processing.")
        }
      }
  }
}

object HandlingExceptionsApplication extends App {
  val unresponsiveActor = ActorSystem().actorOf(Props[UnresponsiveActor])
  new HandlingExceptionsServer(unresponsiveActor).startServer("0.0.0.0", 8085, ServerSettings(ConfigFactory.load))
}

