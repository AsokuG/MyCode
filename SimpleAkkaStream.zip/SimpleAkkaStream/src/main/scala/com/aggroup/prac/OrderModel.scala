package com.aggroup.prac

import akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport

import spray.json.DefaultJsonProtocol

import scala.xml._

import akka.http.scaladsl.marshallers.xml.ScalaXmlSupport

case class Item(id: Int, quantity: Int, unitPrice: Double, percentageDiscount: Option[Double])

case class Order(id: String, timeStamp: Long, items: List[Item], deliveryPrice: Double, metaData: Map[String, String])

case class GrandTotal(id: String, amount: Double)

trait OrderJsonSupport extends SprayJsonSupport with DefaultJsonProtocol {
  implicit val itemFormat = jsonFormat4(Item)
  implicit val orderFormat = jsonFormat5(Order)
  implicit val grandTotalFormat = jsonFormat2(GrandTotal)
}


trait OrderXmlSupport extends ScalaXmlSupport {
  implicit def grandTotalToXML(g: GrandTotal): NodeSeq =
    <grandTotal>
      <id>
        {g.id}
      </id>
      <amount>
        {g.amount}
      </amount>
    </grandTotal>

  implicit def orderToXML(o: Order): NodeSeq =
    <order>
      <id>
        {o.id}
      </id>
      <timeStamp>
        {o.timeStamp}
      </timeStamp>
      <items>
        {o.items.map(itemToXML)}
      </items>
      <deliveryPrice>
        {o.deliveryPrice}
      </deliveryPrice>
      <metaData>
        {o.metaData.map(keyValueToXML)}
      </metaData>
    </order>

  implicit def orderFromXML(xmlOrder: NodeSeq): Order = {
    val id = (xmlOrder \\ "id").text
    val timestamp = (xmlOrder \\ "timestamp").text.toLong
    val deliveryPrice = (xmlOrder \\ "deliveryPrice").text.toDouble
    val items = (xmlOrder \\ "item").map(
      itemFromXML).toList
    val metadata = keyValueFromXML(xmlOrder \\ "metadata")
    Order(id, timestamp, items,
      deliveryPrice, metadata)
  }

  implicit def itemToXML(item: Item): NodeSeq =
    <item>
      <id>
        {item.id}
      </id>
      <quantity>
        {item.quantity}
      </quantity>
      <unitPrice>
        {item.unitPrice}
      </unitPrice>{if (item.percentageDiscount.isDefined)
      <percentageDiscount>
        {item.percentageDiscount.get}
      </percentageDiscount>}
    </item>

  private def itemFromXML(xmlItem: NodeSeq): Item = {
    val id = {
      xmlItem \\ "id"
    }.text.toInt
    val quantity = (xmlItem \\ "quantity").text.toInt
    val unitPrice = (xmlItem \\ "unitPrice").text.toDouble
    val percentageDiscount =
      if ((xmlItem \\ "percentageDiscount").isEmpty) None
      else Some((xmlItem \\ "percentageDiscount").text.toDouble)

    Item(id, quantity, unitPrice, percentageDiscount)
  }


  private def keyValueFromXML(xml: NodeSeq) = {
    xml.flatMap {
      case e: Elem => e.child
      case _ => NodeSeq.Empty
    }.map(x => x.label -> x.text).toMap
  }


  private def keyValueToXML(kv: (String, String)) =
    Elem(null, kv._1, Null, TopScope, false, Text(kv._2))
}