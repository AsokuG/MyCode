package com.aggroup.prac

object OrderNumber extends App{

  def getFormatedOrderNr(orderNumber:String) = if(orderNumber.length > 9 ) orderNumber.substring(3, orderNumber.length) else orderNumber

  println(getFormatedOrderNr("201904699008"))

  Book("Scala")
}

case class Book(name: String, price: Double = 250.5)
