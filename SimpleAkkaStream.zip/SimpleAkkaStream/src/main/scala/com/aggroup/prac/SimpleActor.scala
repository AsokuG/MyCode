package com.aggroup.prac

import akka.actor.Actor

class SimpleActor extends Actor {
  override def receive: Receive = {
    case message: String =>
  }
  
}

object SimpleActor extends App {

}
