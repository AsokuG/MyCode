package com.aggroup.prac

object SimpleTest extends App {
println("hello")
}
