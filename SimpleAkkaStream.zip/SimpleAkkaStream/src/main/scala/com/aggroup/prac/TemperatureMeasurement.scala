package com.aggroup.prac

case class TemperatureMeasurement(location: String, measurment: Double)