package com.aggroup.prac

import akka.actor.Actor

class UnresponsiveActor extends Actor {
  override def receive: Receive = Actor.ignoringBehavior

}
