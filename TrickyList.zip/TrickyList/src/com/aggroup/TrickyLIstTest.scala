package com.aggroup

import scala.annotation.tailrec



object TrickyLIstTest extends App {

  /*
   * List('a, 'a, 'a, 'a, 'b, 'c, 'c, 'a, 'a, 'd, 'e, 'e, 'e, 'e)
   * convert consecutive duplicates into  sublists
   * List(List('a, 'a, 'a, 'a), List('b), List('c, 'c), List('a, 'a), List('d), List('e, 'e, 'e, 'e))
   * */
  
  def pack[A](ls: List[A]): List[List[A]] = {
    if (ls.isEmpty) List(List())
    else {
      val (packed, next) = ls span { _ == ls.head }
      if (next == Nil) List(packed)
      else packed :: pack(next)
    }
  }

  val result = pack(List('a, 'a, 'a, 'b, 'c,  'a, 'c, 'a, 'a, 'd, 'e, 'e, 'e, 'e, 'e))

  println(result)
  /*
   * List('a, 'a, 'a, 'a, 'b, 'c, 'c, 'a, 'a, 'd, 'e, 'e, 'e, 'e)
   * eliminate duplicates in the list
   * The order of the elements should not be changed.
   *  */
  def compressTailRec[A](ls: List[A]): List[A] = {
    def compress(result: List[A], currentList: List[A]): List[A] = currentList match {
      case Nil       => result.reverse
      case h :: tail => compress(h :: result, tail.dropWhile(_ == h))
    }
    compress(Nil, ls)
  }

  val result1 = compressTailRec(List('a, 'a, 'a, 'a, 'b, 'c, 'c, 'a, 'a, 'd, 'e, 'e, 'e, 'e))

  println(result1)
    
  
val list =  List(List('a, 'b, 'c), List('d, 'e), List('f, 'g, 'h), List('d, 'e), List('i, 'j, 'k, 'l), List('m, 'n), List('o))
  
println(list.sortWith(_.length < _.length))

println(list.sortBy(_.length))
  
}