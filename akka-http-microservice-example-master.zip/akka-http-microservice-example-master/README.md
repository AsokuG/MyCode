# Akka HTTP Microservice Example

This is a sample example of creating a simple microservice using [Akka HTTP](https://doc.akka.io/docs/akka-http/current/introduction.html).

In this example, we tried to implement MVC-based architecture using [Akka Actors](https://doc.akka.io/docs/akka/current/typed/actors.html) and [Akka HTTP](https://doc.akka.io/docs/akka-http/current/introduction.html), and are going to create a **CRUD** (CREATE READ UPDATE DELETE) for a **User** entity.

User entity looks like:-

    {
       "id": "test-user",
       "firstName": "FName",
       "lastName": "LName"
    }

**Create Request**

    curl -X POST "http://localhost:1234/user" -H "Content-Type: application/json" -d "{\"id\":\"test-user\",\"firstName\":\"FName\",\"lastName\":\"LName\"}"

**Read Request**

    curl -X GET "http://localhost:1234/user?userId=test-user"

**Update Request**

    curl -X PUT "http://localhost:1234/user" -H "Content-Type: application/json" -d "{\"id\":\"test-user\",\"firstName\":\"FName-1\"}"

**Delete Request**

    curl -X DELETE "http://localhost:1234/user?userId=test-user"

## Table of content

1. **MVC Architecture**
2. **The missing view layer**
3. **Adding more services**
4. **Interacting with other microservices**
5. **MEC Summarized**
6. **Libraries Used**
7. **Running Application**
8. **Database Configuration**
9. **Project Configuration**

## MVC Architecture

Although we are not using the play framework to create this example, but the architecture is highly inspired by the [Play’s Model-View-Controller (MVC) architecture](https://www.playframework.com/documentation/2.8.x/Introduction).

**Play MVC**

![play-mvc](docs/play-mvc-architecture.png)

**Our Architecture**

![akka-http-based-mvc](docs/mvc_architecture_simple.png)

 1. HTTP Request Received at the **Controller** actor.
 2. **Controller** actor then sends the request to **ModelController** actor, and thus from here request enters into the model layer.
 3. **ModelController** actor then based on the requirement of the HTTP request, sends the request to the respective service actor, here in our example it is **UserService** actor.
 4. **UserService** actor query data from the database.
 5. Database returns data to **UserService**.
 6. **UserService** actor creates a corresponding response based on the result it got from the database and sends the response to the **ModelController** actor.
 7. **ModelController** actor then sends the response to **Controller** actor.
 8. **Controller** actor publishes the response.

## The missing view layer

The microservice design we have implemented accepts HTTP request messages, processes the request, and then returns an HTTP response message.

The whole application accepts JSON content and responds with JSON content, which makes it easy to focus just on business logic.

And since everything is JSON, so, therefore, there is no need to render anything and hence there is no view layer.

## Adding more services

![mvc-architecture-1](docs/mvc-architecture-1.png)

When needed more services can be added, like for example we have added **Service-1** and **Service-2** here, and similarly, more services can be added here.

Here in the above pic, we have one **UserService** actor and then a **Service-1** actor, and lastly **Service-2** actor, all are taking msgs from **ModelController** actor and sending a response back to the **ModelController**, then based on requirement **ModelController** process, the response and then sends the response back to **Controller** actor, after that **Controller** actor publishes the response.

**Note:-** In this example, we have not implemented **Service-1** and **Service-2** actor, these are just for explanation purposes.

**For Example:-**

![mvc-architecture-2](docs/mvc-architecture-2.png)

 1. HTTP Request arrived at **Controller** actor.
 2. **Controller** sends request to **ModelController** actor.
 3. **ModelController** actor sends request to **UserService** actor.
 4. **UserService** actor queries data-base.
 5. Database returns data to **UserService** actor.
 6. **UserService** processes the response and sends it back to **ModelController** actor.
 7. **ModelController** actor sends the partial response to **Service-1** actor.
 8. **Service-1** actor queries database.
 9. Database returns data to **Service-1** actor.
 10. **Service-1** processes the response and sends it back to **ModelController** actor.
 11. **ModelController** actor after aggregating the response sends back to **Controller** actor.
 12. **Controller** actor publishes the response.

## Interacting with other microservices

![mvc-architecture-3](docs/mvc-architecture-3.png)

To talk to external services we have an **ExtController** actor the same way we have **ModelController** actor.

**ExtController** actor then contains **ExtService** actors, which talk to other microservice and responds to **ExtController**, after that **ExtController** aggregates the response and sends the response back to **Controller** which then publishes the response.

**Note:-** In this example, we have not implemented this concept.

## MEC Summarized

MVC architecture has

1. **Model Layer** - This layer contains business logic.
2. **~~View Layer~~ Ext Layer** - This layer interacts with other services.
3. **Controller Layer** - This accepts requests, processes the request using the Model layer and Ext layer, and publishes responses.

**Features**

1. Easy to develop and maintain.
2. Need to focus on business logic only.
3. HTTP requests and responses can also be converted to gRPC requests and responses.
4. Easy to add more services, into the model layer when business logic increases.
5. Easy to add more services, into the Ext layer when there is a need to interact with other services.

## Libraries Used

|  | Version |
|--|--|
| **JVM** | 8+ |
| **SBT** | 1.4.7 |
| **Scala** | 2.13.6 |
| **Akka Actor Typed** | 2.6.14 |
| **Akka HTTP** | 10.2.4 |
| **Slick** | 3.3.3 |

[Other libraries used](project/Dependencies.scala)

## Running Application

**Without database**

    sbt run

**With Database**

**Windows**

    SET USE_IN_MEMORY_DB_IMPL=false
    SET DB_HOST=localhost
    SET DB_PORT=3306
    SET DB_DATABASE=Test
    SET DB_USER=root
    SET DB_PASSWORD=root
    sbt run

**Linux**

    export USE_IN_MEMORY_DB_IMPL=false
    export DB_HOST=localhost
    export DB_PORT=3306
    export DB_DATABASE=Test
    export DB_USER=root
    export DB_PASSWORD=root
    sbt run

**Note:-** When using the database, we need to specify the database host, port, name, user, and password, according to the machine and database.

## Database Configuration

By default, this example had an **InMemoryImplementation** which enables to run the application without the need to connect to a database.

But this application uses [Slick](https://scala-slick.org/doc/3.3.3/gettingstarted.html) and MySql to connect and query with the actual database.

And for migration, we use [FlywayDb](https://flywaydb.org/documentation/).

Migration Script is present [here](src/main/resources/db/migration).

## Project Configuration

[here](src/main/resources/application.conf)

We can configure any other database instead of MySql just by changing the configuration as defined in [Slick](https://scala-slick.org/doc/3.3.3/gettingstarted.html) and add the correct library dependency in place of [mysqlConnectorJava](project/Dependencies.scala#L42) and then update [build.sbt](build.sbt#L16) to reflect the changes.
