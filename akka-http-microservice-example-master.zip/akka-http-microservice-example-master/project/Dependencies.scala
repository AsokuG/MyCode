import sbt._

object Dependencies {

  object Akka {

    lazy val version = "2.6.14"

    lazy val akkaActorTyped = "com.typesafe.akka" %% "akka-actor-typed" % version
    lazy val akkaStream = "com.typesafe.akka" %% "akka-stream" % version

    def all: Seq[ModuleID] = Seq(akkaActorTyped, akkaStream)
  }

  object AkkaHttp {

    lazy val version = "10.2.4"

    lazy val akkaHttp = "com.typesafe.akka" %% "akka-http" % version
    lazy val akkaHttpSprayJson =
      "com.typesafe.akka" %% "akka-http-spray-json" % version

    def all: Seq[ModuleID] = Seq(akkaHttp, akkaHttpSprayJson)
  }

  object Slf4j {

    val version = "2.0.0-alpha1"

    val slf4jApi = "org.slf4j" % "slf4j-api" % version
    val slf4jSimple = "org.slf4j" % "slf4j-simple" % version
  }

  object Slick {

    val version = "3.3.3"

    val slick = "com.typesafe.slick" %% "slick" % version
    val slickHikariCp = "com.typesafe.slick" %% "slick-hikaricp" % version
  }

  val mysqlConnectorJava = "mysql" % "mysql-connector-java" % "8.0.25"
  val flywayDb = "org.flywaydb" % "flyway-core" % "7.9.1"
}
