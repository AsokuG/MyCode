package xyz.scalaforge.app

import scala.concurrent.ExecutionContext

import xyz.scalaforge.app.GuardianBehavior.Command
import xyz.scalaforge.config.ServiceConfig
import xyz.scalaforge.controller.Controller
import xyz.scalaforge.model.repository.UserRepository
import xyz.scalaforge.model.repository.impl.{UserRepositoryImpl, UserRepositoryInMemoryImpl}
import xyz.scalaforge.util.ReceiveBehavior

import akka.actor.typed._
import akka.actor.typed.scaladsl.{AbstractBehavior, ActorContext, Behaviors}

object GuardianBehavior {

  sealed trait Command

  def apply(serviceConfig: ServiceConfig): Behavior[Command] =
    Behaviors.setup(new GuardianBehavior(serviceConfig)(_))
}

final class GuardianBehavior private (serviceConfig: ServiceConfig)(
    context: ActorContext[Command])
    extends AbstractBehavior(context)
    with ReceiveBehavior[Command] {

  private implicit val ec: ExecutionContext = ExecutionContext.global
  private val scheduler: Scheduler = context.system.scheduler

  serviceConfig.databaseConfig
    .map(_.flywayConfig.flyway)
    .foreach(_.migrate())

  private val userRepository: UserRepository = serviceConfig.databaseConfig
    .map(_.slickConfig)
    .map(new UserRepositoryImpl(_))
    .getOrElse(new UserRepositoryInMemoryImpl)

  private val controller: ActorRef[Controller.Command] = context.spawn(
    Controller(serviceConfig, userRepository, scheduler),
    Controller.ActorName)

  context.watch(controller)

  context.log.info(s"${context.self.path}: Created")

  override def receive: Receive = msg =>
    context.log.info(s"Unexpected Behavior - $msg")

  override def onSignal: PartialFunction[Signal, Behavior[Command]] = {
    case Terminated(_) =>
      Behaviors.stopped
    case _: PostStop =>
      context.system.terminate()
      Behaviors.stopped
  }
}
