package xyz.scalaforge.app

import scala.util.{Failure, Success}

import xyz.scalaforge.config.ServiceConfig

import akka.actor.typed.ActorSystem
import com.typesafe.config.ConfigFactory

object Main extends App {

  ServiceConfig.build(
    ConfigFactory
      .load()
      .getConfig("akkaHttpExample")) match {
    case Success(serviceConfig) =>
      ActorSystem(
        GuardianBehavior(serviceConfig),
        serviceConfig.actorSystemName,
        serviceConfig.config)
    case Failure(exception) =>
      exception.printStackTrace()
  }
}
