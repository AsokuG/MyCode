package xyz.scalaforge.config

import scala.util.Try

import xyz.scalaforge.config.DbConfig.FlywayDbConfig
import xyz.scalaforge.config.ServiceConfig._

import com.typesafe.config.Config
import org.flywaydb.core.Flyway
import slick.basic.DatabaseConfig
import slick.jdbc.JdbcProfile

sealed abstract case class DbConfig(
    slickConfig: DatabaseConfig[JdbcProfile],
    flywayConfig: FlywayDbConfig)

object DbConfig {

  sealed abstract case class FlywayDbConfig(
      url: String,
      user: String,
      password: String) {

    lazy val flyway: Flyway = Flyway
      .configure()
      .baselineOnMigrate(true)
      .dataSource(url, user, password)
      .load()
  }

  object FlywayDbConfig {

    def build(config: Config): Try[FlywayDbConfig] = {
      for {
        url <- checkNonEmpty(config.getString("url"))
        user <- checkNonEmpty(config.getString("user"))
        password <- checkNonEmpty(config.getString("password"))
      } yield new FlywayDbConfig(url, user, password) {}
    }
  }

  def build(config: Config): Try[DbConfig] = {
    for {
      slickConfig <- Try(DatabaseConfig.forConfig[JdbcProfile]("slick", config))
      flywayDbConfig <- FlywayDbConfig.build(config.getConfig("migration"))
    } yield new DbConfig(slickConfig, flywayDbConfig) {}
  }
}
