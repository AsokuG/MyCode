package xyz.scalaforge.config

import scala.concurrent.duration.FiniteDuration
import scala.jdk.DurationConverters._
import scala.util.Try

import xyz.scalaforge.config.ServiceConfig._

import com.typesafe.config.Config

sealed abstract case class HttpConfig(
    host: String,
    port: Int,
    serverStartTimeout: FiniteDuration)

object HttpConfig {

  def apply(config: Config): Try[HttpConfig] = {
    for {
      nonEmptyHostString <- checkNonEmpty(config.getString("host"))
      positiveIntPort <- checkPositive(config.getInt("port"))
      serverStartTimeout <- Try(
        config.getDuration("serverStartTimeout").toScala)
    } yield new HttpConfig(
      nonEmptyHostString,
      positiveIntPort,
      serverStartTimeout) {}
  }
}
