package xyz.scalaforge.config

import scala.concurrent.duration.FiniteDuration
import scala.jdk.DurationConverters._
import scala.util.{Failure, Success, Try}

import com.typesafe.config.Config

abstract sealed case class ServiceConfig private (
    config: Config,
    actorSystemName: String,
    httpConfig: HttpConfig,
    askTimeout: FiniteDuration,
    databaseConfig: Option[DbConfig])

object ServiceConfig {

  def build(config: Config): Try[ServiceConfig] =
    for {
      actorSystemName <- Try(config.getString("actorSystemName"))
      httpConfig <- HttpConfig(config.getConfig("httpConfig"))
      inMemoryImpl = config.getBoolean("useInMemoryDbImplementation")
      dbConfig <-
        if (inMemoryImpl) Try(None)
        else DbConfig.build(config.getConfig("dbConf")).map(Some(_))
      askTimeout <- Try(config.getDuration("askTimeout").toScala)
    } yield new ServiceConfig(
      config,
      actorSystemName,
      httpConfig,
      askTimeout,
      dbConfig) {}

  private[config] def checkNonEmpty(value: String): Try[String] = {
    if (value.nonEmpty) Success(value)
    else Failure(new Exception(s"Empty value"))
  }

  private[config] def checkPositive(value: Int): Try[Int] = {
    if (value > 0) Success(value)
    else Failure(new Exception(s"Non positive value"))
  }
}
