package xyz.scalaforge.controller

import scala.concurrent.{Await, ExecutionContext}

import xyz.scalaforge.config.ServiceConfig
import xyz.scalaforge.controller.Controller._
import xyz.scalaforge.http.HttpServer
import xyz.scalaforge.http.request.ServiceHttpRequest
import xyz.scalaforge.http.response.ServiceHttpResponse
import xyz.scalaforge.model.ModelController
import xyz.scalaforge.model.repository.UserRepository
import xyz.scalaforge.routes.{BaseRoute, UserRoute}
import xyz.scalaforge.util.ReceiveBehavior

import akka.actor.typed._
import akka.actor.typed.scaladsl._
import akka.http.scaladsl.Http.ServerBinding
import akka.http.scaladsl.model.HttpResponse

object Controller {

  sealed trait Command
  final case class HttpRequestCommand(
      request: ServiceHttpRequest,
      replyTo: ActorRef[HttpResponse])
      extends Command
  final case class HttpResponseCommand(
      response: ServiceHttpResponse,
      replyTo: ActorRef[HttpResponse])
      extends Command

  val ActorName = "Controller"

  def apply(
      config: ServiceConfig,
      userRepository: UserRepository,
      scheduler: Scheduler)(implicit ec: ExecutionContext): Behavior[Command] =
    Behaviors.setup(new Controller(config, userRepository, scheduler)(_))
}

final class Controller private (
    config: ServiceConfig,
    userRepository: UserRepository,
    scheduler: Scheduler)(context: ActorContext[Command])(implicit
    ec: ExecutionContext)
    extends AbstractBehavior(context)
    with ReceiveBehavior[Command] {

  private val routes: Set[BaseRoute] = Set(
    new UserRoute(context.self, config.askTimeout, scheduler))

  private val httpServer = new HttpServer(config.httpConfig, routes)(
    context.system)

  private val serverBinding: ServerBinding =
    Await.result(httpServer.startServer(), config.httpConfig.serverStartTimeout)

  context.log.info(s"Http server started -> ${serverBinding.localAddress}")

  private val modelController: ActorRef[ModelController.Command] =
    context.spawn(
      ModelController(context.self, userRepository),
      ModelController.ActorName)

  context.log.info(s"${context.self.path}: Created")

  override def receive: Receive = {
    case HttpRequestCommand(request, replyTo) =>
      modelController ! ModelController.ProcessRequest(request, replyTo)

    case HttpResponseCommand(response, replyTo) =>
      replyTo ! response.toHttpResponse
  }
}
