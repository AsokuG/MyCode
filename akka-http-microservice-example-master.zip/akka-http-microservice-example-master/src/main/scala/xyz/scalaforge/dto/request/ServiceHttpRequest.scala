package xyz.scalaforge.http.request

trait ServiceHttpRequest
