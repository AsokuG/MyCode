package xyz.scalaforge.http.request

import spray.json.DefaultJsonProtocol._
import spray.json.RootJsonFormat

sealed trait UserHttpRequest extends ServiceHttpRequest

object UserHttpRequest {

  implicit lazy val createUserHttpRequestJsonFormat
      : RootJsonFormat[CreateUserHttpRequest] =
    jsonFormat3(CreateUserHttpRequest)
  implicit lazy val updateUserHttpRequestJsonFormat
      : RootJsonFormat[UpdateUserHttpRequest] =
    jsonFormat3(UpdateUserHttpRequest)
  implicit lazy val getUserHttpRequestJsonFormat
      : RootJsonFormat[GetUserHttpRequest] =
    jsonFormat1(GetUserHttpRequest)
  implicit lazy val deleteUserHttpRequestJsonFormat
      : RootJsonFormat[DeleteUserHttpRequest] =
    jsonFormat1(DeleteUserHttpRequest)
}

final case class CreateUserHttpRequest(
    id: String,
    firstName: String,
    lastName: String)
    extends UserHttpRequest

final case class UpdateUserHttpRequest(
    id: String,
    firstName: Option[String],
    lastName: Option[String])
    extends UserHttpRequest

final case class GetUserHttpRequest(id: String) extends UserHttpRequest

final case class DeleteUserHttpRequest(id: String) extends UserHttpRequest
