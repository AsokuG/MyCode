package xyz.scalaforge.http.response

import akka.http.scaladsl.model.HttpResponse



case object UniqueKeyConstraintViolationFailureResponse extends FailureResponse {

  val responseJson =
    """
      |{
      |   "cause": ""
      |}
      |""".stripMargin

  override def toHttpResponse: HttpResponse = ???
}
