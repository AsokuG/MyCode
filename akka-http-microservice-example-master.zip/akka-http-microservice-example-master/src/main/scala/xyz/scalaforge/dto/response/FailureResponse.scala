package xyz.scalaforge.http.response

import akka.http.scaladsl.model.{ContentTypes, HttpEntity, HttpResponse, StatusCodes}

trait FailureResponse extends ServiceHttpResponse

final case class ConstraintViolationFailureResponse(
    optionalMessage: Option[String] = None)
    extends FailureResponse {

  val responseJson: Option[String] = optionalMessage map { message =>
    s"""
         |{
         |   "cause": "$message"
         |}
         |""".stripMargin
  }

  override def toHttpResponse: HttpResponse = responseJson match {
    case Some(resp) =>
      HttpResponse(
        StatusCodes.Conflict,
        entity = HttpEntity(ContentTypes.`application/json`, resp))

    case None => HttpResponse(StatusCodes.Conflict)
  }
}

case object InternalServerErrorResponse extends FailureResponse {
  override def toHttpResponse: HttpResponse = HttpResponse(
    StatusCodes.InternalServerError)
}
