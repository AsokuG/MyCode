package xyz.scalaforge.http.response

import akka.http.scaladsl.model._
import spray.json.{RootJsonFormat, enrichAny}

trait ServiceHttpResponse {

  def toHttpResponse: HttpResponse
}

object ServiceHttpResponse {

  def toJsonString[T <: ServiceHttpResponse](value: T)(implicit
      jsonFormat: RootJsonFormat[T]): String =
    enrichAny[T](value).toJson.compactPrint
}
