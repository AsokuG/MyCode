package xyz.scalaforge.http.response

import xyz.scalaforge.http.response.ServiceHttpResponse._
import xyz.scalaforge.model.entity.User

import akka.http.scaladsl.model._
import spray.json.DefaultJsonProtocol._
import spray.json.RootJsonFormat

sealed trait UserHttpResponse extends ServiceHttpResponse

object UserHttpResponse {

  implicit lazy val createUserHttpResponseJsonFormat
      : RootJsonFormat[CreateUserHttpResponse] =
    jsonFormat1(CreateUserHttpResponse)
  implicit lazy val updateUserHttpResponseJsonFormat
      : RootJsonFormat[UpdateUserHttpResponse] =
    jsonFormat1(UpdateUserHttpResponse)
  implicit lazy val getUserHttpResponseJsonFormat
      : RootJsonFormat[GetUserHttpResponse] =
    jsonFormat1(GetUserHttpResponse)
  implicit lazy val deleteUserHttpResponseJsonFormat
      : RootJsonFormat[DeleteUserHttpResponse] =
    jsonFormat1(DeleteUserHttpResponse)
}

final case class CreateUserHttpResponse(id: String) extends UserHttpResponse {

  override def toHttpResponse: HttpResponse =
    HttpResponse(entity =
      HttpEntity(ContentTypes.`application/json`, toJsonString(this)))
}

final case class UpdateUserHttpResponse(id: String) extends UserHttpResponse {

  override def toHttpResponse: HttpResponse =
    HttpResponse(entity =
      HttpEntity(ContentTypes.`application/json`, toJsonString(this)))
}

final case class GetUserHttpResponse(user: Option[User])
    extends UserHttpResponse {

  override def toHttpResponse: HttpResponse =
    HttpResponse(entity =
      HttpEntity(ContentTypes.`application/json`, toJsonString(this)))
}

final case class DeleteUserHttpResponse(id: String) extends UserHttpResponse {

  override def toHttpResponse: HttpResponse =
    HttpResponse(entity =
      HttpEntity(ContentTypes.`application/json`, toJsonString(this)))
}
