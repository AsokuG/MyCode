package xyz.scalaforge.model

import scala.concurrent.ExecutionContext

import xyz.scalaforge.controller.Controller
import xyz.scalaforge.http.request._
import xyz.scalaforge.http.response.ServiceHttpResponse
import xyz.scalaforge.model.ModelController._
import xyz.scalaforge.model.repository.UserRepository
import xyz.scalaforge.model.service.UserService
import xyz.scalaforge.util.ReceiveBehavior

import akka.actor.typed.scaladsl._
import akka.actor.typed.{ActorRef, Behavior}
import akka.http.scaladsl.model.HttpResponse

object ModelController {

  sealed trait Command
  final case class ProcessRequest(
      request: ServiceHttpRequest,
      replyTo: ActorRef[HttpResponse])
      extends Command
  final case class ProcessResponse(
      response: ServiceHttpResponse,
      replyTo: ActorRef[HttpResponse])
      extends Command

  val ActorName = "ModelController"

  def apply(
      controller: ActorRef[Controller.Command],
      userRepository: UserRepository)(implicit
      ec: ExecutionContext): Behavior[Command] =
    Behaviors.setup(new ModelController(controller, userRepository)(_))
}

final class ModelController(
    controller: ActorRef[Controller.Command],
    userRepository: UserRepository)(context: ActorContext[Command])(implicit
    ec: ExecutionContext)
    extends AbstractBehavior(context)
    with ReceiveBehavior[Command] {

  private val userService: ActorRef[UserService.Command] = context
    .spawn(UserService(context.self, userRepository), UserService.ActorName)

  context.log.info(s"${context.self.path}: created")

  override def receive: Receive = {
    case ProcessRequest(request: UserHttpRequest, replyTo) =>
      userService ! UserService.ProcessUserServiceRequest(request, replyTo)

    case ProcessResponse(response, replyTo) =>
      controller ! Controller.HttpResponseCommand(response, replyTo)
  }
}
