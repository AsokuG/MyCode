package xyz.scalaforge.model.entity

import spray.json.DefaultJsonProtocol._
import spray.json.RootJsonFormat

final case class User(id: String, firstName: String, lastName: String)

object User {

  implicit lazy val userFormat: RootJsonFormat[User] =
    jsonFormat3(User.apply)
}
