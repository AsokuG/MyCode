package xyz.scalaforge.model.repository

import xyz.scalaforge.model.entity.User

import scala.concurrent.Future

trait UserRepository {

  def insert(user: User): Future[Int]

  def delete(id: String): Future[Int]

  def get(id: String): Future[Option[User]]

  def update(
      id: String,
      fNameOption: Option[String] = None,
      lNameOption: Option[String] = None): Future[Int]
}
