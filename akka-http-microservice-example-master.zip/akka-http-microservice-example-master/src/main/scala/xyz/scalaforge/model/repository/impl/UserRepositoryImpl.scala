package xyz.scalaforge.model.repository.impl

import scala.concurrent.Future

import xyz.scalaforge.model.entity.User
import xyz.scalaforge.model.repository.UserRepository
import xyz.scalaforge.model.repository.impl.UserRepositoryImpl.{UsersTable, tableName}

import slick.basic.DatabaseConfig
import slick.jdbc.JdbcProfile
import slick.lifted.ProvenShape

object UserRepositoryImpl {

  val tableName = "User"

  private[repository] final class UsersTable(
      val profile: JdbcProfile,
      val tableName: String) {

    import profile.api._

    final class Schema(tag: Tag) extends Table[User](tag, tableName) {

      def id: Rep[String] = column[String]("Id", O.PrimaryKey)
      def firstName: Rep[String] = column[String]("FirstName")
      def lastName: Rep[String] = column[String]("LastName")

      override def * : ProvenShape[User] = (id, firstName, lastName) <> ({
        case (userId, fName, lName) => User(userId, fName, lName)
      }, User.unapply)
    }

    lazy val users: TableQuery[Schema] = TableQuery(new Schema(_))
  }
}

final class UserRepositoryImpl(databaseConfig: DatabaseConfig[JdbcProfile])
    extends UserRepository {

  private val users = new UsersTable(databaseConfig.profile, tableName).users

  import databaseConfig.profile.api._

  private val db = databaseConfig.db

  override def insert(user: User): Future[Int] = db.run(users += user)

  override def delete(id: String): Future[Int] =
    db.run(users.filter(_.id === id).delete)

  override def get(id: String): Future[Option[User]] =
    db.run(users.filter(_.id === id).result.headOption)

  override def update(
      id: String,
      fNameOption: Option[String] = None,
      lNameOption: Option[String] = None): Future[Int] = {
    val filterQuery = users.filter(_.id === id)
    ((fNameOption, lNameOption) match {
      case (Some(fName), Some(lName)) =>
        Some(
          filterQuery
            .map(user => (user.firstName, user.lastName))
            .update((fName, lName)))
      case (Some(fName), None) =>
        Some(filterQuery.map(_.firstName).update(fName))
      case (None, Some(lName)) =>
        Some(filterQuery.map(_.lastName).update(lName))
      case (None, None) => None
    }) match {
      case Some(query) => db.run(query)
      case None        => Future.successful(0)
    }
  }
}
