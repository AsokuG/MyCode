package xyz.scalaforge.model.repository.impl

import java.sql.SQLIntegrityConstraintViolationException

import scala.collection.mutable
import scala.concurrent.{ExecutionContext, Future}

import xyz.scalaforge.model.entity.User
import xyz.scalaforge.model.repository.UserRepository

final class UserRepositoryInMemoryImpl(implicit ec: ExecutionContext)
    extends UserRepository {

  private[this] val table = mutable.HashMap[String, User]()

  override def insert(user: User): Future[Int] = table.get(user.id) match {
    case Some(_) =>
      Future.failed(
        new SQLIntegrityConstraintViolationException(
          s"Duplicate entry ${user.id} for key 'users.PRIMARY'"))
    case None =>
      table += user.id -> user
      Future.successful(1)
  }

  override def delete(id: String): Future[Int] = table.get(id) match {
    case Some(_) =>
      table -= id
      Future.successful(1)
    case None =>
      Future.successful(0)
  }

  override def get(id: String): Future[Option[User]] =
    Future.successful(table.get(id))

  override def update(
      id: String,
      fNameOption: Option[String],
      lNameOption: Option[String]): Future[Int] = table.get(id) match {
    case Some(user) =>
      val temp =
        fNameOption.map(fn => user.copy(firstName = fn)).getOrElse(user)
      val temp1 =
        lNameOption.map(ln => temp.copy(lastName = ln)).getOrElse(temp)
      table += id -> temp1
      Future.successful(1)

    case None => Future.successful(0)
  }
}
