package xyz.scalaforge.model.service

import java.sql.SQLIntegrityConstraintViolationException

import scala.concurrent.ExecutionContext
import scala.util.{Failure, Success}

import xyz.scalaforge.http.request._
import xyz.scalaforge.http.response._
import xyz.scalaforge.model.ModelController
import xyz.scalaforge.model.entity.User
import xyz.scalaforge.model.repository.UserRepository
import xyz.scalaforge.model.service.UserService.{Command, ProcessUserServiceRequest}
import xyz.scalaforge.util.ReceiveBehavior

import akka.actor.typed.scaladsl.{AbstractBehavior, ActorContext, Behaviors}
import akka.actor.typed.{ActorRef, Behavior}
import akka.http.scaladsl.model.HttpResponse

private[model] object UserService {

  sealed trait Command
  final case class ProcessUserServiceRequest(
      request: UserHttpRequest,
      replyTo: ActorRef[HttpResponse])
      extends Command

  final val ActorName = "UserService"

  def apply(
      modelController: ActorRef[ModelController.Command],
      userRepository: UserRepository)(implicit
      ec: ExecutionContext): Behavior[Command] =
    Behaviors.setup(new UserService(modelController, userRepository)(_))
}

private[model] final class UserService private (
    modelController: ActorRef[ModelController.Command],
    userRepository: UserRepository)(context: ActorContext[Command])(implicit
    ec: ExecutionContext)
    extends AbstractBehavior(context)
    with ReceiveBehavior[Command] {

  context.log.info(s"${context.self.path}: created")

  override def receive: Receive = {
    case ProcessUserServiceRequest(request: CreateUserHttpRequest, replyTo) =>
      handleCreateUserRequest(request, replyTo)

    case ProcessUserServiceRequest(request: UpdateUserHttpRequest, replyTo) =>
      handleUpdateUserRequest(request, replyTo)

    case ProcessUserServiceRequest(request: GetUserHttpRequest, replyTo) =>
      handleGetUserRequest(request, replyTo)

    case ProcessUserServiceRequest(request: DeleteUserHttpRequest, replyTo) =>
      handleDeleteUserRequest(request, replyTo)
  }

  private def handleCreateUserRequest(
      request: CreateUserHttpRequest,
      replyTo: ActorRef[HttpResponse]): Unit = request match {
    case CreateUserHttpRequest(id, firstName, lastName) =>
      userRepository.insert(User(id, firstName, lastName)).onComplete {
        case Success(1) => processResponse(CreateUserHttpResponse(id), replyTo)
        case Failure(_: SQLIntegrityConstraintViolationException) =>
          processResponse(
            ConstraintViolationFailureResponse(Some("User already exists")),
            replyTo)
        case Failure(exception) =>
          context.log.error(exception.getMessage, exception)
          processResponse(InternalServerErrorResponse, replyTo)
      }
  }

  private def handleUpdateUserRequest(
      request: UpdateUserHttpRequest,
      replyTo: ActorRef[HttpResponse]): Unit = request match {
    case UpdateUserHttpRequest(id, firstName, lastName) =>
      userRepository.update(id, firstName, lastName).onComplete {
        case Success(_) => processResponse(UpdateUserHttpResponse(id), replyTo)
        case Failure(exception) =>
          context.log.error(exception.getMessage, exception)
          processResponse(InternalServerErrorResponse, replyTo)
      }
  }

  private def handleGetUserRequest(
      request: GetUserHttpRequest,
      replyTo: ActorRef[HttpResponse]): Unit = request match {
    case GetUserHttpRequest(id) =>
      userRepository.get(id).onComplete {
        case Success(user) =>
          processResponse(GetUserHttpResponse(user), replyTo)
        case Failure(exception) =>
          context.log.error(exception.getMessage, exception)
          processResponse(InternalServerErrorResponse, replyTo)
      }
  }

  private def handleDeleteUserRequest(
      request: DeleteUserHttpRequest,
      replyTo: ActorRef[HttpResponse]): Unit = request match {
    case DeleteUserHttpRequest(id) =>
      userRepository.delete(id).onComplete {
        case Success(_) => processResponse(DeleteUserHttpResponse(id), replyTo)
        case Failure(exception) =>
          context.log.error(exception.getMessage, exception)
          processResponse(InternalServerErrorResponse, replyTo)
      }
  }

  private def processResponse(
      response: ServiceHttpResponse,
      replyTo: ActorRef[HttpResponse]): Unit = {
    modelController ! ModelController.ProcessResponse(response, replyTo)
  }
}
