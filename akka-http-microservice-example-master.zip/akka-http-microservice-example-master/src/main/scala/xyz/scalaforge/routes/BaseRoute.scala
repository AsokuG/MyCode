package xyz.scalaforge.routes

import akka.http.scaladsl.server.Directives._
import akka.http.scaladsl.server.Route

trait BaseRoute {

  def route: Route
}

object BaseRoute {

  def route(routes: Set[BaseRoute]): Route =
    routes.map(_.route).reduce(_ ~ _)
}
