package xyz.scalaforge.routes

import xyz.scalaforge.controller.Controller
import xyz.scalaforge.http.request.UserHttpRequest._
import xyz.scalaforge.http.request._

import akka.actor.typed.scaladsl.AskPattern.Askable
import akka.actor.typed.{ActorRef, Scheduler}
import akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport._
import akka.http.scaladsl.server.Directives._
import akka.http.scaladsl.server.{Route, StandardRoute}
import akka.util.Timeout

final class UserRoute(
    controller: ActorRef[Controller.Command],
    askTimeout: Timeout,
    scheduler: Scheduler)
    extends BaseRoute {

  override def route: Route = path("user") {
    post {
      entity(as[CreateUserHttpRequest]) { request =>
        processRequest(request)
      }
    } ~ put {
      entity(as[UpdateUserHttpRequest]) { request =>
        processRequest(request)
      }
    } ~ get {
      parameter("userId".as[String]) { id =>
        processRequest(GetUserHttpRequest(id))
      }
    } ~ delete {
      parameter("userId".as[String]) { id =>
        processRequest(DeleteUserHttpRequest(id))
      }

    }
  }

  private def processRequest(request: UserHttpRequest): StandardRoute = {
    complete(
      controller.ask(replyTo =>
        Controller
          .HttpRequestCommand(request, replyTo))(askTimeout, scheduler))
  }
}
