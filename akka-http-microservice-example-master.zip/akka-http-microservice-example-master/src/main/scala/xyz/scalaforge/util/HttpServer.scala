package xyz.scalaforge.http

import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success}

import xyz.scalaforge.config.HttpConfig
import xyz.scalaforge.routes.BaseRoute

import akka.actor.typed.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.Http.ServerBinding
import akka.http.scaladsl.server.Route

final class HttpServer(val httpConfig: HttpConfig, val routes: Set[BaseRoute])(
    implicit val system: ActorSystem[_]) {

  lazy val route: Route = BaseRoute.route(routes)

  private[this] var serverBinding: Option[ServerBinding] = None

  def startServer(): Future[ServerBinding] = {
    if (serverBinding.isEmpty) {
      Http()
        .newServerAt(httpConfig.host, httpConfig.port)
        .bindFlow(route)
        .transform {
          case success @ Success(binding) =>
            serverBinding = Some(binding)
            success
          case failure @ Failure(_) =>
            serverBinding = None
            failure
        }(ExecutionContext.parasitic)
    } else {
      Future.successful(serverBinding.head)
    }
  }
}
