package xyz.scalaforge.util

import akka.actor.typed.Behavior
import akka.actor.typed.scaladsl.{AbstractBehavior, Behaviors}

trait ReceiveBehavior[T] { _: AbstractBehavior[T] =>

  type Receive = PartialFunction[T, Unit]

  def receive: Receive

  override def onMessage(msg: T): Behavior[T] = {
    receive(msg)
    Behaviors.same
  }
}
