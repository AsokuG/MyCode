package models

case class Widget (name: String, price: Int)
  
