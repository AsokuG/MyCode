package controllers

import javax.inject._
import play.api._
import play.api.mvc._

import play.api.libs.{ Comet }
//import play.api.libs.streams
import play.api.libs.iteratee.streams.IterateeStreams
import play.api.libs.concurrent._


//import akka.util.duration._


import akka.util.Timeout

import scala.concurrent.duration._ 
import scala.concurrent.impl.Promise



/**
 * This controller creates an `Action` to handle HTTP requests to the
 * application's home page.
 */
@Singleton
class HomeController @Inject()(cc: ControllerComponents) extends AbstractController(cc) {

  
   /** 
   * A String Enumerator producing a formatted Time message every 100 millis.
   * A callback enumerator is pure an can be applied on several Iteratee.
   */
  lazy val clock: Enumerator[String] = {
    
    import java.util._
    import java.text._
    
    val dateFormat = new SimpleDateFormat("HH mm ss")
    
    Enumerator.fromCallback { () =>
      Promise.timeout(Some(dateFormat.format(new Date)), 100 milliseconds)
    }
  }
  
  
  /**
   * Create an Action to render an HTML page.
   *
   * The configuration in the `routes` file means that this method
   * will be called when the application receives a `GET` request with
   * a path of `/`.
   */
  def index() = Action { implicit request: Request[AnyContent] =>
    Ok(views.html.index())
    
  }
  
    
  def liveClock = Action { implicit request: Request[AnyContent] =>
    Ok.chunked(clock &> Comet.string(callback = "parent.clockChanged"))
  }
}
