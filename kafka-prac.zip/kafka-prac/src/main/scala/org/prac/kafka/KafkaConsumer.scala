package org.prac.kafka

import org.apache.kafka.clients.consumer.KafkaConsumer

import java.util.Properties
import scala.collection.JavaConverters._
import java.time.Duration



object KafkaConsumer extends App {
  val properties = new Properties()
  properties.put("bootstrap.servers", "localhost:9092")
  properties.put("key.deserializer", "org.apache.kafka.common.serialization.IntegerDeserializer")
  properties.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer")
  properties.put("auto.offset.reset", "latest")
  properties.put("group.id", "consumer-group")
  val consumer = new KafkaConsumer[Int, String](properties)
  consumer.subscribe(List("channel").asJava)

  while (true) {
    // print("enter")
    val record = consumer.poll(Duration.ZERO).asScala.iterator
    // println("true")
    // println(record)
    if (!record.isEmpty) {
      for (value <- record)
        println(value)
    }
  }
}
