package org.prac.kafka

import com.oracle.jrockit.jfr.Producer
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord}

import java.util.Properties

object KafkaProducer extends App {
  val properties = new Properties()
  properties.put("bootstrap.servers", "localhost:9092")
  properties.put("key.serializer", "org.apache.kafka.common.serialization.IntegerSerializer")
  properties.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer")
  val kafkaProducer = new KafkaProducer[Int, String](properties)
  val producerRecord = new ProducerRecord[Int, String]("channel", 1, "helloooooooooooooooooooo")
  kafkaProducer.send(producerRecord)
  kafkaProducer.send(new ProducerRecord[Int, String]("channel",  2,"hiiiiiiiiiiiiiiiiiiiiiiiiiiiiii"))
  kafkaProducer.close()
}
