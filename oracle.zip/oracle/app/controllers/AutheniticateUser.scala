package controllers

import javax.inject.Inject
import play.api.mvc._
import play.api.mvc.Results._
import scala.concurrent.{ExecutionContext, Future}

import models.Repository
import models.User


//class UserRequest[A](val username: Option[String], request: Request[A]) extends WrappedRequest[A](request)


class AuthenticatedUserAction @Inject() (parser: BodyParsers.Default)(implicit ec: ExecutionContext)
extends ActionBuilderImpl(parser) {

    private val logger = play.api.Logger(this.getClass)

    override def invokeBlock[A](request: Request[A], block: (Request[A]) => Future[Result]) = {
        logger.debug("ENTERED AuthenticatedUserAction::invokeBlock")
        
         val userName = request.headers.get("username").fold("")(identity)
       
         
          if (Repository.verfiedUsers.contains(User(userName))) {
      val res: Future[Result] = block(request)
                res
    } else {
      Future.successful(Results.Unauthorized("Unauthorized access !!"))
    }
    }
    }

