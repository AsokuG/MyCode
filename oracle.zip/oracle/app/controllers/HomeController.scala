package controllers

import javax.inject._
import play.api._
import play.api.mvc._

import models.Repository.researchPaperList
import models.Repository

import scala.concurrent.Future

import java.text.SimpleDateFormat

/**
 * This controller creates an `Action` to handle HTTP requests to the
 * application's home page.
 */
@Singleton
class HomeController @Inject()(cc: ControllerComponents,authenticatedUserAction: AuthenticatedUserAction ) extends AbstractController(cc) {

  /**
   * Create an Action to render an HTML page.
   *
   * The configuration in the `routes` file means that this method
   * will be called when the application receives a `GET` request with
   * a path of `/`.
   */
  def index() = Action { implicit request: Request[AnyContent] =>
    Ok(views.html.index())
  }
   implicit val ec: scala.concurrent.ExecutionContext = scala.concurrent.ExecutionContext.global
  
  def listResearchPaperList = authenticatedUserAction.async { Future{ Ok(views.html.home(Repository.fetch))} } 
  
 /* def fetchArtistByName(name: String) = Action {
    Ok(views.html.home(Artist.fetchByName(name)))
  }*/
  def fecthByTitle(title:String) = authenticatedUserAction.async { Future{ Ok(views.html.home(Repository.fetchByTitle(title))) }}
  
   def fecthByAuthor(author:String) = authenticatedUserAction.async {  Future {Ok(views.html.home(Repository.fetchByAuthor(author))) }}
   
   
   def fecthByText(text:String) = authenticatedUserAction.async { Future{ Ok(views.html.home(Repository.fetchByText(text))) } }
   
   def fetchByDates(date1:String,date2:String)= authenticatedUserAction.async { Future { Ok(views.html.home(Repository.fetchByDates(new SimpleDateFormat("dd/MM/yyyy").parse(date1), new SimpleDateFormat("dd/MM/yyyy").parse(date2))))} }
   def fecthById(id:String) = authenticatedUserAction.async { Future{ Ok(views.html.home(Repository.fetchById(id.toLong))) } }
   
}
