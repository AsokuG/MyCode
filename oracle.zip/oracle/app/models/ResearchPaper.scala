package models

case class ResearchPaper(id:Long,
    title:String,
    authors:List[String],
    publishedDate:java.util.Date,
    textOfThePaper:String
    )
    
    
    
case class User(username:String)
    

object Autheticated{
 val  verfiedUsers=Seq(User("uday"))
}


    
 object Repository{

  val verfiedUsers = Seq(User("uday"))

  val researchPaperList = Seq(
    ResearchPaper(1, "scala", List("MartinOderskey"), new java.util.Date, "Scala is a Hybrid Programming Langauage"),
    ResearchPaper(2, "akka", List("Roobert", "downey"), new java.util.Date, "Scala is a not a Language for week hearts"),
    ResearchPaper(3, "Play", List("MartinOderskey"), new java.util.Date, "Scala is a Hybrid Programming Langauage"),
    ResearchPaper(4, "Spark", List("MartinOderskey"), new java.util.Date, "Scala is a Hybrid Programming Langauage"),
    ResearchPaper(5, "scala Programming", List("MartinOderskey"), new java.util.Date, "Scala is a Hybrid Programming Langauage"),
    ResearchPaper(6, "scala Programming", List("MartinOderskey"), new java.util.Date, "Scala is a Hybrid Programming Langauage"),
    ResearchPaper(7, "scala Programming", List("MartinOderskey"), new java.util.Date, "Scala is a Hybrid Programming Langauage"),
    ResearchPaper(8, "scala Programming", List("MartinOderskey"), new java.util.Date, "Scala is a Hybrid Programming Langauage"))

  def fetch: Seq[ResearchPaper] = { researchPaperList }

  def fetchByTitle(title: String): Seq[ResearchPaper] = { researchPaperList.filter(a => a.title == (title)) }
  def fetchByAuthor(author: String): Seq[ResearchPaper] = { researchPaperList.filter(a => a.authors.contains(author)) }
  def fetchByDates(date1: java.util.Date, date2: java.util.Date): Seq[ResearchPaper] = { researchPaperList.filter(a => a.publishedDate.compareTo(date1) >= 0 && a.publishedDate.compareTo(date2) <= 0) }
  def fetchByText(text: String): Seq[ResearchPaper] = { researchPaperList.filter(a => a.textOfThePaper.contains(text)) }

  def fetchById(id: Long): Seq[ResearchPaper] = { researchPaperList.filter(a => a.id == id) }

}