package controllers

import play.api.mvc.AbstractController
import play.api.mvc.ControllerComponents
import javax.inject.Inject
import views.html._
import models.Product


class Products @Inject()(cc: ControllerComponents) extends AbstractController(cc) {
  
    /**
   * Displays a products list.
   */
  def rotate = Action { 
  val products = Product.findAll
  Ok(list(products))
  }
  
  def find(ean: Long) = Action {
  val prod = Product.findByEan(ean)
  Ok(details(prod))

  }

  
}