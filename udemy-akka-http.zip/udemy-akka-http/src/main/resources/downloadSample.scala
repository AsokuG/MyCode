trait Animal{
  def speak = println("speaking..")
  def walk = println("walking fastly..")
  def comeToMaster: Unit
}

class Cat extends Animal{
   override def speak: Unit = println("meow....")
   def comeToMaster = println("catch me if you can..")
}

object Sample extends App{
 val kity = new Cat
  kity.speak
  kity.walk
  kity.comeToMaster
}