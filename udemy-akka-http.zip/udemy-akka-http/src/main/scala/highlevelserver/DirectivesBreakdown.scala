package highlevelserver

import akka.actor.ActorSystem
import akka.event.LoggingAdapter
import akka.http.javadsl.server.Route
import akka.http.scaladsl.Http
import akka.http.scaladsl.model.{ContentTypes, HttpEntity, HttpRequest, StatusCodes}
import akka.stream.ActorMaterializer
import akka.http.scaladsl.server.Directives._

object DirectivesBreakdown extends App {

  implicit val system = ActorSystem("DirectivesBreakdown")
  implicit val materializer = ActorMaterializer()

  import system.dispatcher

  /**
   * Type #1: filtering directives
   */

  val simpleHttpMethodRoute =
    get { // equivalent directives for get, put, patch, delete, head, options
      complete(StatusCodes.OK)
    }

  val simplePathRoute =
    path("") {
      complete(
        HttpEntity(
          ContentTypes.`text/html(UTF-8)`,
          """
            |<html>
            |<body>
            |Hello from the about page!!!!
            |</body>
            |</html>
            |""".stripMargin
        ))
    }


  val complexPathRoute =
    path("api" / "myEndpoint") {
      complete(StatusCodes.OK)
    } // /api/myEndpoint


  val dontConfuse =
    path("api/myEndpoint") {
      complete(StatusCodes.OK)
    }

  val pathEndRoute =
    pathEndOrSingleSlash { //localhost:8001 or localhost:8001/
      complete(StatusCodes.OK)
    }

  // Http().bindAndHandle(pathEndRoute, "localhost", 8001)

  /**
   * Type #2: extraction directives
   */
  val pathExtractionRoute =
    path("api" / "item" / IntNumber) { (itemNumber: Int) =>
      println(s"recived item number is $itemNumber")
      complete(StatusCodes.OK)

    }

  val pathMultiExtractRoute =
    path("api" / "order" / IntNumber / IntNumber) { (id, inventory) =>
      println(s"I've got two numbers in the path $id and $inventory")
      complete(StatusCodes.OK)

    }

  val queryParamExtractionRoute =
  // /api/item?id=45
    path("api" / "item") {
      parameter('id.as[Int]) { (itemId: Int) =>
        println(s"I've extracted the ID as $itemId")
        complete(StatusCodes.OK)
      }
    }


  val extractRouteRequest =
    path("controlEndpoint") {
      extractRequest { (httpRequest: HttpRequest) =>
        extractLog { (log: LoggingAdapter) =>
          log.info(s"I got the http request: $httpRequest")
          complete(StatusCodes.OK)

        }

      }
    }

  /**
   * Type #3: composite directives
   */


  val simpleNestedRoute =
    path("api" / "item") {
      get {
        complete(StatusCodes.OK)
      }

    }

  val complexNestedRoute =
    (path("api" / "item") & get) {
      complete(StatusCodes.OK)
    }

  val complexExtractNestedRouteRequest =
    (path("controlEndpoint") & extractRequest & extractLog) { (request, log) =>
      log.info(s"I got the http request: $request")
      complete(StatusCodes.OK)
    }

  // /about and /aboutUs
  // /about and /aboutUs
  val repeatedRoute =
  path("about") {
    complete(StatusCodes.OK)
  } ~
    path("aboutUs") {
      complete(StatusCodes.OK)
    }

  val dryRoute =
    (path("about") | path("aboutUs")) {
      complete(StatusCodes.OK)
    }

  val blogByIdRoute =
    path(IntNumber) { (blogPostId: Int) =>
      complete(StatusCodes.OK)

    }

  val blogByQueryParamRoute =
    parameter('postId.as[Int]) { (blogpostId: Int) =>
      // the SAME server logic
      complete(StatusCodes.OK)
    }
  val combinedBlogByIdRoute =
    (path(IntNumber) | parameter('postId.as[Int])) {
      ((blogPostId: Int) =>
        complete(StatusCodes.OK))
    }

  val completeOkRoute = complete(StatusCodes.OK)

  val failedRoute =
    path("notSupported") {
      failWith(new RuntimeException("Unsupported!!"))
    }

  val routeWithRejection =
  //    path("home") {
  //      reject
  //    } ~
    path("index") {
      completeOkRoute
    }


  Http().bindAndHandle(complexPathRoute, "localhost", 8001)
}
