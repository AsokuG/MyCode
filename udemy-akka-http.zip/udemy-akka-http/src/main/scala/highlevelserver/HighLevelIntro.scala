package highlevelserver

import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.model.{ContentTypes, HttpEntity, StatusCodes}
import akka.http.scaladsl.server.Route
import akka.stream.ActorMaterializer
import akka.http.scaladsl.server.Directives._
import lowlevelserver.HttpsContext



object HighLevelIntro extends App {

  implicit val system = ActorSystem("HighLevelIntro")
  implicit val actorMaterializer = ActorMaterializer()

  import system.dispatcher

  val simpleRoute: Route = path("home") { // Directive
    complete(StatusCodes.OK) // Directive
  }

  /*  val pathGetRoute: Route = path("home") {
      get {
        complete(StatusCodes.OK)
      }
    }*/

  val chainedRoute: Route = path("myEndpoint") {
    get {
      complete(StatusCodes.OK)
    } ~
      post {
        complete(StatusCodes.OK)
      }
  } ~
    path("home") {
      complete(
        StatusCodes.OK,
        HttpEntity(
          ContentTypes.`text/html(UTF-8)`,
          """
            |<html>
            | <body>
            |   Hello from the high level Akka HTTP!
            | </body>
            |</html>
          """.stripMargin
        )
      )
    }

  Http().bindAndHandle(simpleRoute, "localhost", 8080)//HttpsContext.httpsConnectionContext

}
