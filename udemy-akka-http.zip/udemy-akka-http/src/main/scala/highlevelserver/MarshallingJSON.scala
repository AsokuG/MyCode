package highlevelserver

import akka.actor.{Actor, ActorLogging, ActorSystem, Props}
import akka.http.scaladsl.Http
import akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport
import akka.http.scaladsl.model.{ContentTypes, HttpEntity, StatusCodes}
import akka.stream.ActorMaterializer
import akka.http.scaladsl.server.Directives._
import spray.json._
import akka.pattern.ask
import akka.util.Timeout

import scala.concurrent.duration._

case class Player(nickname: String, characterClass: String, level: Int)

object GameAreaMap {

  case object GetAllPlayers

  case class GetPlayer(nickname: String)

  case class GetPlayerByClass(characterClass: String)

  case class AddPlayer(player: Player)

  case class RemovePlayer(player: Player)

  case object OperationSuccess

}

class GameAreaMap extends Actor with ActorLogging {

  import GameAreaMap._

  var players = Map[String, Player]()

  override def receive: Receive = {

    case GetAllPlayers =>
      log.info(s"Get all the players.")
      sender() ! players.values.toList

    case GetPlayer(nickname) =>
      log.info(s"Get the player with nickname. $nickname")
      sender() ! players.get(nickname)
    case GetPlayerByClass(characterClass) =>
      log.info(s"Get list of players with character class. $characterClass")
      sender() ! players.values.toList.filter(_.characterClass == characterClass)
    case AddPlayer(player) =>
      log.info(s"Trying to add a player $player")
      players = players + (player.nickname -> player)
      sender() ! players
    case RemovePlayer(player) =>
      log.info(s"Trying to remove a player $player")
      players = players - (player.nickname)
      sender() ! players
  }
}

trait PlayerJsonProtocol extends DefaultJsonProtocol {
  implicit val parseJson = jsonFormat3(Player)
}

object MarshallingJSON extends App
  with PlayerJsonProtocol
  with SprayJsonSupport {

  implicit val system = ActorSystem("MarshallingJSON")
  implicit val actorMaterializer = ActorMaterializer()

  import system.dispatcher
  import GameAreaMap._

  val rtjvmGameAreaMap = system.actorOf(Props[GameAreaMap], "rockTheJVMGameAreaMap")

  val playersList = List(
    Player("martin_killz_u", "Warrior", 70),
    Player("rolandbraveheart007", "Elf", 67),
    Player("daniel_rock03", "Wizard", 30)
  )

  playersList.foreach { player =>
    rtjvmGameAreaMap ! AddPlayer(player)

  }

  /*
   - GET /api/player, returns all the players in the map, as JSON
   - GET /api/player/(nickname), returns the player with the given nickname (as JSON)
   - GET /api/player?nickname=X, does the same
   - GET /api/player/class/(charClass), returns all the players with the given character class
   - POST /api/player with JSON payload, adds the player to the map
   - (Exercise) DELETE /api/player with JSON payload, removes the player from the map
  */
  implicit val timeout = Timeout(2 seconds)
  val rtjvmGameRouteServ =
    pathPrefix("api" / "player") {
      get {
        path("class" / Segment) { characterClass =>
          complete((rtjvmGameAreaMap ? GetPlayerByClass(characterClass)).mapTo[List[Player]])
        } ~
          (path(Segment) | parameter('nickname.as[String])) { nickname =>
            complete((rtjvmGameAreaMap ? GetPlayer(nickname)).mapTo[Option[Player]])
          } ~
          pathEndOrSingleSlash {
            complete((rtjvmGameAreaMap ? GetAllPlayers).mapTo[List[Player]])
          }
      } ~
        post {
          entity(as[Player]) { player =>
            complete((rtjvmGameAreaMap ? AddPlayer(player)).map(_ => StatusCodes.OK))
          }

        } ~
        delete {
          entity(as[Player]) { player =>
            complete((rtjvmGameAreaMap ? RemovePlayer(player)).map(_ => StatusCodes.OK))
          }
        }
    }

  Http().bindAndHandle(rtjvmGameRouteServ, "localhost", 8067)

}
