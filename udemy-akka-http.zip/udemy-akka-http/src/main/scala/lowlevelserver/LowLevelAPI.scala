package lowlevelserver

import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.Http.IncomingConnection
import akka.http.scaladsl.model.headers.Location
import akka.http.scaladsl.model.{ContentTypes, HttpEntity, HttpMethods, HttpRequest, HttpResponse, StatusCodes, Uri}
import akka.stream.ActorMaterializer
import akka.stream.scaladsl.{Flow, Sink}

import scala.concurrent.Future
import scala.concurrent.duration.DurationInt
import scala.util.{Failure, Success}

object LowLevelAPI extends App {

  implicit val system = ActorSystem("LowLevelAPI")
  implicit val actorMaterializer = ActorMaterializer()

  import system.dispatcher

  val serverSource = Http().bind("localhost", 8000)
  val connectionSink = Sink.foreach[IncomingConnection] { connection =>
    println(s"Accepted incoming connection from: ${connection.remoteAddress}")
  }
  /* val serverBindingFuture = serverSource.to(connectionSink).run()
   serverBindingFuture.onComplete {
     case Success(binding) =>
       println("Server binding successful.")
     // binding.terminate(2 seconds)
     case Failure(ex) => println(s"Server binding failed: $ex")
   }*/

  /*
    Method 1: synchronously serve HTTP responses
   */
  val requestHandler: HttpRequest => HttpResponse = {
    case HttpRequest(HttpMethods.GET, _, _, _, _) =>
      HttpResponse(
        StatusCodes.OK,
        entity = HttpEntity(
          ContentTypes.`text/html(UTF-8)`,
          """
            |<html>
            | <body>
            |   Hello from Akka HTTP!!!!!!
            | </body>
            |</html>
          """.stripMargin
        )
      )

    case request: HttpRequest =>
      request.discardEntityBytes()
      HttpResponse(
        StatusCodes.NotFound,
        entity = HttpEntity(
          ContentTypes.`text/html(UTF-8)`,
          """
            |<html>
            | <body>
            |   Hello from Akka HTTP!
            | </body>
            |</html>
          """.stripMargin
        )
      )
  }

    val httpSynConnectionHandler = Sink.foreach[IncomingConnection] { connection =>
      connection.handleWithSyncHandler(requestHandler)
    }

  // Http().bind("localhost", 8081).runWith(httpSynConnectionHandler)

  // Http().bindAndHandleSync(requestHandler, "localhost", 8081)

  /*
   Method 2: serve back HTTP response ASYNCHRONOUSLY
  */

  val asyncRequestHandler: HttpRequest => Future[HttpResponse] = {
    case HttpRequest(HttpMethods.GET, Uri.Path("/home"), _, _, _) =>     //Method, URI, HTTP headers, content and protocol
      Future(HttpResponse(
        StatusCodes.OK,
        entity = HttpEntity(
          ContentTypes.`text/html(UTF-8)`,
          """
            |<html>
            | <body>
            |   Hello from Akka HTTP2b!!!!!!
            | </body>
            |</html>
          """.stripMargin
        )
      ))


    case request: HttpRequest =>
      request.discardEntityBytes()
      Future(HttpResponse(
        StatusCodes.NotFound,
        entity = HttpEntity(
          ContentTypes.`text/html(UTF-8)`,
          """
            |<html>
            | <body>
            |   Hello from Akka HTTP!
            | </body>
            |</html>
          """.stripMargin
        )
      ))
  }

  val httpAsyncRequestHandler = Sink.foreach[IncomingConnection] { connection =>
    connection.handleWithAsyncHandler(asyncRequestHandler)
  }

  // Http().bind("localhost", 8082).runWith(httpAsyncRequestHandler)

   Http().bindAndHandleAsync(asyncRequestHandler, "localhost", 8082)

  /*
   Method 3: async via Akka streams
  */

  val streamBasedRequestHandler: Flow[HttpRequest, HttpResponse, _] = Flow[HttpRequest].map {

    case HttpRequest(HttpMethods.GET, Uri.Path("/home"), _, _, _) =>
      HttpResponse(
        StatusCodes.OK,
        entity = HttpEntity(
          ContentTypes.`text/html(UTF-8)`,
          """
            |<html>
            | <body>
            |   Hello from Akka HTTP2b!!!!!!
            | </body>
            |</html>
          """.stripMargin
        )
      )

    case request: HttpRequest =>
      request.discardEntityBytes()
      HttpResponse(
        StatusCodes.NotFound,
        entity = HttpEntity(
          ContentTypes.`text/html(UTF-8)`,
          """
            |<html>
            | <body>
            |   Oops Something might be wrong!
            | </body>
            |</html>
          """.stripMargin
        )
      )

  }

 /*  Http().bind("localhost", 8083).runForeach{connection =>
     connection.handleWith(streamBasedRequestHandler)
   }*/

  Http().bindAndHandle(streamBasedRequestHandler, "localhost", 8083)
 // Http().bindAndHandleAsync(asyncRequestHandler, "localhost", 8083)



  /**
   * Exercise: create your own HTTP server running on localhost on 8388, which replies
   *   - with a welcome message on the "front door" localhost:8388
   *   - with a proper HTML on localhost:8388/about
   *   - with a 404 message otherwise
   */

  val synchExerciseHandler: HttpRequest => HttpResponse = {
    case HttpRequest(HttpMethods.GET, Uri.Path("/"), _, _, _) =>
      HttpResponse(
        entity = HttpEntity(
          ContentTypes.`text/html(UTF-8)`,
          "Hello from exercise front door!"
        )
      )
    case HttpRequest(HttpMethods.GET, Uri.Path("/about"), _, _, _) =>
      HttpResponse(
        entity = HttpEntity(
          ContentTypes.`text/html(UTF-8)`,
          """
            |<html>
            | <body>
            |  <div style="color:red">
            |    Hello from the about page!!
            |  <div>
            | </body>
            |</html>
            |""".stripMargin
        )
      )

    case HttpRequest(HttpMethods.GET, Uri.Path("/search"), _, _, _) =>
      HttpResponse(
        StatusCodes.Found,
        headers = List(Location("http://google.com"))
      )

    case request: HttpRequest =>
      request.discardEntityBytes()
      HttpResponse(
        StatusCodes.NotFound,
        entity = HttpEntity(
          ContentTypes.`text/html(UTF-8)`,
          "Oops page not found!!!"
        )
      )
  }

 val bindingFuture = Http().bindAndHandleSync(synchExerciseHandler, "localhost", 8388)

 // bindingFuture.flatMap(binding => binding.unbind()).onComplete(_ => system.terminate())
}
