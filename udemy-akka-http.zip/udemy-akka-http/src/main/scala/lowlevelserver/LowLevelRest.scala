package lowlevelserver

import akka.actor.{Actor, ActorLogging, ActorSystem, Props}
import akka.http.scaladsl.Http
import akka.http.scaladsl.model.Uri.Query
import akka.http.scaladsl.model.{ContentTypes, HttpEntity, HttpMethods, HttpRequest, HttpResponse, StatusCodes, Uri}
import akka.stream.ActorMaterializer
import akka.util.Timeout
import lowlevelserver.GuitarDB.{AddQuantity, CreateGuitar, FindAllGuitars, FindGuitar, FindGuitarsInStock, GuitarCreated}
import spray.json._
import akka.pattern.ask

import scala.concurrent.duration._
import scala.concurrent.Future

case class Guitar(make: String, model: String, quantity: Int = 0)

object GuitarDB {

  case class CreateGuitar(guitar: Guitar)

  case class GuitarCreated(id: Int)

  case object FindAllGuitars

  case class FindGuitar(id: Int)

  case class AddQuantity(id: Int, quantity: Int)

  case class FindGuitarsInStock(inStock: Boolean)

}

class GuitarDB extends Actor with ActorLogging {

  import GuitarDB._

  var guitars: Map[Int, Guitar] = Map()
  var currentGuitarId: Int = 0

  override def receive: Receive = {
    case FindAllGuitars =>
      log.info("searching for all guitars")
      sender() ! guitars.values.toList

    case FindGuitar(id) =>
      log.info(s"searching a guitar by $id")
      sender() ! guitars.get(id)

    case CreateGuitar(guitar) =>
      log.info(s"Adding a guitar $guitar with id $currentGuitarId")
      guitars = guitars + (currentGuitarId -> guitar)
      sender() ! GuitarCreated(currentGuitarId)
      currentGuitarId += 1

    case AddQuantity(id, quantity) =>
      log.info(s"Trying to add $quantity items for guitar $id")
      val guitar: Option[Guitar] = guitars.get(id)
      val newGuitar: Option[Guitar] = guitar.map {
        case Guitar(make, model, q) => Guitar(make, model, q + quantity)
      }
      newGuitar.foreach(guitar => guitars = guitars + (id -> guitar))
      sender() ! newGuitar

    case FindGuitarsInStock(inStock) =>
      log.info(s"Searching for all guitars ${if (inStock) "in" else "out of"} stock")
      if (inStock) sender() ! guitars.values.filter(_.quantity > 0)
      else sender() ! guitars.values.filter(_.quantity == 0)
  }
}

trait GuitarStoreJsonProtocol extends DefaultJsonProtocol {
  implicit val guitarFormat = jsonFormat3(Guitar)
}

object LowLevelRest extends App with GuitarStoreJsonProtocol {

  implicit val system = ActorSystem("LowLevelRest")
  implicit val actorMaterializer = ActorMaterializer()

  import system.dispatcher

  /*
  - GET on localhost:8080/api/guitar => ALL the guitars in the store
  - GET on localhost:8080/api/guitar?id=X => fetches the guitar associated with id X
  - POST on localhost:8080/api/guitar => insert the guitar into the store
 */

  // JSON -> marshalling

  /*  val simpleGuitar = Guitar("Fender", "Stratocaster")
    println(simpleGuitar.toJson.prettyPrint)*/

  /*val simpleGuitarJsonString =
    """
      |{
      |  "make": "Fender",
      |  "model": "Stratocaster"
      |}
      |""".stripMargin

  println(simpleGuitarJsonString.parseJson.convertTo[Guitar])*/

  /*
   setup
  */

  val guitarDb = system.actorOf(Props[GuitarDB], "LowLevelGuitarDB")

  val guitarList = List(
    Guitar("Fender", "Stratocaster"),
    Guitar("Gibson", "Les Paul"),
    Guitar("Martin", "LX1")
  )

  guitarList.foreach { guitar =>
    guitarDb ! CreateGuitar(guitar)

  }

  implicit val defaultTimeout = Timeout(2 second)

  def getGuitar(query: Query): Future[HttpResponse] = {
    val guitarId = query.get("id").map(_.toInt)
    guitarId match {
      case None => Future(HttpResponse(StatusCodes.NotFound)) //localhost:8088/api/guitar?id=
      case Some(id) =>
        val guitarFuture: Future[Option[Guitar]] = (guitarDb ? FindGuitar(id)).mapTo[Option[Guitar]]
        guitarFuture.map {
          case None => HttpResponse(StatusCodes.NotFound)
          case Some(guitar) => HttpResponse(entity = HttpEntity(ContentTypes.`application/json`, guitar.toJson.prettyPrint))
        }
    }

  }

  /**
   * Server code
   */

  // implicit val defaultTimeout = Timeout(2 second)
  val requestHandler: HttpRequest => Future[HttpResponse] = {

    case HttpRequest(HttpMethods.POST, uri@Uri.Path("/api/guitar/inventory"), _, _, _) =>
      val query = uri.query()
      val guitarId: Option[Int] = query.get("id").map(_.toInt)
      val guitarQuantity: Option[Int] = query.get("quantity").map(_.toInt)
      val validGuitarResponseFuture: Option[Future[HttpResponse]] = for {
        id <- guitarId
        quantity <- guitarQuantity
      } yield {
        val newGuitarFuture: Future[Option[Guitar]] = (guitarDb ? AddQuantity(id, quantity)).mapTo[Option[Guitar]]
        newGuitarFuture.map { _ =>
          HttpResponse(StatusCodes.OK)
        }
      }
      validGuitarResponseFuture.getOrElse(Future(HttpResponse(StatusCodes.BadRequest)))

    case HttpRequest(HttpMethods.GET, uri@Uri.Path("/api/guitar/inventory"), _, _, _) =>
      val query = uri.query()
      val inStockOption = query.get("inStock").map(_.toBoolean)
      inStockOption match {
        case Some(inStock) =>
          val guitarsFuture: Future[List[Guitar]] = (guitarDb ? FindGuitarsInStock(inStock)).mapTo[List[Guitar]]
          guitarsFuture.map { guitars =>
            HttpResponse(
              entity = HttpEntity(
                ContentTypes.`application/json`,
                guitars.toJson.prettyPrint
              )
            )

          }
        case None => Future(HttpResponse(StatusCodes.BadRequest))
      }
    //GET
    case HttpRequest(HttpMethods.GET, uri@Uri.Path("/api/guitar"), _, _, _) =>
      val query = uri.query()
      if (query.isEmpty) {
        val guitarList: Future[List[Guitar]] = (guitarDb ? (FindAllGuitars)).mapTo[List[Guitar]]
        guitarList.map { guitar =>
          HttpResponse(
            entity = HttpEntity(
              ContentTypes.`application/json`,
              guitar.toJson.prettyPrint
            )
          )

        }
      } else {
        getGuitar(query)
      }
    //POST
    case HttpRequest(HttpMethods.POST, Uri.Path("/api/guitar"), _, entity, _) =>
      val strictEntityFutre = entity.toStrict(3 seconds)
      strictEntityFutre.flatMap { strictEntity =>
        val guitarJsonString = strictEntity.data.utf8String
        val guitar = guitarJsonString.parseJson.convertTo[Guitar]
        val guitarCreatedFuture: Future[GuitarCreated] = ((guitarDb ? CreateGuitar(guitar)).mapTo[GuitarCreated])
        guitarCreatedFuture.map { _ =>
          HttpResponse(StatusCodes.OK)
        }
      }


    /* case HttpRequest(HttpMethods.GET, uri@Uri.Path("/api/guitar"), _, _, _) =>
       /*
       Query parameter handling code
       */

       val query = uri.query()
       if (query.isEmpty) {
         val guitarlist: Future[List[Guitar]] = (guitarDb ? FindAllGuitars).mapTo[List[Guitar]]
         guitarlist.map { guitar =>
           HttpResponse(
             entity = HttpEntity(
               ContentTypes.`application/json`,
               guitar.toJson.prettyPrint
             )
           )

         }
       } else {
         // fetch guitar associated with guitar id
         //localhost:8088/api/guitars?id=45
         getGuitar(query)
       }*/


    case request: HttpRequest =>
      request.discardEntityBytes()
      Future {
        HttpResponse(status = StatusCodes.NotFound)
      }

  }

  Http().bindAndHandleAsync(requestHandler, "localhost", 8088)

}
